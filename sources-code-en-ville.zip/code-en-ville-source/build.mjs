// Assemble le jeu en deux versions :
//  - dist/code-en-ville.html : page unique pour les artifacts claude.ai
//    (Three.js chargé depuis le CDN jsDelivr via l'import map, polices Google Fonts) ;
//  - site/ : version autonome publiée sur GitHub Pages. Tout est intégré (moteur 3D,
//    polices, textures), avec un manifeste et un service worker : le jeu s'installe
//    comme une application et fonctionne hors connexion.
import { build } from 'esbuild';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, readdirSync } from 'node:fs';

const common = {
  entryPoints: ['src/main.js'],
  bundle: true,
  format: 'esm',
  write: false,
  target: 'es2022', // await au niveau du module : les textures photo sont décodées avant le premier rendu
  legalComments: 'none',
  loader: { '.jpg': 'dataurl' }, // textures photographiques intégrées à la page
};
const scriptSafe = (s) => s.replace(/<\/script/gi, '<\\/script');
const template = readFileSync('src/index.html', 'utf8');

// ---------- 1. Version artifact ----------
const artifact = await build({ ...common, external: ['three', 'three/addons/*'] });
const js = scriptSafe(artifact.outputFiles[0].text);
const page = template.replace('/*__SCRIPT__*/', () => `document.documentElement.lang = 'fr';\n${js}`);
mkdirSync('dist', { recursive: true });
writeFileSync('dist/code-en-ville.html', page);
// Version de test locale (le squelette HTML est ajouté par l'hébergeur en production).
writeFileSync('dist/test.html', `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><style>[hidden]{display:none!important}body{margin:0}</style></head><body>\n${page}\n</body></html>`);
console.log(`dist/code-en-ville.html : ${(page.length / 1024).toFixed(1)} Ko`);

// ---------- 2. Version autonome (site/) ----------
const site = await build({ ...common, minify: true }); // three.js est intégré (licence MIT)
const siteJs = scriptSafe(site.outputFiles[0].text);

// Polices Barlow (SIL Open Font License 1.1) intégrées pour le hors-ligne.
const fonts = [
  ['Barlow', 400, '@fontsource/barlow/files/barlow-latin-400-normal.woff2'],
  ['Barlow', 500, '@fontsource/barlow/files/barlow-latin-500-normal.woff2'],
  ['Barlow', 600, '@fontsource/barlow/files/barlow-latin-600-normal.woff2'],
  ['Barlow Semi Condensed', 600, '@fontsource/barlow-semi-condensed/files/barlow-semi-condensed-latin-600-normal.woff2'],
  ['Barlow Semi Condensed', 700, '@fontsource/barlow-semi-condensed/files/barlow-semi-condensed-latin-700-normal.woff2'],
];
const fontCss = fonts.map(([family, weight, file]) => {
  const b64 = readFileSync(`node_modules/${file}`).toString('base64');
  return `@font-face{font-family:"${family}";font-style:normal;font-weight:${weight};font-display:swap;src:url(data:font/woff2;base64,${b64}) format("woff2")}`;
}).join('\n');

const body = template
  .replace(/<link rel="preconnect"[^>]*>\n?/g, '')
  .replace(/<link rel="stylesheet" href="https:\/\/fonts\.googleapis\.com[^>]*>\n?/, '')
  .replace(/<script type="importmap">[\s\S]*?<\/script>\n?/, '')
  .replace('/*__SCRIPT__*/', () => siteJs);
if (/googleapis|jsdelivr/.test(body)) throw new Error('La version autonome dépend encore d’un serveur externe.');

const sitePage = `<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="description" content="Jeu en 3D pour réviser tout le Code de la route : 10 thèmes de l'examen, vue conducteur, révisions par chapitre.">
<meta name="theme-color" content="#1d4f9c">
<meta name="apple-mobile-web-app-title" content="Code en ville">
<meta name="mobile-web-app-capable" content="yes">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" href="icons/icon-192.png" type="image/png">
<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
<style>[hidden]{display:none!important}body{margin:0}
${fontCss}</style>
</head>
<body>
${body}
<script>
// Mise en cache pour le fonctionnement hors connexion (uniquement en HTTPS ou en local).
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
  addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
}
</script>
</body>
</html>
`;

mkdirSync('site/icons', { recursive: true });
writeFileSync('site/index.html', sitePage);
for (const f of readdirSync('src/pwa/icons')) copyFileSync(`src/pwa/icons/${f}`, `site/icons/${f}`);
copyFileSync('src/pwa/manifest.webmanifest', 'site/manifest.webmanifest');
writeFileSync('site/.nojekyll', '');
// Le nom du cache change à chaque nouvelle version : l'ancienne est remplacée automatiquement.
const version = createHash('sha256').update(sitePage).digest('hex').slice(0, 12);
writeFileSync('site/sw.js', readFileSync('src/pwa/sw.js', 'utf8').replace('__VERSION__', version));
console.log(`site/index.html : ${(sitePage.length / 1024).toFixed(1)} Ko (version ${version})`);
