# Code en ville

Jeu en 3D pour réviser **tout le Code de la route** (permis B) : séries aléatoires sur les 10 thèmes de l'examen, révisions par chapitre, parcours guidé, vue à la place du conducteur.

## Jouer

**https://philgoood91.github.io/code-en-ville/** — sur ordinateur, tablette ou téléphone, sans compte ni inscription.

### Installer le jeu comme une application (fonctionne ensuite sans internet)

- **Android (Chrome)** : ouvrir l'adresse, menu ⋮ → « Installer l'application » (ou « Ajouter à l'écran d'accueil »).
- **iPhone / iPad (Safari)** : ouvrir l'adresse, bouton Partager → « Sur l'écran d'accueil ».
- **Ordinateur (Chrome ou Edge)** : icône d'installation à droite de la barre d'adresse.

Après une première ouverture avec internet, le jeu est conservé sur l'appareil et se lance hors connexion. Les mises à jour arrivent toutes seules à l'ouverture suivante avec internet. La progression (notions déjà vues) est enregistrée sur chaque appareil séparément.

## Comment le dépôt fonctionne

- `src/` : le jeu (moteur de règles, générateur de questions, décors 3D, interface) ; `src/pwa/` : icône, manifeste et cache hors ligne.
- `tests/` : tests automatiques. `npm test` (règles et questions), `python3 tests/e2e.py` (parcours complet dans un navigateur), `python3 tests/site_test.py` (version publiée, hors connexion).
- `npm run build` produit `site/` (la version publiée, tout intégré) et `dist/code-en-ville.html` (version pour claude.ai).
- À chaque envoi sur la branche `main`, GitHub lance les tests, reconstruit le jeu et le publie (`.github/workflows/publier.yml`). Si un test échoue, la version en ligne n'est pas remplacée.
- Licence : voir [LICENCE.md](LICENCE.md) (tous droits réservés ; éléments tiers sous MIT, CC0 et OFL).

## Historique des versions

Jeu web en 3D isométrique pour apprendre le Code de la route (permis B). Version 0.6 : vue à la place du conducteur (pare-brise, rétroviseur) et textures photographiques ; trois modes — **examen blanc** (10, 20 ou 40 questions tirées sur les **10 thèmes de l’examen**), **révision par chapitre** (un thème entier ou l’un de ses 22 chapitres, avec le nombre de notions déjà vues) et **parcours guidé** (11 situations commentées). Catalogue de **227 notions**, dont 83 panneaux ; aucune notion n’est répétée dans une série.

## Vue conducteur et textures photographiques (v0.6)

- **Vue à la place du conducteur** (`src/scene/world.js`, `src/ui/cockpit.js`) : caméra à hauteur des yeux (1,22 m), siège à gauche ; habitacle dessiné en SVG (montants, pavillon, planche de bord, volant) ; **rétroviseur intérieur** rendu en temps réel dans une texture puis inversé comme un miroir. La caméra suit la voiture pendant la résolution. Bouton « Vue conducteur / Vue du dessus » et touche V. La vue conducteur est conseillée automatiquement pour 168 notions sur 227 (panneaux, feux, piétons, passages à niveau, nuit et brouillard, distances, dépassement, vitesses, trajets) ; les priorités restent en vue du dessus (les véhicules venant des côtés seraient hors champ), mais le joueur peut basculer.
- **Panneaux dans le champ de vision** : pour les questions de panneaux, le point d'arrêt du joueur est reculé automatiquement jusqu'à ce que le panneau soit devant lui, à moins de 16° de l'axe et entre 8 et 45 m.
- **Textures réelles** (`src/scene/photos.js`, `src/assets/tex/`) : enrobé, herbe, dalles de trottoir, enduit, brique, tuiles et ballast photographiés (ambientCG, licence CC0), avec relief (normal maps) ; environ 440 Ko intégrés à la page. Les façades combinent la photo d'enduit ou de brique et les fenêtres dessinées.
- **Coût de rendu** : les façades d'immeubles sont fusionnées par matériau et les voitures garées du décor partagent leurs matériaux ; environ 100 appels de dessin par image en vue du dessus, 140 en vue conducteur (rétroviseur compris, ombres calculées une seule fois). Page : 940 Ko.
- **Échelle réaliste** : feux tricolores à hauteur réelle avec une tête de rappel de l'autre côté du carrefour, piétons et cyclistes ramenés presque à leur taille réelle ; brouillard à 50 m de visibilité en vue conducteur.

## Révision par chapitre et panneaux (v0.5)

- **Chapitres** (`src/data/chapters.js`) : les 10 thèmes de l’examen ; la circulation est découpée en 10 chapitres (5 familles de panneaux, priorités, feux, vitesses, dépassement, stationnement) et la route en 4 (nuit et météo, autoroute, passages à niveau, visibilité et montagne). Le menu affiche pour chacun le nombre de notions déjà vues. « Toutes les notions » propose chaque notion du chapitre une fois (60 au plus).
- **Panneaux** : 83 panneaux (libellés vérifiés dans le catalogue CEREMA de juin 2022), quatre types de questions — signification (trois leurres de la même famille), « quel panneau signifie… » avec quatre panneaux plantés en bord de route et réponses en images, famille d’après la forme et les couleurs, et 10 mises en situation (sens interdit, interdiction de tourner, direction obligatoire, stop sans véhicule, arrêt ou stationnement interdit, interdiction de dépasser, entrée d’agglomération, passage étroit B15/C18, zone 30, zone de rencontre).

## Programme couvert et tirage sans redondance (v0.4)

- **Catalogue de notions** (`src/engine/generator.js`, `src/data/fiches.js`) : une notion = une règle ou une connaissance précise (« feu jaune fixe », « alcoolémie en permis probatoire », « position latérale de sécurité »…). 155 notions réparties sur les 10 thèmes : circulation 62 (dont 35 panneaux), route 21, mécanique 13, autres usagers 10, premiers secours 10, conducteur 8, notions diverses 8, prendre et quitter son véhicule 8, sécurité 8, environnement 7.
- **Composition d’une série** (`src/engine/plan.js`) : une notion au plus une fois ; thèmes servis à tour de rôle (poids 2 pour la circulation, 1,5 pour la route et les autres usagers, 1 pour le reste) ; une même famille de mise en scène plafonnée (5 sur 40) ; deux questions qui se suivent n’ont ni le même thème ni la même famille ; les notions vues aux séries précédentes (historique du navigateur) passent après les nouvelles.
- **Variété des mises en scène** : branche d’arrivée tirée au hasard (4 directions), couleur de la voiture du joueur (9 teintes, repérée par l’anneau), usagers variés (voiture, camionnette, camion, bus, moto, vélo, piétons, enfants, pompiers, SMUR, police, tracteur, train), météo et moment (beau, pluie, brouillard, neige, nuit avec lampadaires et faisceaux des phares), deux angles de caméra, six décors (carrefour, giratoire, rue, campagne et forêt, autoroute, parking).
- **Fiches de connaissances** : chaque fiche cite un article du Code (texte du 12/10/2026) ou une source publique avec lien (ADEME, Service-public, fiches de secourisme, voyants). Les points à faire confirmer portent le drapeau `verifier`.
- **Kit véhicule** : capot ouvrant avec batterie, jauge d’huile, vase d’expansion, réservoir de lave-glace (repérage A/B/C), pneus mis en évidence, feux (position, croisement, route, brouillard avant et arrière, détresse), coffre de toit ; voyants du tableau de bord dessinés en vectoriel (`src/scene/dashboard.js`).
- **Accessoires** (`src/scene/props.js`) : feux tricolores animés, lampadaires, passage à niveau (rails, demi-barrières, feux rouges clignotants), triangle, borne, passage piéton.

## Kits et génération aléatoire

- **Kit de décor** (`src/data/layouts.js`, `src/scene/kit.js`) : tuiles de 20 m (route avec options de lignes, trottoirs, piste cyclable, places, passage piéton ; carrefour en croix, en T, giratoire, autoroute avec bretelle et biseau) et pièces de décor (immeubles, maisons, parc, champ, forêt). Formes et matériaux sont partagés ; seule la scène en cours est construite, puis fusionnée par matériau pour limiter les appels de dessin.
- **Kit de panneaux** (`src/data/signs-catalog.js`, `src/scene/signs.js`) : 83 panneaux dessinés par code (panneau et panonceau découpés par transparence pour AB3b et AB5), significations du catalogue IISR du CEREMA, textures en cache.
- **Moteur de règles** (`src/engine/rules.js`) : priorités (R415-4 III, R415-5, R415-6, R415-7), vitesses (R413-2 à R413-5), dépassement (R412-18, R412-19, R414-4), stationnement (R417-11), feux tricolores (R412-30 à R412-33), éclairage (R416-5 à R416-7), distances (R412-12).
- **Générateur** (`src/engine/generator.js`) : 5 familles de questions (priorité, vitesse, panneau, dépassement, stationnement). La bonne réponse et l'explication viennent toujours du moteur de règles ; 2 000 tirages sont vérifiés à chaque `npm test`.

| Chapitre | Situations | Articles |
|---|---|---|
| Carrefours en ville | priorité à droite, stop, cédez le passage, tourner à gauche, giratoire | R415-4 III, R415-5, R415-6, R415-7, R415-10 |
| Rue, vélos et stationnement | tourner à droite en traversant une piste cyclable, où stationner | R415-3 III, R417-11 I |
| Campagne et forêt | vitesse à la sortie du village, dépasser un tracteur sur ligne continue | R413-2 I 3°, R412-19 |
| Autoroute | insertion depuis la bretelle, vitesse sous la pluie | R421-3, R413-2 II 1° |

## Lancer et construire

```
npm install          # three@0.170.0, esbuild, axe-core
npm test             # tests unitaires (moteur de quiz, trajectoires)
npm run build        # produit dist/code-en-ville.html (page unique publiée en artifact)
python3 tests/e2e.py # tests de bout en bout dans Chromium (Playwright)
python3 tests/captures.py [largeur hauteur]  # captures d'écran de revue
```

Three.js est chargé depuis jsDelivr (version figée 0.170.0) par l'import map de la page. Les tests servent la même version depuis `node_modules`.

## Architecture

| Dossier | Rôle | Testable sans navigateur |
|---|---|---|
| `src/data/questions.js` | Banque de questions, chacune rattachée à un article du Code | oui |
| `src/engine/quiz.js` | Session, correction (réponse exacte exigée), seuil 35/40, validation de la banque | oui |
| `src/engine/tween.js` | Animations (motion design) pilotées par la boucle, accélérables | oui |
| `src/scene/routes.js` | Trajectoires des véhicules (circulation à droite, giratoire antihoraire) | oui |
| `src/scene/world.js` | Décor, caméra isométrique, rendu à la demande, qualité adaptative | non |
| `src/scene/director.js` | Mise en scène de chaque situation et du bon ordre de passage | non |
| `src/scene/vehicles.js`, `textures.js` | Voitures et textures procédurales (aucun fichier image) | non |
| `src/audio/sfx.js` | Bruitages synthétisés en Web Audio (aucun fichier son) | non |
| `src/ui/ui.js`, `src/main.js` | Interface et déroulé du jeu | non |

## Règles de contenu

- Chaque question cite l'article du Code de la route qui la fonde (texte officiel, version d'octobre 2026).
- Énoncés et explications rédigés de façon originale. Les ouvrages commerciaux servent uniquement de liste de contrôle des thèmes.
- Mention des réponses : « Plusieurs bonnes réponses » quand il y en a plusieurs, d'après l'exemple du communiqué de la Délégation à la sécurité routière du 11/09/2023 (à confirmer sur une épreuve réelle). Le nombre exact est disponible en option d'aide.

## Phases de test

1. **Tests unitaires** à chaque modification : moteur, trajectoires, cohérence de la banque.
2. **Tests de bout en bout** : parcours complet (juste, faux, temps écoulé), mouvements des véhicules, bilan, téléphone, accessibilité axe-core, budget de rendu.
3. **Revue visuelle** : captures bureau et téléphone.
4. **Relecture indépendante** : code (grille Google eng-practices) et exactitude réglementaire de chaque question.
5. **Tests utilisateurs** : vrais appareils (fluidité, lisibilité, compréhension des scènes).
6. **Relecture par un moniteur d'auto-école** avant toute diffusion.

## Grille de relecture de code (d'après Google eng-practices)

Conception · fonctionnement pour l'utilisateur · complexité et sur-ingénierie · tests (échouent-ils vraiment si le code casse ?) · nommage · commentaires (le pourquoi) · style et cohérence · documentation · sécurité (échappement HTML) · accessibilité · performance (mémoire, appels de dessin) · robustesse (clics répétés, animations concurrentes).

## Historique de relecture

- **v0.1 → v0.2** (relecture indépendante, 19 constats) : `[hidden]` forcé dans la page, Entrée qui valide depuis une option, résolutions concurrentes neutralisées, libération mémoire des objets de chaque situation (testée), clignotant rétabli au « Revoir », focus contrasté, description textuelle de chaque scène pour les lecteurs d'écran, énoncés Q2/Q3/Q5 resserrés sur le texte des articles, alinéas affichés, test de cohérence scène/énoncé.
- **v0.2 → v0.3** (kits + aléatoire, relecture indépendante, 17 constats) : passage piéton replacé à l'endroit des étiquettes (testé), route à deux chaussées sans bretelle, dépassement d'un cycliste conditionné à R414-4, combinaisons stop/stop et cédez/cédez perpendiculaires exclues (le texte ne tranche pas), table des conflits établie à la main comme oracle de test, panneau B21-1 retiré et A1a corrigé (pictogrammes à faire valider), descriptions visuelles des panneaux pour les lecteurs d'écran, fusion du décor protégée contre les changements de scène.
- **v0.3 → v0.4** (programme complet, sans redondance, relecture réglementaire indépendante sur le texte du Code du 12/10/2026) : aucune bonne réponse fausse relevée ; 9 constats corrigés ou documentés — sens du panneau A7 élargi aux barrières manuelles, mention « sans formation complémentaire » dans les questions sur la période probatoire, voiture stationnée de nuit replacée sur la chaussée (R416-12 I), sortie d’autoroute reformulée sur le texte de R421-4, panne « en partie sur la chaussée » pour justifier feux de détresse et triangle, source du 114 remplacée par Santé.fr, pression des pneus « avant de rouler » (ADEME), précautions de R417-8 présentées comme conseils. Restent à faire confirmer : la valeur de 1,6 mm (fixée par arrêté, non relu), les pictogrammes simplifiés des nouveaux panneaux et des voyants, et le décor des routes à deux chaussées (identique à celui de l’autoroute ; seul le texte les distingue). Ne jamais proposer « feux de position seuls » comme leurre en agglomération éclairée (permis par R416-6 II 3°).
- **v0.4 → v0.5** (révision par chapitre, panneaux) : 48 panneaux ajoutés d’après le catalogue CEREMA ; mises en situation adossées au texte du Code (R412-28, R415-6, R413-3, R110-2 pour l’arrêt, la zone 30 et la zone de rencontre). Pictogrammes simplifiés à faire valider (B21-1 et B21c1 se ressemblent ; A15b, A24, B26, B52 très schématiques).
