// Habitacle dessiné en SVG par-dessus la vue conducteur : montants de pare-brise, pavillon, planche de bord,
// volant et cadre du rétroviseur intérieur (l'image du rétroviseur est rendue en 3D, sous ce cadre).
const NS = 'http://www.w3.org/2000/svg';

export function createCockpit(world) {
  const svg = document.createElementNS(NS, 'svg');
  svg.id = 'cockpit'; svg.setAttribute('aria-hidden', 'true'); svg.setAttribute('focusable', 'false');
  document.body.insertBefore(svg, document.getElementById('scene').nextSibling);

  function draw() {
    const on = world.view.mode === 'conducteur';
    svg.style.display = on ? 'block' : 'none';
    if (!on) return;
    const w = window.innerWidth, h = window.innerHeight;
    const cx = world.view.focus.x * w;
    const r = world.view.mirrorRect;
    svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
    const dashTop = h * 0.83, wheelR = Math.min(h * 0.36, w * 0.3);
    svg.innerHTML = `
      <defs>
        <linearGradient id="cp-dash" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b2f35"/><stop offset="1" stop-color="#121417"/></linearGradient>
        <linearGradient id="cp-pillar" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#15171a"/><stop offset="1" stop-color="#2a2e34"/></linearGradient>
        <radialGradient id="cp-glass" cx="0.5" cy="0" r="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0.07"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>
      </defs>
      <rect x="0" y="0" width="${w}" height="${h}" fill="url(#cp-glass)"/>
      <path d="M0 0 H${w} V${h * 0.05} Q${cx} ${h * 0.085} 0 ${h * 0.05} Z" fill="#1d2025"/>
      <path d="M0 ${h * 0.03} L${w * 0.09} ${h * 0.03} L${w * 0.01} ${h * 0.86} L0 ${h * 0.86} Z" fill="url(#cp-pillar)"/>
      <path d="M${w} ${h * 0.03} L${w - w * 0.09} ${h * 0.03} L${w - w * 0.01} ${h * 0.86} L${w} ${h * 0.86} Z" fill="url(#cp-pillar)"/>
      <path d="M0 ${h} V${dashTop + h * 0.03} Q${cx} ${dashTop - h * 0.06} ${w} ${dashTop + h * 0.03} V${h} Z" fill="url(#cp-dash)"/>
      <path d="M${cx - w * 0.09} ${dashTop + h * 0.005} Q${cx} ${dashTop - h * 0.05} ${cx + w * 0.09} ${dashTop + h * 0.005}" fill="#0d0f12"/>
      <circle cx="${cx}" cy="${h + wheelR * 0.42}" r="${wheelR}" fill="none" stroke="#0c0d0f" stroke-width="${Math.max(18, wheelR * 0.12)}"/>
      <circle cx="${cx}" cy="${h + wheelR * 0.42}" r="${wheelR}" fill="none" stroke="#3a3f46" stroke-width="2" opacity="0.6"/>
      ${r ? `<path d="M${cx} ${h * 0.05} V${r.y}" stroke="#1d2025" stroke-width="12"/>
      <rect x="${r.x - 7}" y="${r.y - 7}" width="${r.w + 14}" height="${r.h + 14}" rx="${r.h * 0.38}" fill="none" stroke="#16181b" stroke-width="12"/>
      <rect x="${r.x - 1}" y="${r.y - 1}" width="${r.w + 2}" height="${r.h + 2}" rx="${r.h * 0.3}" fill="none" stroke="#5a6068" stroke-width="2"/>` : ''}`;
  }
  window.addEventListener('resize', draw);
  return { draw, element: svg };
}
