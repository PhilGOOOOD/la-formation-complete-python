// Interface : écrans, carte de question, retour pédagogique et bilan.
import { THEMES } from '../data/questions.js';
import { DOMAINS, domainLabel } from '../data/domains.js';
import { expectedHint } from '../engine/quiz.js';

const $ = (sel, root = document) => root.querySelector(sel);

/** « R415-4 » + « III » → « R. 415-4, III » ; une fiche hors Code renvoie « source ». */
export function articleLabel(q) {
  if (q.reference) return q.signCode ? 'IISR' : 'source';
  return q.article.replace(/^([RL])/, '$1. ') + (q.alinea ? `, ${q.alinea}` : '');
}
/** Plaque de référence sous l'explication (avec lien vers la source publique quand il y en a une). */
function referenceHtml(q) {
  const text = q.signCode ? `Signalisation · ${q.reference}` : q.reference ? `Source · ${q.reference}` : `Code de la route · art. ${articleLabel(q)}`;
  const link = q.source && /^https:\/\//.test(q.source) ? ` <a href="${esc(q.source)}" target="_blank" rel="noopener">voir</a>` : '';
  return `${esc(text)}${link}`;
}
/** Vignette : panneau (même dessin que dans la scène) ou voyant du tableau de bord. */
function thumb(q) {
  if (q.signImage) return `<img class="vignette" src="${q.signImage}" alt="Panneau : ${esc(q.signDesc || '')}" width="96" height="96">`;
  if (q.voyantImage) return `<img class="vignette" src="${q.voyantImage}" alt="Voyant du tableau de bord : ${esc(q.voyantDesc || '')}" width="96" height="96">`;
  return '';
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function createUI() {
  const el = {
    intro: $('#ecran-accueil'),
    card: $('#carte'),
    end: $('#ecran-bilan'),
    progress: $('#progression'),
    timer: $('#chrono'),
    timerBar: $('#chrono-barre'),
    live: $('#annonce'),
    mute: $('#btn-son'),
    skip: $('#btn-passer'),
  };

  function show(which) {
    el.intro.hidden = which !== 'intro';
    el.end.hidden = which !== 'end';
    el.card.hidden = !['observe', 'question', 'feedback'].includes(which);
  }

  function renderProgress(total, index, answers) {
    el.progress.innerHTML = Array.from({ length: total }, (_, i) => {
      const a = answers[i];
      const cls = a ? (a.correct ? 'ok' : 'ko') : i === index ? 'en-cours' : '';
      const label = a ? (a.correct ? 'juste' : 'à revoir') : i === index ? 'en cours' : 'à venir';
      return `<li class="${cls}" title="Question ${i + 1} : ${label}"><span class="sr">Question ${i + 1} : ${label}</span></li>`;
    }).join('');
  }

  function header(q, index, total) {
    return `<div class="carte-tete">
      <span class="eyebrow">${esc(domainLabel(q.domaine) || THEMES[q.theme] || '')}</span>
      <span class="compteur">${index + 1}<span class="sur">/${total}</span></span>
    </div>`;
  }

  function renderObserve(q, index, total) {
    el.card.dataset.phase = 'observe';
    el.card.innerHTML = `${header(q, index, total)}
      <p class="situation">${esc(q.situation)}</p>
      <p class="observe"><span class="pulse" aria-hidden="true"></span>Observez la situation…</p>`;
  }

  function renderQuestion(q, index, total, selected, onToggle, onValidate, { exactCount = false } = {}) {
    el.card.dataset.phase = 'question';
    const hint = expectedHint(q, { exact: exactCount });
    el.card.innerHTML = `${header(q, index, total)}
      <p class="situation">${esc(q.situation)}</p>
      ${thumb(q)}
      <h2 class="question" id="q-titre">${esc(q.question)}</h2>
      ${hint ? `<p class="attendues">${hint}</p>` : ''}
      <div class="options${q.options.every((o) => o.image) ? ' en-images' : ''}" role="group" aria-labelledby="q-titre">
        ${q.options.map((o) => `<button type="button" class="option" id="opt-${o.id}" data-id="${o.id}" aria-pressed="${selected.has(o.id)}">
          <span class="lettre">${o.id}</span>${o.image ? `<img class="opt-img" src="${o.image}" alt="${esc(o.alt || '')}" width="64" height="64">` : ''}<span class="texte">${esc(o.text)}</span></button>`).join('')}
      </div>
      <button type="button" class="btn primaire" id="btn-valider" ${selected.size ? '' : 'disabled'}>Valider</button>`;
    el.card.querySelectorAll('.option').forEach((b) => b.addEventListener('click', () => onToggle(b.dataset.id)));
    $('#btn-valider', el.card).addEventListener('click', onValidate);
  }

  function updateSelection(selected) {
    el.card.querySelectorAll('.option').forEach((b) => b.setAttribute('aria-pressed', String(selected.has(b.dataset.id))));
    const v = $('#btn-valider', el.card); if (v) v.disabled = selected.size === 0;
  }

  function renderFeedback(q, record, index, total, onReplay, onNext, last) {
    el.card.dataset.phase = 'feedback';
    const verdict = record.timedOut ? 'Temps écoulé' : record.correct ? 'Bonne réponse' : 'Pas tout à fait';
    const good = q.options.filter((o) => q.correct.includes(o.id)).map((o) => `<li><span class="lettre">${o.id}</span>${o.image ? `<img class="opt-img" src="${o.image}" alt="${esc(o.alt || '')}" width="48" height="48">` : ''}${esc(o.text)}</li>`).join('');
    el.card.innerHTML = `${header(q, index, total)}
      <p class="verdict ${record.correct ? 'ok' : 'ko'}"><span class="pastille" aria-hidden="true">${record.correct ? '✓' : '✕'}</span>${verdict}</p>
      <p class="attendu-titre">${q.correct.length > 1 ? 'Les bonnes réponses' : 'La bonne réponse'}</p>
      <ul class="bonnes">${good}</ul>
      <p class="explication">${esc(q.explanation)}</p>
      <p class="panonceau">${referenceHtml(q)}</p>
      <div class="actions">
        <button type="button" class="btn secondaire" id="btn-revoir">Revoir la scène</button>
        <button type="button" class="btn primaire" id="btn-suivant">${last ? 'Voir le bilan' : 'Question suivante'}</button>
      </div>`;
    $('#btn-revoir', el.card).addEventListener('click', onReplay);
    $('#btn-suivant', el.card).addEventListener('click', onNext);
    announce(`${verdict}. ${q.explanation}`);
    $('#btn-suivant', el.card).focus({ preventScroll: true });
  }

  function renderEnd(result, questions, onRestart, titre = 'Bilan du parcours') {
    $('#titre-bilan', el.end).textContent = titre;
    const { score, total } = result;
    const ratio = score / total;
    const message = ratio === 1 ? 'Sans faute : toutes les situations sont maîtrisées.'
      : result.passed ? 'Réussi. Revoyez les situations marquées pour consolider.'
        : 'Encore un tour : relisez les explications puis rejouez.';
    $('#bilan-score', el.end).innerHTML = `${score}<span class="sur">/${total}</span>`;
    $('#bilan-anneau', el.end).style.setProperty('--ratio', ratio);
    $('#bilan-message', el.end).textContent = message;
    $('#bilan-seuil', el.end).textContent = `À l’examen, il faut 35 bonnes réponses sur 40, soit ${Math.ceil(total * 35 / 40)} sur ${total} à cette échelle.`;
    // Résultat par thème officiel : repère ce qu'il faut retravailler
    const perDomain = new Map();
    for (const d of result.details) {
      const q = questions.find((x) => x.id === d.id);
      const r = perDomain.get(q.domaine) || { ok: 0, n: 0 }; r.n++; if (d.correct) r.ok++; perDomain.set(q.domaine, r);
    }
    const rows = DOMAINS.filter((d) => perDomain.has(d.id)).map((d) => {
      const r = perDomain.get(d.id);
      return `<tr><th scope="row">${esc(d.label)}</th><td class="${r.ok < r.n ? 'faible' : ''}">${r.ok} / ${r.n}</td></tr>`;
    }).join('');
    $('#bilan-themes', el.end).innerHTML = rows ? `<table><caption>Par thème de l’examen</caption><tbody>${rows}</tbody></table>` : '';
    $('#bilan-liste', el.end).innerHTML = result.details.map((d) => {
      const q = questions.find((x) => x.id === d.id);
      const ref = q.signCode ? esc(q.signCode) : q.reference ? 'source' : `art. ${esc(articleLabel(q))}`;
      return `<li class="${d.correct ? 'ok' : 'ko'}"><span class="pastille" aria-hidden="true">${d.correct ? '✓' : '✕'}</span>
        <span class="bilan-q">${esc(q.question)} <em>${esc(q.situation)}</em></span><span class="bilan-art">${ref}</span></li>`;
    }).join('');
    $('#btn-rejouer', el.end).onclick = onRestart;
    show('end');
    announce(`Bilan : ${score} sur ${total}. ${message}`);
  }

  function setTimer(fraction, visible) {
    el.timer.hidden = !visible;
    el.timerBar.style.transform = `scaleX(${Math.max(0, Math.min(1, fraction))})`;
    el.timer.classList.toggle('urgent', fraction < 0.25);
  }

  function announce(text) { el.live.textContent = ''; requestAnimationFrame(() => { el.live.textContent = text; }); }

  return { el, show, renderProgress, renderObserve, renderQuestion, updateSelection, renderFeedback, renderEnd, setTimer, announce };
}
