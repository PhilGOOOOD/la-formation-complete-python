// Banque de fiches de connaissances — une fiche = une notion du programme, jamais tirée deux fois dans une même série.
// Chaque fiche cite sa source :
//  - article : Code de la route, texte du 12 octobre 2026 (document codedelaroute2026.pdf du projet) ;
//  - reference + source : source publique hors Code (ADEME, Service-public, Croix-Rouge…), lien dans `source`.
// verifier : point à faire confirmer par un moniteur avant diffusion (seuil fixé par arrêté, ordre de grandeur, maquette).
// Énoncés rédigés de façon originale. Champs d'une variante : s (situation), q (question), ok (bonnes réponses),
// ko (leurres), e (explication), fixe (garder l'ordre des options, ex. Oui / Non).
// scene : recette de mise en scène (voir src/engine/generator.js, sceneFromRecipe).

const OUI_NON = (bonne, e, s, q) => ({ s, q, ok: [bonne], ko: [bonne === 'Oui' ? 'Non' : 'Oui'], e, fixe: true });

export const FICHES = [
  // ——————————————————— Le conducteur ———————————————————
  { notion: 'alcool-general', domaine: 'conducteur', article: 'R234-1', alinea: 'I, 2°', scene: { recette: 'trajet', nuit: true },
    variantes: [
      { s: 'Vous avez votre permis depuis plus de trois ans et vous sortez d’un repas.', q: 'Au volant, vous êtes en infraction à partir d’une alcoolémie de :', ok: ['0,5 g d’alcool par litre de sang'], ko: ['0,2 g d’alcool par litre de sang', '0,8 g d’alcool par litre de sang'], e: 'Pour un conducteur qui n’est ni en permis probatoire ni en apprentissage, l’infraction commence à 0,50 g par litre de sang, soit 0,25 mg par litre d’air expiré.' },
      { s: 'Lors d’un contrôle, on mesure l’alcool dans l’air que vous soufflez. Vous avez le permis depuis dix ans.', q: 'Vous êtes en infraction à partir de :', ok: ['0,25 mg par litre d’air expiré'], ko: ['0,10 mg par litre d’air expiré', '0,50 mg par litre d’air expiré'], e: 'Le seuil général est de 0,25 mg par litre d’air expiré, ce qui correspond à 0,50 g par litre de sang.' },
    ] },
  { notion: 'alcool-probatoire', domaine: 'conducteur', article: 'R234-1', alinea: 'I, 1°', scene: { recette: 'trajet', nuit: true },
    variantes: [
      { s: 'Vous venez d’obtenir votre permis : vous êtes en période probatoire.', q: 'Vous êtes en infraction à partir d’une alcoolémie de :', ok: ['0,2 g d’alcool par litre de sang'], ko: ['0,5 g d’alcool par litre de sang', '0,8 g d’alcool par litre de sang'], e: 'En permis probatoire, en apprentissage ou au volant d’un transport en commun, le seuil est abaissé à 0,20 g par litre de sang (0,10 mg par litre d’air expiré). En pratique, un seul verre peut suffire à le dépasser.' },
    ] },
  { notion: 'telephone', domaine: 'conducteur', article: 'R412-6-1', scene: { recette: 'trajet' },
    variantes: [
      { s: 'Votre téléphone sonne pendant que vous roulez.', q: 'Qu’est-ce qui est interdit, véhicule en circulation ?', ok: ['téléphoner en tenant le téléphone en main', 'porter une oreillette ou un écouteur'], ko: ['écouter la radio du véhicule'], e: 'L’usage d’un téléphone tenu en main est interdit, comme le port à l’oreille de tout dispositif qui émet du son (sauf appareil correcteur de surdité). Le mieux reste de s’arrêter dans un endroit autorisé pour répondre.' },
    ] },
  { notion: 'ecran', domaine: 'conducteur', article: 'R412-6-2', scene: { recette: 'trajet' },
    variantes: [
      { s: 'Un écran est fixé dans votre champ de vision, près du volant.', q: 'Cet écran peut rester allumé pendant que vous roulez s’il sert à :', ok: ['la navigation (guidage GPS)'], ko: ['regarder une vidéo', 'lire vos messages'], e: 'Un appareil à écran en fonctionnement dans le champ de vision du conducteur est interdit, sauf s’il s’agit d’une aide à la conduite ou à la navigation. L’infraction est une contravention de 5e classe et l’appareil est saisi.' },
    ] },
  { notion: 'temps-reaction', domaine: 'conducteur', reference: 'Ordre de grandeur pédagogique : temps de réaction d’environ 1 seconde', source: 'https://www.digischool.fr/articles/auto/securite-routiere/distance-de-freinage-distance-arret-calcul/', verifier: true,
    scene: { recette: 'trajet', site: 'campagne' },
    variantes: [
      { s: 'Vous roulez à 90 km/h. Un obstacle surgit.', q: 'Pendant votre temps de réaction (environ une seconde), avant même de freiner, vous parcourez environ :', ok: ['25 mètres'], ko: ['9 mètres', '50 mètres'], e: 'À 90 km/h, on parcourt 25 mètres par seconde (90 ÷ 3,6). Pendant ce temps de réaction, la voiture avance encore à pleine vitesse ; la distance d’arrêt est la somme de cette distance et de la distance de freinage.' },
      { s: 'Vous roulez à 50 km/h en ville.', q: 'Pendant une seconde de réaction, vous parcourez environ :', ok: ['14 mètres'], ko: ['5 mètres', '28 mètres'], e: 'À 50 km/h, on parcourt environ 14 mètres par seconde (50 ÷ 3,6). C’est autant de distance perdue avant de commencer à freiner.' },
    ] },
  { notion: 'arret-mouille', domaine: 'conducteur', reference: 'Distance d’arrêt = distance de réaction + distance de freinage (ordres de grandeur pédagogiques)', source: 'https://www.digischool.fr/articles/auto/securite-routiere/distance-de-freinage-distance-arret-calcul/', verifier: true,
    scene: { recette: 'trajet', site: 'campagne', meteo: 'pluie' },
    variantes: [
      { s: 'Il pleut. La chaussée est mouillée.', q: 'Par rapport à une chaussée sèche, ma distance de freinage est :', ok: ['plus longue'], ko: ['identique', 'plus courte'], e: 'Sur chaussée mouillée, les pneus adhèrent moins : la distance de freinage s’allonge nettement (les cours retiennent souvent un ordre de grandeur d’une fois et demie). J’augmente donc mes distances et je réduis ma vitesse.' },
      { s: 'Vous voulez estimer la distance nécessaire pour vous arrêter.', q: 'La distance d’arrêt est égale à :', ok: ['la distance parcourue pendant le temps de réaction plus la distance de freinage'], ko: ['la seule distance de freinage', 'la distance de sécurité de deux secondes'], e: 'Avant de freiner, il faut percevoir, décider et appuyer sur la pédale : c’est le temps de réaction. La distance d’arrêt additionne la distance parcourue pendant ce temps et la distance de freinage.' },
    ] },

  // ——————————————————— Notions diverses (permis à points, documents) ———————————————————
  { notion: 'points-initiaux', domaine: 'notions', article: 'R223-1', alinea: 'II', scene: { recette: 'trajet' },
    variantes: [
      { s: 'Vous venez de réussir l’examen du permis B.', q: 'Votre permis probatoire est doté au départ de :', ok: ['6 points'], ko: ['12 points', '8 points'], e: 'À son obtention, le permis compte 6 points. Sans infraction entraînant un retrait de points, il gagne des points chaque année de la période probatoire, jusqu’à 12.' },
    ] },
  { notion: 'probatoire-duree', domaine: 'notions', article: 'L223-1', scene: { recette: 'trajet' },
    variantes: [
      { s: 'Vous avez appris à conduire en auto-école, sans conduite accompagnée, et sans suivre la formation complémentaire post-permis.', q: 'Votre période probatoire dure :', ok: ['3 ans'], ko: ['2 ans', '1 an'], e: 'Le délai probatoire est de trois ans. Il est réduit à deux ans après un apprentissage anticipé de la conduite (conduite accompagnée), et d’un an de plus pour qui suit la formation complémentaire sans commettre d’infraction (article R223-1).' },
      { s: 'Vous avez suivi la conduite accompagnée avant d’obtenir votre permis, mais pas la formation complémentaire post-permis.', q: 'Votre période probatoire dure :', ok: ['2 ans'], ko: ['3 ans', '6 mois'], e: 'Après l’apprentissage anticipé de la conduite, le délai probatoire est réduit à deux ans (au lieu de trois).' },
    ] },
  { notion: 'probatoire-majoration', domaine: 'notions', article: 'R223-1', alinea: 'II', scene: { recette: 'trajet' },
    variantes: [
      { s: 'Vous êtes en permis probatoire, après une formation classique, sans formation complémentaire post-permis, et vous n’avez commis aucune infraction.', q: 'À la fin de chaque année de la période probatoire, votre permis gagne :', ok: ['2 points'], ko: ['1 point', '6 points'], e: 'Sans infraction ayant entraîné un retrait de points, le permis gagne 2 points par an (3 points après une conduite accompagnée), pour atteindre 12 points à la fin de la période probatoire.' },
    ] },
  { notion: 'points-max', domaine: 'notions', article: 'R223-1', alinea: 'I', scene: { recette: 'trajet' },
    variantes: [
      { s: 'Vous avez terminé votre période probatoire sans infraction.', q: 'Le nombre maximal de points d’un permis est de :', ok: ['12 points'], ko: ['10 points', '15 points'], e: 'Le permis de conduire est affecté d’un nombre maximal de douze points. Quand le nombre de points devient nul, le permis perd sa validité.' },
    ] },
  { notion: 'points-feu-rouge', domaine: 'notions', article: 'R412-30', scene: { recette: 'feu-rouge' },
    variantes: [
      { s: 'Un conducteur franchit un feu rouge.', q: 'Combien de points perd-il ?', ok: ['4 points'], ko: ['1 point', '2 points', '6 points'], e: 'Ne pas marquer l’arrêt au feu rouge est une contravention de 4e classe qui entraîne le retrait de 4 points et peut conduire à une suspension du permis.' },
    ] },
  { notion: 'points-pieton', domaine: 'notions', article: 'R415-11', scene: { recette: 'trajet', site: 'rue' },
    variantes: [
      { s: 'Un conducteur ne laisse pas passer un piéton engagé sur un passage piéton.', q: 'Combien de points perd-il ?', ok: ['6 points'], ko: ['2 points', '3 points', '4 points'], e: 'Ne pas céder le passage à un piéton qui traverse régulièrement (ou qui manifeste clairement l’intention de le faire) coûte 6 points.' },
    ] },
  { notion: 'points-ceinture', domaine: 'notions', article: 'R412-1', alinea: 'IV', scene: { recette: 'atelier' },
    variantes: [
      { s: 'Un conducteur roule sans attacher sa ceinture de sécurité.', q: 'Combien de points perd-il ?', ok: ['3 points'], ko: ['1 point', '6 points'], e: 'Le défaut de port de la ceinture par le conducteur entraîne de plein droit le retrait de 3 points.' },
    ] },
  { notion: 'controle-technique', domaine: 'notions', article: 'R323-22', alinea: 'I', scene: { recette: 'atelier', capot: true },
    variantes: [
      { s: 'Vous avez acheté une voiture neuve.', q: 'Le premier contrôle technique doit être fait :', ok: ['dans les six mois qui précèdent ses 4 ans'], ko: ['au bout d’un an', 'à 10 ans'], e: 'Une voiture particulière passe son premier contrôle technique dans les six mois précédant les quatre ans de sa première mise en circulation, puis tous les deux ans.' },
      { s: 'Votre voiture a déjà passé son premier contrôle technique.', q: 'Elle doit ensuite le repasser :', ok: ['tous les deux ans'], ko: ['tous les ans', 'tous les cinq ans'], e: 'Après le premier contrôle, le contrôle technique périodique d’une voiture particulière est renouvelé tous les deux ans.' },
    ] },

  // ——————————————————— Mécanique et équipements ———————————————————
  { notion: 'pneu-profondeur', domaine: 'mecanique', article: 'R314-1', verifier: true, scene: { recette: 'atelier', piece: 'pneus' },
    variantes: [
      { s: 'Vous contrôlez l’usure de vos pneus.', q: 'La profondeur des sculptures ne doit pas descendre sous :', ok: ['1,6 mm'], ko: ['0,5 mm', '4 mm'], e: 'Le Code impose des sculptures apparentes sur toute la bande de roulement et renvoie à un arrêté pour les détails : la profondeur minimale retenue est de 1,6 mm, repérée par les témoins d’usure moulés dans les rainures.' },
    ] },
  { notion: 'pneu-toile', domaine: 'mecanique', article: 'R314-1', scene: { recette: 'atelier', piece: 'pneus' },
    variantes: [
      OUI_NON('Non', 'Aucune toile ne doit apparaître, ni en surface ni au fond des sculptures, et les flancs ne doivent pas présenter de déchirure profonde. Rouler ainsi expose à une amende et à l’immobilisation du véhicule.', 'La toile d’un pneu apparaît au fond des sculptures.', 'Puis-je continuer à rouler avec ce pneu ?'),
    ] },
  { notion: 'pneu-pression', domaine: 'mecanique', reference: 'ADEME — contrôle de la pression des pneus à froid', source: 'https://agirpourlatransition.ademe.fr/particuliers/economiser/carburant/ecoconduite-solution-consommer-moins-carburant-limiter-emissions-co2', scene: { recette: 'atelier', piece: 'pneus' },
    variantes: [
      { s: 'Vous allez vérifier la pression de vos pneus à la station.', q: 'La pression se contrôle de préférence :', ok: ['pneus froids, de préférence avant de rouler'], ko: ['après un long trajet sur autoroute', 'pneus chauds, pour qu’ils soient à leur pression de route'], e: 'La pression se mesure à froid (l’ADEME précise : voiture à l’arrêt depuis plus de deux heures) : un pneu chaud affiche une pression plus élevée et fausse le réglage. On suit les valeurs indiquées par le constructeur, au moins une fois par mois.' },
    ] },
  { notion: 'voyant-rouge', domaine: 'mecanique', reference: 'Code couleur des voyants : rouge = alerte, arrêt nécessaire', source: 'https://public.codesrousseau.fr/code-de-la-route/reviser-le-code/voyants-de-voiture-feux/', image: { voyant: 'temperature' }, scene: { recette: 'trajet' },
    variantes: [
      { s: 'Ce voyant rouge s’allume pendant que vous roulez.', q: 'Que faites-vous ?', ok: ['je m’arrête dès que possible, dans un endroit sûr'], ko: ['je termine mon trajet puis je consulte un garage', 'j’accélère pour rejoindre vite la prochaine ville'], e: 'Un voyant rouge signale une alerte : en général, il faut s’arrêter rapidement. Celui-ci indique une température trop élevée du liquide de refroidissement : continuer peut casser le moteur.' },
    ] },
  { notion: 'voyant-huile', domaine: 'mecanique', reference: 'Voyant de pression d’huile (rouge)', source: 'https://public.codesrousseau.fr/code-de-la-route/reviser-le-code/voyants-de-voiture-feux/', image: { voyant: 'huile' }, scene: { recette: 'atelier', capot: true },
    variantes: [
      { s: 'Ce voyant rouge s’allume moteur en marche.', q: 'Il signale un problème de :', ok: ['pression d’huile du moteur'], ko: ['niveau de carburant', 'liquide de lave-glace'], e: 'C’est le voyant de pression d’huile. Je m’arrête, je coupe le moteur et je vérifie le niveau d’huile. S’il se rallume, le moteur risque la casse : il faut faire appel à un dépanneur.' },
    ] },
  { notion: 'voyant-batterie', domaine: 'mecanique', reference: 'Voyant de charge de la batterie (rouge)', source: 'https://public.codesrousseau.fr/code-de-la-route/reviser-le-code/voyants-de-voiture-feux/', image: { voyant: 'batterie' }, scene: { recette: 'atelier', capot: true },
    variantes: [
      { s: 'Ce voyant rouge reste allumé en roulant.', q: 'Il indique que :', ok: ['la batterie n’est plus rechargée correctement'], ko: ['les feux de route sont allumés', 'la ceinture du passager n’est pas bouclée'], e: 'C’est le voyant de charge : le circuit qui recharge la batterie (alternateur, régulateur) ne fonctionne plus. La voiture risque de ne plus redémarrer au prochain arrêt : direction le garage.' },
    ] },
  { notion: 'voyant-orange', domaine: 'mecanique', reference: 'Code couleur des voyants : orange = anomalie à faire vérifier', source: 'https://public.codesrousseau.fr/code-de-la-route/reviser-le-code/voyants-de-voiture-feux/', image: { voyant: 'moteur' }, scene: { recette: 'trajet' },
    variantes: [
      { s: 'Ce voyant orange s’allume au tableau de bord.', q: 'Un voyant orange signale en général :', ok: ['une anomalie à faire vérifier rapidement'], ko: ['un simple témoin de fonctionnement, sans conséquence', 'un danger qui impose de couper le moteur sur-le-champ'], e: 'Rouge : alerte, arrêt nécessaire. Orange : anomalie à faire contrôler sans tarder. Vert ou bleu : simple information sur un équipement en marche, comme l’éclairage.' },
    ] },
  { notion: 'voyant-route', domaine: 'mecanique', reference: 'Voyant bleu : feux de route allumés', source: 'https://public.codesrousseau.fr/code-de-la-route/reviser-le-code/voyants-de-voiture-feux/', image: { voyant: 'route' }, scene: { recette: 'trajet', nuit: true, site: 'campagne', feux: 'route' },
    variantes: [
      { s: 'Ce voyant bleu est allumé au tableau de bord.', q: 'Il indique que sont allumés :', ok: ['les feux de route'], ko: ['les feux de croisement', 'les feux de brouillard avant'], e: 'Le voyant bleu est celui des feux de route (« pleins phares »). Le voyant des feux de croisement est vert.' },
    ] },
  { notion: 'voyant-croisement', domaine: 'mecanique', reference: 'Voyant vert : feux de croisement allumés', source: 'https://public.codesrousseau.fr/code-de-la-route/reviser-le-code/voyants-de-voiture-feux/', image: { voyant: 'croisement' }, scene: { recette: 'trajet', nuit: true, feux: 'croisement' },
    variantes: [
      { s: 'Ce voyant vert est allumé au tableau de bord.', q: 'Il indique que sont allumés :', ok: ['les feux de croisement'], ko: ['les feux de route', 'les feux de brouillard arrière'], e: 'Le voyant vert, avec des rayons inclinés vers le bas, est celui des feux de croisement. Les feux de route ont un voyant bleu.' },
    ] },
  { notion: 'voyant-brouillard-ar', domaine: 'mecanique', reference: 'Voyant orange : feux de brouillard arrière', source: 'https://public.codesrousseau.fr/code-de-la-route/reviser-le-code/voyants-de-voiture-feux/', image: { voyant: 'brouillard-ar' }, scene: { recette: 'trajet', meteo: 'brouillard', feux: 'brouillard' },
    variantes: [
      { s: 'Ce voyant orange est allumé.', q: 'Il indique que sont allumés :', ok: ['les feux de brouillard arrière'], ko: ['les feux de brouillard avant', 'les feux de détresse'], e: 'Ce voyant orange signale les feux de brouillard arrière. Ils éblouissent ceux qui suivent : on ne les utilise qu’en cas de brouillard ou de chute de neige, et on les éteint dès que la visibilité revient.' },
    ] },
  { notion: 'piece-batterie', domaine: 'mecanique', reference: 'Notion de mécanique (repérage sur la maquette du jeu)', verifier: true, scene: { recette: 'atelier', capot: true, etiquettes: ['batterie', 'huile', 'refroidissement'] },
    variantes: [
      { s: 'Le capot est ouvert. Trois éléments sont repérés par les lettres A, B et C.', q: 'Où se trouve la batterie ?', cible: 'batterie', e: 'La batterie est le bloc noir avec ses deux bornes, + (rouge) et −. Elle alimente le démarreur et l’équipement électrique ; l’alternateur la recharge quand le moteur tourne.' },
    ] },
  { notion: 'piece-huile', domaine: 'mecanique', reference: 'Notion de mécanique (repérage sur la maquette du jeu)', verifier: true, scene: { recette: 'atelier', capot: true, etiquettes: ['huile', 'lave-glace', 'batterie'] },
    variantes: [
      { s: 'Le capot est ouvert. Trois éléments sont repérés par les lettres A, B et C.', q: 'Pour contrôler le niveau d’huile du moteur, j’utilise :', cible: 'huile', e: 'Le niveau d’huile se lit sur la jauge (poignée souvent jaune), moteur arrêté, voiture à plat : il doit se situer entre les repères mini et maxi.' },
    ] },
  { notion: 'piece-refroidissement', domaine: 'mecanique', reference: 'Notion de mécanique (repérage sur la maquette du jeu)', verifier: true, scene: { recette: 'atelier', capot: true, etiquettes: ['refroidissement', 'lave-glace', 'huile'] },
    variantes: [
      { s: 'Le capot est ouvert. Trois éléments sont repérés par les lettres A, B et C.', q: 'Où se contrôle le niveau du liquide de refroidissement ?', cible: 'refroidissement', e: 'Le liquide de refroidissement se contrôle sur le vase d’expansion (réservoir translucide avec repères mini et maxi), moteur froid : bouchon ouvert à chaud, le liquide sous pression peut brûler.' },
    ] },

  // ——————————————————— Prendre et quitter son véhicule ———————————————————
  { notion: 'gilet-portee', domaine: 'vehicule', article: 'R416-19', alinea: 'II', scene: { recette: 'atelier' },
    variantes: [
      { s: 'Vous rangez votre gilet de haute visibilité avant de partir.', q: 'En circulation, ce gilet doit se trouver :', ok: ['à portée de main du conducteur'], ko: ['dans le coffre, sous les bagages', 'à la maison, il n’est utile qu’en cas de panne'], e: 'Le conducteur doit disposer du gilet à portée de main : il doit pouvoir l’enfiler avant de sortir du véhicule.' },
    ] },
  { notion: 'gilet-sortie', domaine: 'vehicule', article: 'R416-19', scene: { recette: 'panne', surChaussee: true },
    variantes: [
      { s: 'Votre voiture tombe en panne : elle est immobilisée en partie sur la chaussée et gêne la circulation.', q: 'Avant de sortir de la voiture, je :', ok: ['revêts mon gilet de haute visibilité', 'allume mes feux de détresse'], ko: ['retire ma ceinture et descends côté chaussée pour voir le moteur'], e: 'Quand je quitte un véhicule immobilisé sur la chaussée ou ses abords après un arrêt d’urgence, je revêts le gilet (II). Comme la voiture constitue ici un danger, je la signale avec les feux de détresse et le triangle (I). Je descends de préférence côté accotement.' },
    ] },
  { notion: 'triangle', domaine: 'vehicule', article: 'R416-19', alinea: 'I', scene: { recette: 'panne', triangle: true },
    variantes: [
      { s: 'Votre voiture est immobilisée sur la chaussée juste après un virage : elle constitue un danger.', q: 'Pour la présignaler, j’utilise :', ok: ['les feux de détresse', 'le triangle de présignalisation'], ko: ['les feux de brouillard arrière'], e: 'Un véhicule immobilisé qui constitue un danger (près d’un virage, d’une intersection, d’un sommet de côte…) se présignale avec les feux de détresse et le triangle, que le conducteur doit avoir à bord.' },
    ] },
  { notion: 'portiere', domaine: 'vehicule', article: 'R417-7', scene: { recette: 'stationne', cycliste: true },
    variantes: [
      { s: 'Vous êtes garé le long du trottoir. Un cycliste arrive derrière vous.', q: 'Vous voulez ouvrir votre portière côté chaussée :', ok: ['j’attends que le cycliste soit passé'], ko: ['j’ouvre rapidement, il me verra', 'j’ouvre en grand pour qu’il s’écarte'], e: 'Il est interdit à tout occupant d’ouvrir une portière quand cela constitue un danger pour lui ou pour les autres usagers. Je regarde dans le rétroviseur et par-dessus l’épaule avant d’ouvrir.' },
    ] },
  { notion: 'stationner-cote', domaine: 'vehicule', article: 'R417-1', alinea: 'I, 2°', scene: { recette: 'stationne' },
    variantes: [
      { s: 'En agglomération, vous voulez vous garer dans une rue à double sens, sans places matérialisées ni signalisation particulière.', q: 'Je me gare :', ok: ['du côté droit de la chaussée, dans mon sens de circulation'], ko: ['du côté gauche, si la place y est plus grande', 'au milieu de la chaussée, feux de détresse allumés'], e: 'Sur une chaussée à double sens, en agglomération, l’arrêt et le stationnement se font sur le côté droit, sauf décision contraire de l’autorité de police.' },
    ] },
  { notion: 'detresse-lent', domaine: 'vehicule', article: 'R416-18', scene: { recette: 'trajet', site: 'autoroute', detresse: true },
    variantes: [
      { s: 'Un incident vous oblige à rouler momentanément beaucoup plus lentement que la circulation.', q: 'Pour avertir ceux qui vous suivent, j’allume :', ok: ['mes feux de détresse'], ko: ['mes feux de brouillard arrière', 'mes feux de route'], e: 'Un conducteur contraint de circuler momentanément à allure fortement réduite doit avertir les usagers qu’il risque de surprendre avec ses feux de détresse.' },
    ] },
  { notion: 'quitter-precautions', domaine: 'vehicule', article: 'R417-8', scene: { recette: 'stationne' },
    variantes: [
      { s: 'Vous venez de vous garer en pente et vous partez faire une course.', q: 'Avant de vous éloigner de votre voiture :', ok: ['je serre le frein de stationnement et je prends les précautions utiles contre tout risque d’accident'], ko: ['je laisse le moteur tourner pour repartir plus vite', 'je laisse une vitre ouverte pour aérer, rien d’autre n’est utile'], e: 'Le conducteur ne doit s’éloigner de son véhicule qu’après avoir pris les précautions utiles pour éviter tout accident du fait de son absence. En pratique, on conseille notamment de serrer le frein de stationnement, de couper le moteur et, en pente, de braquer les roues vers le trottoir.' },
    ] },

  // ——————————————————— Sécurité du passager et du véhicule ———————————————————
  { notion: 'ceinture-arriere', domaine: 'securite', article: 'R412-1', alinea: 'I', scene: { recette: 'atelier' },
    variantes: [
      OUI_NON('Oui', 'Tout conducteur ou passager d’un véhicule à moteur doit porter la ceinture dès que son siège en est équipé, à l’avant comme à l’arrière.', 'Un adulte s’installe à l’arrière pour un court trajet en ville.', 'Doit-il attacher sa ceinture ?'),
    ] },
  { notion: 'enfant-siege', domaine: 'securite', article: 'R412-2', alinea: 'II', scene: { recette: 'atelier' },
    variantes: [
      { s: 'Vous transportez un enfant de 7 ans dont la morphologie ne convient pas encore à la ceinture seule.', q: 'Il doit être installé :', ok: ['dans un système de retenue homologué adapté à sa taille et à son poids'], ko: ['sur les genoux d’un adulte attaché', 'avec la ceinture adulte seule, s’il est à l’arrière'], e: 'Le conducteur doit s’assurer que tout enfant de moins de dix ans est retenu par un système homologué adapté à sa morphologie et à son poids (sauf exceptions, par exemple si sa morphologie permet déjà la ceinture).' },
    ] },
  { notion: 'enfant-airbag', domaine: 'securite', article: 'R412-3', alinea: 'I, 1°', scene: { recette: 'atelier' },
    variantes: [
      { s: 'Vous installez un bébé à l’avant, dans un siège dos à la route prévu pour cette place.', q: 'Je dois obligatoirement :', ok: ['désactiver le coussin gonflable (airbag) frontal du passager'], ko: ['avancer le siège au maximum', 'laisser l’airbag actif pour mieux le protéger'], e: 'Un enfant de moins de dix ans peut voyager à l’avant face à l’arrière, dans un système homologué conçu pour cette place, à condition que l’airbag frontal soit désactivé : en se gonflant, il heurterait violemment le siège.' },
    ] },
  { notion: 'passager-mineur', domaine: 'securite', article: 'R412-2', alinea: 'I', scene: { recette: 'trajet' },
    variantes: [
      { s: 'Vous emmenez un passager de 16 ans. Il ne veut pas boucler sa ceinture.', q: 'Qui doit s’assurer qu’il est attaché ?', ok: ['moi, le conducteur'], ko: ['lui seul', 'ses parents, même absents'], e: 'Le conducteur d’une voiture doit s’assurer que tout passager de moins de dix-huit ans est maintenu par une ceinture ou un système de retenue homologué.' },
    ] },
  { notion: 'un-par-siege', domaine: 'securite', article: 'R412-1-1', scene: { recette: 'atelier' },
    variantes: [
      { s: 'Votre voiture compte cinq places assises sur sa carte grise. Six amis veulent monter.', q: 'Je peux transporter :', ok: ['cinq personnes au plus, conducteur compris, une par siège'], ko: ['six personnes, en serrant deux enfants sur un siège', 'autant de personnes que de ceintures disponibles, plus une'], e: 'Les passagers sont transportés sur des sièges, dans la limite du nombre de places assises inscrit sur le certificat d’immatriculation, et chaque siège n’accueille qu’une seule personne.' },
    ] },
  { notion: 'abs', domaine: 'securite', reference: 'Aides à la conduite : ABS (antiblocage des roues)', source: 'https://codedelaroute.io/blog/aides-au-freinage/', scene: { recette: 'trajet', meteo: 'pluie' },
    variantes: [
      { s: 'Votre voiture est équipée de l’ABS. Vous freinez fort en urgence.', q: 'L’ABS :', ok: ['empêche les roues de se bloquer', 'me permet de garder le contrôle de la direction pendant le freinage'], ko: ['me dispense de garder mes distances de sécurité'], e: 'L’ABS évite le blocage des roues lors d’un freinage brusque : je peux continuer à diriger la voiture pour éviter l’obstacle. Il ne remplace ni les distances de sécurité ni une vitesse adaptée.' },
    ] },
  { notion: 'esp', domaine: 'securite', reference: 'Aides à la conduite : ESP (correcteur électronique de trajectoire)', source: 'https://codedelaroute.io/blog/aides-au-freinage/', scene: { recette: 'trajet', site: 'campagne' },
    variantes: [
      { s: 'Dans un virage, votre voiture commence à déraper. Elle est équipée de l’ESP.', q: 'L’ESP agit en :', ok: ['freinant une ou plusieurs roues pour corriger la trajectoire'], ko: ['gonflant les airbags', 'allumant automatiquement les feux de détresse'], e: 'L’ESP détecte un écart entre la direction donnée au volant et la trajectoire réelle ; il freine une roue et peut réduire la puissance du moteur pour remettre la voiture dans l’axe.' },
    ] },
  { notion: 'afu', domaine: 'securite', reference: 'Aides à la conduite : AFU (aide au freinage d’urgence)', source: 'https://codedelaroute.io/blog/aides-au-freinage/', scene: { recette: 'trajet' },
    variantes: [
      { s: 'Votre voiture est équipée de l’AFU.', q: 'Ce système :', ok: ['amplifie la force de freinage quand il détecte un freinage d’urgence'], ko: ['freine à ma place dans les virages', 'empêche le moteur de caler'], e: 'L’aide au freinage d’urgence reconnaît un freinage d’urgence et augmente la pression de freinage, ce qui réduit la distance de freinage. Elle fonctionne avec l’ABS.' },
    ] },

  // ——————————————————— Premiers secours ———————————————————
  { notion: 'pas-ordre', domaine: 'secours', reference: 'Conduite à tenir : Protéger, Alerter, Secourir', source: 'https://www.ornikar.com/code/cours/securite/premiers-secours', scene: { recette: 'accident' },
    variantes: [
      { s: 'Vous êtes le premier témoin d’un accident.', q: 'Dans quel ordre agissez-vous ?', ok: ['protéger, alerter, secourir'], ko: ['secourir, alerter, protéger', 'alerter, secourir, protéger'], e: 'On protège d’abord (pour éviter un sur-accident), on alerte ensuite les secours, puis on secourt les victimes en attendant leur arrivée.' },
    ] },
  { notion: 'proteger', domaine: 'secours', reference: 'Protéger les lieux d’un accident', source: 'https://www.ornikar.com/code/cours/securite/premiers-secours', scene: { recette: 'accident' },
    variantes: [
      { s: 'Vous arrivez sur un accident qui vient de se produire.', q: 'Pour protéger les lieux, je :', ok: ['me gare après l’accident, feux de détresse allumés', 'enfile mon gilet de haute visibilité avant de sortir'], ko: ['m’arrête au milieu de la chaussée, juste avant les véhicules accidentés'], e: 'Je me gare au-delà de l’accident, hors de la chaussée si possible, feux de détresse allumés. Je porte le gilet et je fais signaler le danger en amont pour éviter un sur-accident.' },
    ] },
  { notion: 'numero-samu', domaine: 'secours', reference: 'Numéros d’urgence (Service-public.fr)', source: 'https://www.service-public.gouv.fr/particuliers/actualites/A17758?lang=fr', scene: { recette: 'accident' },
    variantes: [
      { s: 'Une victime est blessée et a besoin d’une aide médicale urgente.', q: 'J’appelle le :', ok: ['15 (SAMU)'], ko: ['17', '115'], e: 'Le 15 est le numéro du SAMU (aide médicale urgente). Le 18 joint les sapeurs-pompiers, le 17 la police ou la gendarmerie, et le 112 est le numéro d’urgence européen.' },
      { s: 'Un véhicule accidenté commence à fumer.', q: 'Pour joindre les sapeurs-pompiers, j’appelle le :', ok: ['18'], ko: ['15', '17'], e: 'Le 18 joint les sapeurs-pompiers. Le 112, numéro d’urgence européen, fonctionne aussi depuis un portable.' },
    ] },
  { notion: 'numero-112', domaine: 'secours', reference: 'Numéros d’urgence (Service-public.fr, Santé.fr)', source: 'https://sante.fr/en-cas-durgence-conseils-et-numeros-utiles', scene: { recette: 'accident' },
    variantes: [
      { s: 'Vous êtes à l’étranger, dans un pays de l’Union européenne, et vous assistez à un accident.', q: 'Le numéro d’urgence valable dans toute l’Europe est le :', ok: ['112'], ko: ['911', '118'], e: 'Le 112 est le numéro d’appel d’urgence européen, gratuit, accessible depuis un téléphone fixe ou portable.' },
      { s: 'Une personne sourde ou malentendante doit alerter les secours.', q: 'Elle peut utiliser le :', ok: ['114 (par SMS, visio ou tchat)'], ko: ['117', '15 uniquement par appel vocal'], e: 'Le 114 est le numéro d’urgence des personnes sourdes ou malentendantes ; il est joignable par visiophonie, tchat, SMS ou fax, 24 h sur 24 (Santé.fr).' },
    ] },
  { notion: 'alerter-infos', domaine: 'secours', reference: 'Alerter les secours : informations à donner', source: 'https://www.ornikar.com/code/cours/securite/premiers-secours', scene: { recette: 'accident' },
    variantes: [
      { s: 'Vous appelez les secours après un accident.', q: 'Je leur indique :', ok: ['le lieu exact de l’accident', 'le nombre de victimes et leur état apparent'], ko: ['le nom de l’assureur des véhicules'], e: 'Pour que les secours arrivent vite et équipés, je donne le lieu précis, la nature de l’accident, le nombre de victimes et leur état, et un numéro où me rappeler. Je ne raccroche que lorsqu’on me le dit.' },
    ] },
  { notion: 'ne-pas-deplacer', domaine: 'secours', reference: 'Secourir : ne pas déplacer une victime sauf danger', source: 'https://www.ornikar.com/code/cours/securite/premiers-secours', scene: { recette: 'accident' },
    variantes: [
      { s: 'Une victime est assise dans sa voiture, consciente. Il n’y a ni fumée ni autre danger.', q: 'Je la sors de la voiture :', ok: ['non, je ne la déplace pas'], ko: ['oui, pour l’allonger sur le bas-côté', 'oui, pour la conduire moi-même à l’hôpital'], e: 'On ne déplace pas une victime, sauf danger réel et immédiat (incendie, risque de noyade, véhicule exposé à un nouveau choc) : un mouvement peut aggraver une lésion de la colonne vertébrale.' },
    ] },
  { notion: 'casque', domaine: 'secours', reference: 'Secourir un motard : ne pas retirer le casque', source: 'https://mobiliteclub.fr/wp-content/uploads/2026/03/eurotest-premiers-secours-conseils.pdf', scene: { recette: 'accident', moto: true },
    variantes: [
      OUI_NON('Non', 'On ne retire pas le casque d’un motard blessé : le geste peut aggraver une lésion du cou. On peut relever la visière si c’est possible, et attendre les secours.', 'Un motard est tombé. Il est conscient et porte son casque.', 'Je lui retire son casque ?'),
    ] },
  { notion: 'pls', domaine: 'secours', reference: 'Victime inconsciente qui respire : position latérale de sécurité', source: 'https://mobiliteclub.fr/wp-content/uploads/2026/03/eurotest-premiers-secours-conseils.pdf', scene: { recette: 'accident' },
    variantes: [
      { s: 'Une victime est inconsciente, mais elle respire. Les secours sont prévenus.', q: 'Je la place :', ok: ['sur le côté, en position latérale de sécurité'], ko: ['sur le dos, jambes surélevées', 'assise contre un mur'], e: 'Une victime inconsciente qui respire ne doit pas rester sur le dos : on la met sur le côté (position latérale de sécurité) pour garder ses voies respiratoires libres, et on surveille sa respiration.' },
    ] },
  { notion: 'massage', domaine: 'secours', reference: 'Victime qui ne respire pas : massage cardiaque et défibrillateur', source: 'https://mobiliteclub.fr/wp-content/uploads/2026/03/eurotest-premiers-secours-conseils.pdf', scene: { recette: 'accident' },
    variantes: [
      { s: 'Une victime est inconsciente et ne respire pas. Les secours sont appelés.', q: 'Que faites-vous ?', ok: ['je commence un massage cardiaque', 'je fais chercher un défibrillateur'], ko: ['je la mets en position latérale de sécurité et j’attends'], e: 'Sans respiration, chaque minute compte : massage cardiaque (compressions au centre de la poitrine) sans s’arrêter jusqu’à l’arrivée des secours, et défibrillateur dès qu’il est disponible : il s’utilise sans formation, en suivant ses instructions.' },
    ] },
  { notion: 'hemorragie', domaine: 'secours', reference: 'Saignement abondant : compression de la plaie', source: 'https://mobiliteclub.fr/wp-content/uploads/2026/03/eurotest-premiers-secours-conseils.pdf', scene: { recette: 'accident' },
    variantes: [
      { s: 'Une victime saigne abondamment du bras.', q: 'J’arrête le saignement en :', ok: ['appuyant fortement sur la plaie, avec un tissu propre si possible'], ko: ['lui donnant à boire', 'surélevant sa tête'], e: 'Face à un saignement abondant, on comprime directement la plaie (doigts ou paume, avec un tissu propre si possible) et on maintient l’appui jusqu’à l’arrivée des secours.' },
    ] },

  // ——————————————————— Environnement ———————————————————
  { notion: 'eco-pression', domaine: 'environnement', reference: 'ADEME — écoconduite : pression des pneus', source: 'https://agirpourlatransition.ademe.fr/particuliers/economiser/carburant/ecoconduite-solution-consommer-moins-carburant-limiter-emissions-co2', scene: { recette: 'atelier', piece: 'pneus' },
    variantes: [
      { s: 'Vos pneus sont sous-gonflés de quelques dixièmes de bar.', q: 'Conséquences :', ok: ['la consommation de carburant augmente', 'les pneus s’usent plus vite'], ko: ['la voiture freine mieux'], e: 'L’ADEME conseille de vérifier la pression au moins une fois par mois, à froid : un sous-gonflage de 0,5 bar augmente la consommation d’environ 2,4 % et use les pneus plus vite.' },
    ] },
  { notion: 'eco-coffre', domaine: 'environnement', reference: 'ADEME — écoconduite : coffre de toit et porte-vélos', source: 'https://agirpourlatransition.ademe.fr/particuliers/economiser/carburant/ecoconduite-solution-consommer-moins-carburant-limiter-emissions-co2', scene: { recette: 'trajet', site: 'autoroute', coffre: true },
    variantes: [
      { s: 'Vous avez laissé votre coffre de toit vide après les vacances.', q: 'Pour moins consommer :', ok: ['je le démonte quand je ne m’en sers pas'], ko: ['je le laisse, il ne change rien à la consommation', 'je roule plus vite pour compenser'], e: 'Coffre de toit, galerie ou porte-vélos augmentent la résistance à l’air : l’ADEME estime le surcoût à 10 à 20 % de consommation. On les retire dès qu’ils ne servent plus.' },
    ] },
  { notion: 'eco-rapports', domaine: 'environnement', reference: 'ADEME — écoconduite : changer de rapport tôt', source: 'https://agirpourlatransition.ademe.fr/particuliers/economiser/carburant/ecoconduite-solution-consommer-moins-carburant-limiter-emissions-co2', scene: { recette: 'trajet' },
    variantes: [
      { s: 'Vous accélérez progressivement après un carrefour.', q: 'Pour limiter la consommation, je passe le rapport supérieur :', ok: ['tôt, avant que le moteur tourne à haut régime'], ko: ['le plus tard possible, moteur dans les tours', 'seulement quand le moteur fait du bruit'], e: 'Faire tourner le moteur à haut régime peut augmenter la consommation jusqu’à 20 % selon l’ADEME : on monte les rapports tôt, en souplesse.' },
    ] },
  { notion: 'eco-moteur', domaine: 'environnement', reference: 'ADEME — écoconduite : couper le moteur à l’arrêt', source: 'https://agirpourlatransition.ademe.fr/particuliers/economiser/carburant/ecoconduite-solution-consommer-moins-carburant-limiter-emissions-co2', scene: { recette: 'stationne' },
    variantes: [
      { s: 'Vous attendez un passager devant chez lui pendant plusieurs minutes.', q: 'Pour moins polluer, je :', ok: ['coupe le moteur'], ko: ['laisse tourner le moteur pour le garder chaud', 'donne quelques coups d’accélérateur avant de repartir'], e: 'Selon l’ADEME, redémarrer consomme moins que de laisser tourner le moteur plus de dix secondes : à l’arrêt prolongé, on coupe le moteur.' },
    ] },
  { notion: 'eco-clim', domaine: 'environnement', reference: 'ADEME — écoconduite : climatisation', source: 'https://agirpourlatransition.ademe.fr/particuliers/economiser/carburant/ecoconduite-solution-consommer-moins-carburant-limiter-emissions-co2', scene: { recette: 'trajet' },
    variantes: [
      { s: 'Il fait chaud et vous allumez la climatisation.', q: 'La climatisation :', ok: ['augmente la consommation de carburant'], ko: ['n’a aucun effet sur la consommation', 'diminue la consommation'], e: 'La climatisation augmente la consommation de 1 à 7 % selon l’ADEME ; on évite de régler une température trop basse (l’agence conseille au moins 22 °C).' },
    ] },
  { notion: 'eco-anticipation', domaine: 'environnement', reference: 'ADEME — écoconduite : conduite souple', source: 'https://agirpourlatransition.ademe.fr/particuliers/economiser/carburant/ecoconduite-solution-consommer-moins-carburant-limiter-emissions-co2', scene: { recette: 'feu-rouge' },
    variantes: [
      { s: 'Vous voyez au loin un feu passer au rouge.', q: 'La conduite la plus économe consiste à :', ok: ['lever le pied tôt et laisser la voiture ralentir'], ko: ['garder ma vitesse et freiner fort au dernier moment', 'accélérer pour passer avant le rouge'], e: 'Anticiper permet d’utiliser le frein moteur et d’éviter les à-coups : selon l’ADEME, une conduite brusque peut consommer jusqu’à 20 % de plus qu’une conduite souple.' },
    ] },
  { notion: 'eco-vitesse', domaine: 'environnement', reference: 'ADEME — écoconduite : réduire sa vitesse', source: 'https://agirpourlatransition.ademe.fr/particuliers/economiser/carburant/ecoconduite-solution-consommer-moins-carburant-limiter-emissions-co2', scene: { recette: 'trajet', site: 'autoroute' },
    variantes: [
      OUI_NON('Oui', 'Selon l’ADEME, rouler 10 km/h moins vite sur autoroute économise environ 1 à 3 litres sur 500 km, selon le véhicule. Moins de vitesse, c’est aussi moins de bruit et plus de sécurité.', 'Sur autoroute, vous roulez 10 km/h sous la vitesse maximale autorisée.', 'Cela réduit-il votre consommation ?'),
    ] },

  // ——————————————————— Les autres usagers ———————————————————
  { notion: 'vulnerables', domaine: 'usagers', article: 'R412-6', alinea: 'I', scene: { recette: 'trajet', site: 'rue', cycliste: true },
    variantes: [
      { s: 'Vous roulez dans une rue fréquentée par des piétons et des cyclistes.', q: 'Envers les usagers les plus vulnérables, le Code impose :', ok: ['une prudence accrue'], ko: ['l’usage du klaxon pour les prévenir', 'la même attitude qu’envers les automobilistes'], e: 'Tout conducteur doit adopter un comportement prudent et respectueux et faire preuve d’une prudence accrue envers les usagers les plus vulnérables : piétons, cyclistes, utilisateurs d’engins de déplacement…' },
    ] },
  { notion: 'pieton-50m', domaine: 'usagers', article: 'R412-37', scene: { recette: 'trajet', site: 'rue' },
    variantes: [
      { s: 'Un piéton veut traverser. Un passage piéton se trouve à 30 mètres de lui.', q: 'Le piéton est tenu :', ok: ['d’utiliser ce passage'], ko: ['de traverser où il veut, en courant', 'd’attendre qu’un agent l’autorise'], e: 'Les piétons doivent utiliser les passages prévus pour eux lorsqu’il en existe à moins de 50 mètres, et traverser en tenant compte de la distance et de la vitesse des véhicules.' },
    ] },
  { notion: 'cavalier', domaine: 'usagers', article: 'R414-4', alinea: 'IV', scene: { recette: 'trajet', site: 'campagne' },
    variantes: [
      { s: 'Hors agglomération, vous allez dépasser un cavalier.', q: 'Je laisse un écart latéral d’au moins :', ok: ['1,50 m'], ko: ['0,50 m', '1 m'], e: 'Pour dépasser un piéton, un cavalier, un animal, un deux-roues ou un véhicule à traction animale, l’écart latéral est d’au moins 1 m en agglomération et 1,50 m hors agglomération.' },
    ] },
  { notion: 'depasser-droite', domaine: 'circulation', article: 'R414-6', alinea: 'II, 1°', scene: { recette: 'trajet', site: 'rue' },
    variantes: [
      { s: 'Le véhicule devant vous a mis son clignotant gauche et se place pour tourner à gauche.', q: 'Pour le dépasser, je passe :', ok: ['par sa droite'], ko: ['par sa gauche', 'je n’ai jamais le droit de le dépasser'], e: 'Les dépassements se font à gauche, sauf exceptions : on dépasse par la droite un véhicule dont le conducteur a signalé qu’il allait tourner à gauche.' },
    ] },
  { notion: 'depasser-passage-pieton', domaine: 'usagers', article: 'R414-5', scene: { recette: 'trajet', site: 'rue' },
    variantes: [
      { s: 'Vous approchez d’un passage piéton. Une voiture lente roule devant vous.', q: 'Je ne la dépasse qu’après m’être assuré :', ok: ['qu’aucun piéton n’est engagé sur le passage'], ko: ['que la voiture devant ralentit', 'que je dépasse de moins de 10 km/h la vitesse autorisée'], e: 'À l’approche d’un passage piéton, on ne dépasse qu’après s’être assuré qu’aucun piéton n’y est engagé : le véhicule dépassé peut masquer un piéton.' },
    ] },

  // ——————————————————— La route ———————————————————
  { notion: 'autoroute-marche-arriere', domaine: 'route', article: 'R421-6', scene: { recette: 'trajet', site: 'autoroute' },
    variantes: [
      { s: 'Sur autoroute, vous venez de manquer votre sortie.', q: 'Que faites-vous ?', ok: ['je continue jusqu’à la sortie suivante'], ko: ['je recule sur la bande d’arrêt d’urgence', 'je fais demi-tour par une interruption du terre-plein'], e: 'Sur autoroute, la marche arrière et le demi-tour sont interdits en toutes circonstances (4 points). On poursuit jusqu’à la sortie suivante.' },
    ] },
  { notion: 'autoroute-bau', domaine: 'route', article: 'R421-7', scene: { recette: 'trajet', site: 'autoroute' },
    variantes: [
      { s: 'Sur autoroute, vous voulez consulter votre téléphone.', q: 'Je peux m’arrêter sur la bande d’arrêt d’urgence :', ok: ['non, elle est réservée aux cas de nécessité absolue'], ko: ['oui, feux de détresse allumés', 'oui, si l’arrêt dure moins de cinq minutes'], e: 'Sauf nécessité absolue (panne, malaise…), il est interdit de s’arrêter ou de stationner sur les chaussées et les accotements, y compris la bande d’arrêt d’urgence. Pour une pause, on utilise une aire.' },
    ] },
  { notion: 'autoroute-gauche-80', domaine: 'route', article: 'R413-19', scene: { recette: 'trajet', site: 'autoroute', voie: 'gauche' },
    variantes: [
      { s: 'Vous roulez sur la voie la plus à gauche d’une autoroute. Le temps est clair, la circulation fluide.', q: 'Votre vitesse ne doit pas descendre sous :', ok: ['80 km/h'], ko: ['50 km/h', '110 km/h'], e: 'Sur autoroute, quand la circulation est fluide et que la visibilité et l’adhérence sont suffisantes, on ne peut pas circuler sur la voie la plus à gauche à moins de 80 km/h.' },
    ] },
  { notion: 'autoroute-sortie', domaine: 'route', article: 'R421-4', scene: { recette: 'trajet', site: 'autoroute', voie: 'gauche' },
    variantes: [
      { s: 'Sur autoroute, votre sortie, située à droite, est annoncée. Vous êtes sur la voie de gauche.', q: 'Je rejoins la voie de droite :', ok: ['dès l’annonce de la sortie, et au plus tard en atteignant les signaux du début de la bretelle'], ko: ['au dernier moment, en coupant les voies', 'je reste à gauche, la bretelle se prend depuis n’importe quelle voie'], e: 'Aussitôt qu’une bretelle de sortie est annoncée, le conducteur qui veut l’emprunter gagne la voie de droite (ou de gauche si la sortie est à gauche) ; la manœuvre doit être achevée au plus tard au moment où il atteint les signaux placés au début de la bretelle.' },
    ] },
  { notion: 'virage-depassement', domaine: 'route', article: 'R414-11', scene: { recette: 'trajet', site: 'campagne' },
    variantes: [
      { s: 'Sur une route à double sens, vous approchez du sommet d’une côte derrière une voiture lente. Vous ne voyez pas ce qui arrive en face.', q: 'Je la dépasse :', ok: ['non, la visibilité vers l’avant est insuffisante'], ko: ['oui, en klaxonnant', 'oui, si je le fais rapidement'], e: 'Sur une chaussée à double sens, tout dépassement est interdit lorsque la visibilité vers l’avant est insuffisante, notamment dans un virage ou au sommet d’une côte.' },
    ] },
  { notion: 'montagne-croisement', domaine: 'route', article: 'R414-3', alinea: 'I', scene: { recette: 'trajet', site: 'campagne' },
    variantes: [
      { s: 'Sur une route de montagne étroite, vous descendez. Une voiture monte en face ; le croisement est difficile.', q: 'Qui doit s’arrêter le premier ?', ok: ['moi, qui descends'], ko: ['la voiture qui monte', 'le premier qui klaxonne'], e: 'Sur les routes de montagne et à forte pente, quand le croisement est difficile, c’est le véhicule descendant qui doit s’arrêter à temps le premier.' },
    ] },
];

/** Libellé des pièces repérables sur la maquette de voiture (capot ouvert). */
export const PIECES = {
  batterie: 'la batterie',
  huile: 'la jauge d’huile',
  refroidissement: 'le vase d’expansion du liquide de refroidissement',
  'lave-glace': 'le réservoir de lave-glace',
};
