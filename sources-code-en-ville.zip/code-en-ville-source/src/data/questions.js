// Banque de questions — prototype « Priorités ».
// Chaque question est rédigée de façon originale et rattachée à l'article
// du Code de la route (partie réglementaire) qui la fonde.
// Texte de référence : codedelaroute2026.pdf (version du 12 octobre 2026).
//
// Couleurs des véhicules : la voiture du joueur est toujours bleue.

export const THEMES = {
  priorites: 'Intersections et priorités',
  usagers: 'Partage de la route',
  stationnement: 'Arrêt et stationnement',
  vitesse: 'Vitesse',
  depassement: 'Dépassement',
  autoroute: 'Autoroute',
  signalisation: 'Signalisation',
};

// Chapitres du parcours, dans l'ordre du menu
export const CHAPTERS = [
  { id: 'ville', label: 'Carrefours en ville' },
  { id: 'rue', label: 'Rue, vélos et stationnement' },
  { id: 'campagne', label: 'Campagne et forêt' },
  { id: 'autoroute', label: 'Autoroute' },
];

export const QUESTIONS = [
  {
    id: 'priorite-droite-1',
    vue: 'Carrefour en croix sans signalisation. Votre voiture bleue arrive par le sud ; une voiture rouge arrive par l’est, à votre droite.',
    chapter: 'ville',
    theme: 'priorites',
    article: 'R415-5',
    situation: 'Vous continuez tout droit. Il n’y a ni panneau ni feu à cette intersection.',
    question: 'Par rapport à la voiture rouge, je passe :',
    options: [
      { id: 'A', text: 'avant elle' },
      { id: 'B', text: 'après elle' },
    ],
    correct: ['B'],
    explanation:
      'Sans panneau ni feu, la règle par défaut s’applique : on laisse passer le véhicule qui arrive par la droite. La voiture rouge vient de votre droite, elle passe en premier.',
    scene: {
      site: 'intersection',
      signs: [],
      vehicles: [
        { id: 'moi', player: true, from: 'S', action: 'straight' },
        { id: 'rouge', from: 'E', action: 'straight', color: 'rouge' },
      ],
      resolution: [{ go: ['rouge'] }, { wait: 0.9 }, { go: ['moi'] }],
    },
  },
  {
    id: 'stop-1',
    vue: 'Carrefour en croix. Un panneau stop et une ligne continue sont devant votre voiture bleue. Aucune autre voiture.',
    chapter: 'ville',
    theme: 'priorites',
    article: 'R415-6',
    situation: 'Vous arrivez à un stop. Aucun véhicule n’est visible sur la route que vous allez croiser.',
    question: 'À ce stop :',
    options: [
      { id: 'A', text: 'je marque un arrêt complet à la ligne' },
      { id: 'B', text: 'je peux passer sans m’arrêter puisque la route est libre' },
      { id: 'C', text: 'je ne repars qu’après m’être assuré de pouvoir le faire sans danger' },
    ],
    correct: ['A', 'C'],
    explanation:
      'Au stop, l’arrêt est obligatoire même quand personne n’arrive. On s’immobilise à la limite de la chaussée abordée, on cède le passage aux véhicules de l’autre route s’il y en a, et on ne repart qu’une fois sûr de pouvoir le faire sans danger.',
    scene: {
      site: 'intersection',
      signs: [{ type: 'stop', approach: 'S' }],
      vehicles: [{ id: 'moi', player: true, from: 'S', action: 'straight' }],
      resolution: [{ wait: 1.4 }, { go: ['moi'] }],
    },
  },
  {
    id: 'cedez-1',
    vue: 'Carrefour en croix. Un panneau cédez le passage est à votre droite. Une voiture blanche arrive par l’ouest, à votre gauche.',
    chapter: 'ville',
    theme: 'priorites',
    article: 'R415-7',
    situation: 'Un panneau « cédez le passage » est placé à votre droite. Une voiture blanche arrive par la gauche.',
    question: 'Dans cette situation :',
    options: [
      { id: 'A', text: 'je laisse passer la voiture blanche' },
      { id: 'B', text: 'je dois m’arrêter même quand la route est libre' },
      { id: 'C', text: 'je m’engage après son passage, si c’est sans danger' },
    ],
    correct: ['A', 'C'],
    explanation:
      'Le cédez-le-passage impose de laisser passer les véhicules de l’autre route et de ne s’engager que sans danger. Contrairement au stop, il n’impose pas de marquer un arrêt quand la voie est libre. Ici une voiture arrive : je la laisse passer, puis je m’engage.',
    scene: {
      site: 'intersection',
      signs: [{ type: 'cedez', approach: 'S' }],
      vehicles: [
        { id: 'moi', player: true, from: 'S', action: 'straight' },
        { id: 'blanche', from: 'W', action: 'straight', color: 'blanc' },
      ],
      resolution: [{ go: ['blanche'] }, { wait: 0.9 }, { go: ['moi'] }],
    },
  },
  {
    id: 'gauche-1',
    vue: 'Carrefour en croix sans signalisation. Votre voiture bleue, clignotant gauche allumé ; une voiture jaune arrive en face.',
    chapter: 'ville',
    theme: 'priorites',
    article: 'R415-4',
    alinea: 'III',
    situation: 'Vous tournez à gauche, clignotant allumé. Une voiture jaune arrive en face et continue tout droit.',
    question: 'Qui passe en premier ?',
    options: [
      { id: 'A', text: 'moi, car je suis arrivé le premier' },
      { id: 'B', text: 'la voiture jaune qui vient en face' },
    ],
    correct: ['B'],
    explanation:
      'Le conducteur qui tourne à gauche doit céder le passage aux véhicules venant en sens inverse. En pratique, il coupe leur trajectoire : il les laisse passer avant de tourner.',
    scene: {
      site: 'intersection',
      signs: [],
      vehicles: [
        { id: 'moi', player: true, from: 'S', action: 'left' },
        { id: 'jaune', from: 'N', action: 'straight', color: 'jaune' },
      ],
      resolution: [{ go: ['jaune'] }, { wait: 0.7 }, { go: ['moi'] }],
    },
  },
  {
    id: 'giratoire-1',
    vue: 'Entrée d’un carrefour à sens giratoire avec un cédez le passage. Une voiture rouge circule sur l’anneau et arrive par votre gauche.',
    chapter: 'ville',
    theme: 'priorites',
    article: 'R415-10',
    situation: 'Vous abordez un carrefour à sens giratoire signalé par un « cédez le passage ». Une voiture rouge circule déjà sur l’anneau.',
    question: 'Que faites-vous ?',
    options: [
      { id: 'A', text: 'je laisse passer la voiture déjà engagée sur l’anneau' },
      { id: 'B', text: 'je m’engage : elle vient de ma gauche, je suis prioritaire' },
    ],
    correct: ['A'],
    explanation:
      'À l’entrée d’un carrefour à sens giratoire, on cède le passage aux usagers qui circulent déjà sur l’anneau, quel que soit le classement de la route que l’on quitte.',
    scene: {
      site: 'giratoire',
      signs: [{ type: 'cedez', approach: 'S' }],
      vehicles: [
        { id: 'moi', player: true, from: 'S', action: 'ring-east' },
        { id: 'rouge', from: 'RING', action: 'ring-north', color: 'rouge' },
      ],
      resolution: [{ go: ['rouge'] }, { wait: 1.1 }, { go: ['moi'] }],
    },
  },
  {
    id: 'rue-velo-1',
    vue: 'Rue avec piste cyclable à droite. Votre voiture va tourner à droite dans une rue transversale ; un cycliste arrive derrière vous sur la piste.',
    chapter: 'rue',
    theme: 'usagers',
    article: 'R415-3',
    alinea: 'III',
    situation: 'Vous tournez à droite dans la rue transversale, clignotant allumé. Un cycliste arrive derrière vous sur la piste cyclable.',
    question: 'Que faites-vous ?',
    options: [
      { id: 'A', text: 'je tourne avant lui, c’est à lui de s’arrêter' },
      { id: 'B', text: 'je le laisse passer avant de tourner' },
      { id: 'C', text: 'je klaxonne pour qu’il ralentisse' },
    ],
    correct: ['B'],
    explanation:
      'En tournant à droite, je traverse la piste cyclable que suit le cycliste. Je dois céder le passage aux cycles qui y circulent, dans un sens comme dans l’autre. Conseil : un coup d’œil au rétroviseur et dans l’angle mort permet de le repérer à temps.',
    scene: {
      site: 'rue',
      signs: [{ type: 'piste', x: 9.2, z: 21, rotY: 0 }],
      vehicles: [
        { id: 'moi', player: true, from: 'S', action: 'right-cross' },
        { id: 'cycliste', kind: 'velo', action: 'piste-north' },
      ],
      resolution: [{ go: [{ id: 'cycliste', dist: 45, speed: 5, easing: 'linear' }] }, { wait: 2.2 }, { go: ['moi'] }],
    },
  },
  {
    id: 'rue-stationnement-1',
    vue: 'Rue avec places de stationnement, piste cyclable et passage piéton. A : place libre ; B : piste cyclable ; C : passage piéton.',
    chapter: 'rue',
    theme: 'stationnement',
    article: 'R417-11',
    alinea: 'I',
    situation: 'Vous cherchez à vous garer dans cette rue. Trois emplacements sont repérés par les lettres A, B et C.',
    question: 'Où avez-vous le droit de stationner ?',
    options: [
      { id: 'A', text: 'sur la place matérialisée (A)' },
      { id: 'B', text: 'sur la piste cyclable (B), quelques minutes seulement' },
      { id: 'C', text: 'sur le passage piéton (C), avec les feux de détresse' },
    ],
    correct: ['A'],
    explanation:
      'Seule la place matérialisée est autorisée. S’arrêter ou stationner sur une piste cyclable ou sur un passage piéton est considéré comme très gênant, même brièvement ; les feux de détresse n’y changent rien.',
    scene: {
      site: 'rue',
      camera: { x: 3, z: 30, zoom: 40 },
      labels: [{ id: 'A', x: 5.3, z: 37.7 }, { id: 'B', x: 7.4, z: 43 }, { id: 'C', x: -1.5, z: 13 }],
      vehicles: [{ id: 'moi', player: true, action: 'park' }],
      resolution: [{ wait: 0.3 }, { go: [{ id: 'moi', speed: 4, easing: 'inOutCubic' }] }],
    },
  },
  {
    id: 'campagne-vitesse-1',
    vue: 'Sortie de village : panneau blanc bordé de rouge, nom barré. Au-delà, une route de campagne à une voie par sens entre des champs.',
    chapter: 'campagne',
    theme: 'vitesse',
    article: 'R413-2',
    alinea: 'I, 3°',
    situation: 'Vous quittez le village et passez ce panneau. La route compte une voie dans chaque sens et aucun autre panneau n’est visible.',
    question: 'Quelle est la vitesse maximale autorisée après le panneau ?',
    options: [
      { id: 'A', text: '70 km/h' },
      { id: 'B', text: '80 km/h' },
      { id: 'C', text: '90 km/h' },
    ],
    correct: ['B'],
    explanation:
      'Le nom barré marque la sortie de l’agglomération : la limite de 50 km/h ne s’applique plus. Hors agglomération, sur une route à une voie par sens sans terre-plein central, la vitesse est limitée à 80 km/h, sauf panneau contraire.',
    scene: {
      site: 'campagne',
      camera: { x: 2, z: 4, zoom: 36 },
      signs: [{ type: 'sortie-agglo', x: 5.6, z: 3, rotY: 0 }],
      vehicles: [{ id: 'moi', player: true, action: 'rural-straight' }],
      resolution: [{ go: [{ id: 'moi', dist: 45, speed: 13 }] }],
    },
  },
  {
    id: 'campagne-depassement-1',
    vue: 'Route de campagne en lisière de forêt. Un tracteur roule devant vous ; la ligne médiane est continue, elle devient discontinue plus loin.',
    chapter: 'campagne',
    theme: 'depassement',
    article: 'R412-19',
    situation: 'Un tracteur roule lentement devant vous, en lisière de forêt. La ligne au milieu de la chaussée est continue.',
    question: 'Pouvez-vous le dépasser maintenant ?',
    options: [
      { id: 'A', text: 'oui, en franchissant la ligne puisqu’il roule lentement' },
      { id: 'B', text: 'non, je reste derrière jusqu’à ce que la ligne devienne discontinue' },
    ],
    correct: ['B'],
    explanation:
      'Une ligne continue au milieu de la chaussée interdit de la franchir ou de la chevaucher. Je reste derrière le tracteur et je ne dépasse qu’une fois la ligne devenue discontinue, si la voie de gauche est libre. Seul le dépassement d’un vélo permet de chevaucher cette ligne.',
    scene: {
      site: 'campagne',
      camera: { x: 0, z: -58, zoom: 40 },
      follow: 'moi',
      vehicles: [
        { id: 'moi', player: true, action: 'rural-follow' },
        { id: 'tracteur', kind: 'tracteur', action: 'tractor' },
      ],
      resolution: [
        { sync: true, go: [{ id: 'tracteur', dist: 30, speed: 4.5, easing: 'linear' }, { id: 'moi', dist: 30, speed: 4.5, easing: 'linear' }] },
        { sync: true, go: [{ id: 'tracteur', dist: 40, speed: 4.5, easing: 'linear' }, { id: 'moi', dist: 70, speed: 11, easing: 'inOutCubic' }] },
      ],
    },
  },
  {
    id: 'autoroute-insertion-1',
    vue: 'Autoroute à deux voies par sens. Vous êtes sur la voie d’insertion ; une voiture blanche arrive sur la voie de droite, un peu en arrière.',
    chapter: 'autoroute',
    theme: 'autoroute',
    article: 'R421-3',
    situation: 'Vous arrivez sur l’autoroute par la voie d’insertion. Une voiture blanche circule sur la voie de droite, un peu en arrière.',
    question: 'Qui passe en premier ?',
    options: [
      { id: 'A', text: 'moi, puisque mon clignotant est allumé' },
      { id: 'B', text: 'la voiture qui circule déjà sur l’autoroute' },
    ],
    correct: ['B'],
    explanation:
      'Quand on emprunte une bretelle pour entrer sur l’autoroute, on cède le passage aux véhicules qui y circulent déjà. J’adapte ma vitesse sur la voie d’insertion pour m’insérer derrière la voiture blanche.',
    scene: {
      site: 'autoroute',
      follow: 'moi',
      vehicles: [
        { id: 'moi', player: true, action: 'merge' },
        { id: 'blanche', action: 'motorway-right', color: 'blanc' },
      ],
      resolution: [{ go: [{ id: 'blanche', dist: 90, speed: 22, easing: 'linear' }] }, { wait: 0.3 }, { go: [{ id: 'moi', dist: 90, speed: 16 }] }],
    },
  },
  {
    id: 'autoroute-pluie-1',
    vue: 'Autoroute sous la pluie, chaussée mouillée. Votre voiture roule sur la voie de droite.',
    chapter: 'autoroute',
    theme: 'vitesse',
    article: 'R413-2',
    alinea: 'II, 1°',
    situation: 'Il pleut. Vous roulez sur une autoroute où la vitesse est normalement limitée à 130 km/h.',
    question: 'Quelle est votre vitesse maximale ?',
    options: [
      { id: 'A', text: '90 km/h' },
      { id: 'B', text: '110 km/h' },
      { id: 'C', text: '130 km/h' },
    ],
    correct: ['B'],
    explanation:
      'Par temps de pluie, la vitesse maximale descend à 110 km/h sur les autoroutes normalement limitées à 130 km/h. Sur chaussée mouillée, il faut plus de distance pour s’arrêter : je garde aussi davantage d’écart avec le véhicule qui précède.',
    scene: {
      site: 'autoroute',
      weather: 'pluie',
      camera: { x: 7, z: 2, zoom: 40 },
      follow: 'moi',
      vehicles: [{ id: 'moi', player: true, action: 'motorway-cruise' }],
      resolution: [{ go: [{ id: 'moi', dist: 80, speed: 18 }] }],
    },
  },
];

// Thème officiel de l'examen de chaque situation du parcours guidé (cf. src/data/domains.js)
const DOMAINE_OF_THEME = { priorites: 'circulation', usagers: 'usagers', stationnement: 'circulation', vitesse: 'circulation', depassement: 'circulation', autoroute: 'route' };
for (const q of QUESTIONS) q.domaine = q.scene.weather === 'pluie' ? 'route' : DOMAINE_OF_THEME[q.theme];
