// Kit de panneaux — catalogue (données pures, sans dessin).
// Codes et significations : catalogue des panneaux de l'Instruction interministérielle sur la signalisation
// routière (IISR), CEREMA, juin 2022. Les significations sont reprises du catalogue ou résumées sans en changer le sens.
// Le dessin de chaque panneau est fait par code dans src/scene/signs.js (aucune image).
// desc : description visuelle (forme, couleurs, symbole) pour les lecteurs d'écran, sans donner la signification.
// Pictogrammes à faire valider par un moniteur avant diffusion.

export const SIGN_SOURCE = 'IISR (arrêté du 24 novembre 1967), catalogue CEREMA des panneaux';

/** famille : danger | priorite | interdiction | fin | obligation | zone | indication | service | localisation */
export const SIGNS = [
  // Priorité
  { code: 'AB1', famille: 'priorite', sens: 'Intersection où je dois céder le passage aux véhicules venant de ma droite', desc: 'triangle à bord rouge, croix noire en forme de X' },
  { code: 'AB2', famille: 'priorite', sens: 'Intersection avec une route dont les usagers doivent me céder le passage', desc: 'triangle à bord rouge, croix noire droite au trait vertical plus épais' },
  { code: 'AB3a', famille: 'priorite', sens: 'Cédez le passage à l’intersection', desc: 'triangle pointe en bas, bord rouge, fond blanc' },
  { code: 'AB4', famille: 'priorite', sens: 'Arrêt obligatoire à l’intersection (stop)', desc: 'octogone rouge portant l’inscription STOP' },
  { code: 'AB6', famille: 'priorite', sens: 'Route à caractère prioritaire', desc: 'losange jaune bordé de blanc' },
  { code: 'AB7', famille: 'priorite', sens: 'Fin de route à caractère prioritaire', desc: 'losange jaune bordé de blanc, barré d’un trait noir' },
  // Danger
  { code: 'A1a', famille: 'danger', sens: 'Virage à droite', desc: 'triangle à bord rouge, ligne noire courbée vers la droite' },
  { code: 'A2b', famille: 'danger', sens: 'Ralentisseur de type dos-d’âne', desc: 'triangle à bord rouge, bosse noire dessinée sur une ligne' },
  { code: 'A3', famille: 'danger', sens: 'Chaussée rétrécie', desc: 'triangle à bord rouge, deux lignes noires qui se rapprochent' },
  { code: 'A14', famille: 'danger', sens: 'Autres dangers', desc: 'triangle à bord rouge, point d’exclamation noir' },
  // Ajouts v0.4 (libellés du catalogue CEREMA ; pictogrammes simplifiés, à faire valider)
  { code: 'A7', famille: 'danger', sens: 'Passage à niveau muni de barrières ou de demi-barrières (manuelles ou automatiques)', desc: 'triangle à bord rouge, barrière noire' },
  { code: 'A8', famille: 'danger', sens: 'Passage à niveau sans barrières ni demi-barrières', desc: 'triangle à bord rouge, locomotive à vapeur noire' },
  { code: 'A13a', famille: 'danger', sens: 'Endroit fréquenté par les enfants', desc: 'triangle à bord rouge, deux enfants qui courent' },
  { code: 'A13b', famille: 'danger', sens: 'Annonce d’un passage pour piétons', desc: 'triangle à bord rouge, piéton noir qui marche sur des bandes' },
  { code: 'A17', famille: 'danger', sens: 'Annonce de feux tricolores', desc: 'triangle à bord rouge, trois feux rouge, jaune et vert superposés' },
  { code: 'AB25', famille: 'priorite', sens: 'Carrefour à sens giratoire', desc: 'triangle à bord rouge, trois flèches noires en cercle' },
  { code: 'B3', famille: 'interdiction', sens: 'Interdiction de dépasser tous les véhicules à moteur autres que les deux-roues sans side-car', desc: 'disque à couronne rouge, voiture rouge à côté d’une voiture noire' },
  { code: 'B34', famille: 'fin', sens: 'Fin d’interdiction de dépasser', desc: 'disque blanc, deux voitures grises barrées de traits noirs' },
  { code: 'C20a', famille: 'indication', sens: 'Indication de l’emplacement d’un passage pour piétons', desc: 'carré bleu, triangle blanc avec un piéton noir sur des bandes' },
  { code: 'C207', famille: 'indication', sens: 'Début d’une section d’autoroute', desc: 'carré bleu, chaussée blanche passant sous un pont' },

  // ——— Ajouts v0.5 (libellés du catalogue CEREMA, juin 2022 ; pictogrammes simplifiés, à faire valider) ———
  // Danger
  { code: 'A1b', famille: 'danger', sens: 'Virage à gauche', desc: 'triangle à bord rouge, ligne noire courbée vers la gauche' },
  { code: 'A1c', famille: 'danger', sens: 'Succession de virages dont le premier est à droite', desc: 'triangle à bord rouge, ligne noire en zigzag partant vers la droite' },
  { code: 'A1d', famille: 'danger', sens: 'Succession de virages dont le premier est à gauche', desc: 'triangle à bord rouge, ligne noire en zigzag partant vers la gauche' },
  { code: 'A2a', famille: 'danger', sens: 'Cassis ou dos-d’âne', desc: 'triangle à bord rouge, ligne noire avec un creux puis une bosse' },
  { code: 'A3a', famille: 'danger', sens: 'Chaussée rétrécie par la droite', desc: 'triangle à bord rouge, deux lignes noires, celle de droite se rapproche' },
  { code: 'A3b', famille: 'danger', sens: 'Chaussée rétrécie par la gauche', desc: 'triangle à bord rouge, deux lignes noires, celle de gauche se rapproche' },
  { code: 'A4', famille: 'danger', sens: 'Chaussée particulièrement glissante', desc: 'triangle à bord rouge, voiture noire et traces sinueuses' },
  { code: 'A15b', famille: 'danger', sens: 'Passage d’animaux sauvages', desc: 'triangle à bord rouge, cerf noir qui bondit' },
  { code: 'A16', famille: 'danger', sens: 'Descente dangereuse', desc: 'triangle à bord rouge, pente noire et pourcentage' },
  { code: 'A18', famille: 'danger', sens: 'Circulation dans les deux sens', desc: 'triangle à bord rouge, deux flèches noires de sens opposés' },
  { code: 'A19', famille: 'danger', sens: 'Risque de chute de pierres ou de présence de pierres tombées sur la route', desc: 'triangle à bord rouge, falaise et pierres qui tombent' },
  { code: 'A21', famille: 'danger', sens: 'Débouché de cyclistes venant de droite ou de gauche', desc: 'triangle à bord rouge, vélo noir' },
  { code: 'A24', famille: 'danger', sens: 'Vent latéral', desc: 'triangle à bord rouge, manche à air gonflée par le vent' },
  // Priorité (signaux avancés : panneau et panonceau de distance)
  { code: 'AB3b', famille: 'priorite', sens: 'Annonce d’un cédez-le-passage à l’intersection (signal avancé)', desc: 'triangle pointe en bas, bord rouge, avec panonceau « 150 m »' },
  { code: 'AB5', famille: 'priorite', sens: 'Annonce d’un arrêt obligatoire (stop) à l’intersection (signal avancé)', desc: 'triangle pointe en bas, bord rouge, portant le mot STOP, avec panonceau « 150 m »' },
  // Interdiction
  { code: 'B2c', famille: 'interdiction', sens: 'Interdiction de faire demi-tour jusqu’à la prochaine intersection', desc: 'disque à couronne rouge, flèche noire en U barrée de rouge' },
  { code: 'B7b', famille: 'interdiction', sens: 'Accès interdit à tous les véhicules à moteur', desc: 'disque à couronne rouge, voiture noire au-dessus d’une moto noire' },
  { code: 'B9a', famille: 'interdiction', sens: 'Accès interdit aux piétons', desc: 'disque à couronne rouge, piéton noir' },
  { code: 'B9b', famille: 'interdiction', sens: 'Accès interdit aux cycles', desc: 'disque à couronne rouge, vélo noir' },
  { code: 'B12', famille: 'interdiction', sens: 'Accès interdit aux véhicules dont la hauteur, chargement compris, dépasse le nombre indiqué', desc: 'disque à couronne rouge, « 3,5 m » entre deux pointes verticales' },
  { code: 'B13', famille: 'interdiction', sens: 'Accès interdit aux véhicules dont le poids total autorisé en charge dépasse le nombre indiqué', desc: 'disque à couronne rouge, « 3,5 t »' },
  { code: 'B15', famille: 'interdiction', sens: 'Cédez le passage à la circulation venant en sens inverse', desc: 'disque à couronne rouge, flèche rouge vers le bas et flèche noire vers le haut' },
  { code: 'B16', famille: 'interdiction', sens: 'Signaux sonores interdits', desc: 'disque à couronne rouge, trompe noire barrée de rouge' },
  // Fin d'interdiction
  { code: 'B31', famille: 'fin', sens: 'Fin de toutes les interdictions précédemment signalées, imposées aux véhicules en mouvement', desc: 'disque blanc traversé de fines bandes noires en diagonale' },
  { code: 'B33', famille: 'fin', sens: 'Fin de limitation de vitesse', desc: 'disque blanc, nombre 70 gris barré de bandes noires' },
  // Obligation
  { code: 'B21-1', famille: 'obligation', sens: 'Obligation de tourner à droite avant le panneau', desc: 'disque bleu, flèche blanche coudée vers la droite' },
  { code: 'B21a1', famille: 'obligation', sens: 'Contournement obligatoire par la droite', desc: 'disque bleu, flèche blanche oblique vers le bas à droite' },
  { code: 'B21b', famille: 'obligation', sens: 'Direction obligatoire à la prochaine intersection : tout droit', desc: 'disque bleu, flèche blanche vers le haut' },
  { code: 'B21c1', famille: 'obligation', sens: 'Direction obligatoire à la prochaine intersection : à droite', desc: 'disque bleu, flèche blanche qui monte puis tourne à droite' },
  { code: 'B21e', famille: 'obligation', sens: 'Directions obligatoires à la prochaine intersection : à droite ou à gauche', desc: 'disque bleu, flèche blanche qui se divise à droite et à gauche' },
  { code: 'B22b', famille: 'obligation', sens: 'Chemin obligatoire pour piétons', desc: 'disque bleu, piéton blanc' },
  { code: 'B25', famille: 'obligation', sens: 'Vitesse minimale obligatoire', desc: 'disque bleu portant le nombre 30 en blanc' },
  { code: 'B26', famille: 'obligation', sens: 'Chaînes à neige obligatoires sur au moins deux roues motrices', desc: 'disque bleu, roue blanche entourée d’une chaîne' },
  // Fin d'obligation
  { code: 'B40', famille: 'fin', sens: 'Fin de piste ou bande obligatoire pour cycles', desc: 'disque bleu, vélo blanc barré de rouge' },
  // Zones
  { code: 'B30', famille: 'zone', sens: 'Entrée d’une zone à vitesse limitée à 30 km/h', desc: 'panneau blanc rectangulaire portant un disque « 30 » et le mot ZONE' },
  { code: 'B51', famille: 'zone', sens: 'Sortie d’une zone à vitesse limitée à 30 km/h', desc: 'panneau blanc rectangulaire « ZONE 30 » en gris, barré' },
  { code: 'B52', famille: 'zone', sens: 'Entrée d’une zone de rencontre', desc: 'panneau blanc rectangulaire à fond bleu portant « ZONE DE RENCONTRE » et le nombre 20' },
  { code: 'B54', famille: 'zone', sens: 'Entrée d’une aire piétonne', desc: 'panneau blanc rectangulaire à fond bleu portant un piéton et « AIRE PIÉTONNE »' },
  // Indication
  { code: 'C4a', famille: 'indication', sens: 'Vitesse conseillée', desc: 'carré bleu portant le nombre 70 en blanc' },
  { code: 'C6', famille: 'indication', sens: 'Arrêt d’autobus', desc: 'carré bleu portant un autobus blanc' },
  { code: 'C13a', famille: 'indication', sens: 'Impasse', desc: 'carré bleu, barre blanche verticale terminée par une barre rouge' },
  { code: 'C18', famille: 'indication', sens: 'Priorité par rapport à la circulation venant en sens inverse', desc: 'carré bleu, flèche blanche vers le haut et flèche rouge vers le bas' },
  { code: 'C107', famille: 'indication', sens: 'Route à accès réglementé', desc: 'carré bleu portant une voiture blanche vue de face' },
  { code: 'C111', famille: 'indication', sens: 'Entrée d’un tunnel', desc: 'carré bleu portant l’entrée d’un tunnel en blanc' },
  { code: 'C113', famille: 'indication', sens: 'Piste ou bande cyclable conseillée et réservée aux cycles', desc: 'carré bleu portant un vélo blanc' },
  { code: 'C115', famille: 'indication', sens: 'Voie verte, réservée aux piétons et aux véhicules non motorisés', desc: 'carré vert portant un piéton et un vélo blancs' },
  // Services
  { code: 'CE1', famille: 'service', sens: 'Poste de secours', desc: 'carré bleu, carré blanc intérieur portant une croix rouge' },
  { code: 'CE15a', famille: 'service', sens: 'Poste de carburant ouvert 7 jours sur 7 et 24 heures sur 24', desc: 'carré bleu, carré blanc intérieur portant une pompe à essence noire' },
  // Interdiction
  { code: 'B0', famille: 'interdiction', sens: 'Circulation interdite à tout véhicule dans les deux sens', desc: 'disque blanc entouré d’une couronne rouge, sans symbole' },
  { code: 'B1', famille: 'interdiction', sens: 'Sens interdit à tout véhicule', desc: 'disque rouge barré d’une bande blanche horizontale' },
  { code: 'B2a', famille: 'interdiction', sens: 'Interdiction de tourner à gauche à la prochaine intersection', desc: 'disque à couronne rouge, flèche noire tournant à gauche, barrée de rouge' },
  { code: 'B2b', famille: 'interdiction', sens: 'Interdiction de tourner à droite à la prochaine intersection', desc: 'disque à couronne rouge, flèche noire tournant à droite, barrée de rouge' },
  { code: 'B6a1', famille: 'interdiction', sens: 'Stationnement interdit', desc: 'disque bleu à couronne rouge, barré d’un trait rouge' },
  { code: 'B6d', famille: 'interdiction', sens: 'Arrêt et stationnement interdits', desc: 'disque bleu à couronne rouge, barré d’une croix rouge' },
  { code: 'B14-30', famille: 'interdiction', sens: 'Vitesse limitée à 30 km/h', valeur: 30, desc: 'disque à couronne rouge portant le nombre 30' },
  { code: 'B14-50', famille: 'interdiction', sens: 'Vitesse limitée à 50 km/h', valeur: 50, desc: 'disque à couronne rouge portant le nombre 50' },
  { code: 'B14-70', famille: 'interdiction', sens: 'Vitesse limitée à 70 km/h', valeur: 70, desc: 'disque à couronne rouge portant le nombre 70' },
  { code: 'B14-90', famille: 'interdiction', sens: 'Vitesse limitée à 90 km/h', valeur: 90, desc: 'disque à couronne rouge portant le nombre 90' },
  // Obligation
  { code: 'B22a', famille: 'obligation', sens: 'Piste ou bande obligatoire pour les cycles', desc: 'disque bleu avec un vélo blanc' },
  // Indication
  { code: 'C1a', famille: 'indication', sens: 'Lieu aménagé pour le stationnement', desc: 'carré bleu portant un P blanc' },
  { code: 'C12', famille: 'indication', sens: 'Circulation à sens unique', desc: 'carré bleu portant une flèche blanche vers le haut' },
  // Localisation
  { code: 'EB10', famille: 'localisation', sens: 'Entrée d’agglomération', desc: 'panneau rectangulaire blanc bordé de rouge portant le nom d’une commune' },
  { code: 'EB20', famille: 'localisation', sens: 'Sortie d’agglomération', desc: 'panneau rectangulaire blanc bordé de rouge, nom d’une commune barré d’une bande rouge' },
];

/** Anciens noms internes conservés pour les questions déjà écrites. */
export const SIGN_ALIASES = { stop: 'AB4', cedez: 'AB3a', piste: 'B22a', 'sortie-agglo': 'EB20', 'entree-agglo': 'EB10' };

export function signByCode(code) {
  const c = SIGN_ALIASES[code] || code;
  return SIGNS.find((s) => s.code === c) || null;
}

/** Forme découpée du panneau, utilisée pour la géométrie 3D et le cadrage. */
export function signShape(code) {
  const s = signByCode(code);
  if (!s) return 'cercle';
  if (s.code === 'AB4') return 'octogone';
  if (s.code === 'AB3a') return 'triangle-bas';
  if (s.code === 'AB3b' || s.code === 'AB5') return 'libre'; // panneau et panonceau : face découpée par transparence
  if (s.code === 'AB6' || s.code === 'AB7') return 'losange';
  if (s.famille === 'danger' || ['AB1', 'AB2', 'AB25'].includes(s.code)) return 'triangle';
  if (['indication', 'service', 'zone'].includes(s.famille)) return 'carre';
  if (s.famille === 'localisation') return 'rectangle';
  return 'cercle';
}

/** Libellé des familles de panneaux, avec la forme et les couleurs qui permettent de les reconnaître. */
export const FAMILLES = {
  danger: { nom: 'de danger', forme: 'un triangle pointe en haut, bordé de rouge' },
  priorite: { nom: 'd’intersection et de priorité', forme: 'des formes particulières (triangle pointe en bas, octogone, losange) ou un triangle de danger' },
  interdiction: { nom: 'd’interdiction', forme: 'un disque bordé de rouge' },
  fin: { nom: 'de fin d’interdiction ou d’obligation', forme: 'un disque barré de bandes (noires sur fond blanc, ou rouge sur un panneau bleu)' },
  obligation: { nom: 'd’obligation', forme: 'un disque bleu à symbole blanc' },
  zone: { nom: 'de zone (prescription zonale)', forme: 'un panneau rectangulaire qui annonce l’entrée ou la sortie d’une zone' },
  indication: { nom: 'd’indication', forme: 'un carré ou un rectangle à fond bleu (ou vert pour la voie verte)' },
  service: { nom: 'de services', forme: 'un carré bleu contenant un carré blanc' },
  localisation: { nom: 'de localisation', forme: 'un panneau rectangulaire (entrée et sortie d’agglomération : blanc bordé de rouge)' },
};
