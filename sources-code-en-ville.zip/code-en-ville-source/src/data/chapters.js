// Chapitres de révision : les 10 thèmes de l'examen, découpés en sous-chapitres quand le thème est vaste.
// Chaque notion du catalogue (src/engine/generator.js) porte l'identifiant de son chapitre.
import { DOMAINS } from './domains.js';

const SUB = {
  circulation: [
    ['panneaux-danger', 'Panneaux de danger'],
    ['panneaux-priorite', 'Panneaux d’intersection et de priorité'],
    ['panneaux-interdiction', 'Panneaux d’interdiction et de fin d’interdiction'],
    ['panneaux-obligation', 'Panneaux d’obligation'],
    ['panneaux-indication', 'Panneaux d’indication, de zone et de localisation'],
    ['priorites', 'Priorités et intersections'],
    ['feux', 'Feux tricolores'],
    ['vitesse', 'Vitesses maximales'],
    ['depassement', 'Dépassement'],
    ['stationnement', 'Arrêt et stationnement'],
  ],
  route: [
    ['nuit-meteo', 'Nuit, éclairage et météo'],
    ['autoroute', 'Autoroute'],
    ['passage-niveau', 'Passages à niveau'],
    ['route-divers', 'Visibilité, montagne, poids lourds'],
  ],
};

/** Liste ordonnée des chapitres : { id, domaine, label }. Un thème sans découpage forme un chapitre unique. */
export const CHAPITRES = DOMAINS.flatMap((d) => (SUB[d.id] || [[d.id, d.label]]).map(([id, label]) => ({ id, domaine: d.id, label })));
export const chapitreLabel = (id) => CHAPITRES.find((c) => c.id === id)?.label || '';
