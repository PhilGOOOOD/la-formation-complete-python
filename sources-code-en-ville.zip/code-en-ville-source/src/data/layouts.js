// Kit de décor — plans d'assemblage (données pures, testables sous Node).
// Une scène est une liste de pièces posées sur une grille de tuiles de 20 m.
//   i : colonne (vers l'est), j : rangée (vers le sud), rot : quart de tour (0 = route nord-sud).
// Les pièces de route sont décrites par leurs options (lignes, trottoirs, piste, places, passage piéton…)
// et le décor autour est complété automatiquement selon le thème, sans rien de haut côté caméra (sud-est).

import { RUE } from '../scene/routes.js';

export const TILE = 20;

/** Emprise des grandes pièces, en tuiles (demi-largeur et demi-hauteur autour de la tuile centrale). */
export const FOOTPRINT = { giratoire: [1, 1], autoroute: [1, 0] };

/** Variante déterministe 0–3 d'une case (toujours positive, même pour des indices négatifs). */
const variante = (i, j) => (((i * 7 + j * 13) % 4) + 4) % 4;

const ROAD_TYPES = new Set(['route', 'croix', 'te', 'giratoire', 'autoroute', 'parking']);
export const isRoad = (p) => ROAD_TYPES.has(p.type);

function cellsOf(p) {
  const [hx, hz] = FOOTPRINT[p.type] || [0, 0];
  const out = [];
  for (let di = -hx; di <= hx; di++) for (let dj = -hz; dj <= hz; dj++) out.push(`${p.i + di},${p.j + dj}`);
  return out;
}

/** Complète les cases libres autour des routes avec des pièces de décor selon le thème. */
function fill(pieces, theme, radius = 3, camera = 'est') {
  const used = new Set(pieces.flatMap(cellsOf));
  for (let i = -radius; i <= radius; i++) {
    for (let j = -radius; j <= radius; j++) {
      if (used.has(`${i},${j}`)) continue;
      const sx = camera === 'ouest' ? -1 : 1;     // la caméra regarde depuis le sud-est (ou le sud-ouest)
      const cameraSide = i * sx > 0 && j > 0;     // devant la scène pour la caméra : rien de haut
      const back = i * sx < 0 && j < 0;            // arrière-plan : on peut monter
      let type;
      if (theme === 'ville') type = cameraSide ? 'parc' : back ? 'immeubles' : 'maisons';
      else if (theme === 'campagne') type = i < 0 ? (j < 0 ? 'foret' : 'maisons') : (j > 0 ? 'parc' : 'champ');
      else if (theme === 'foret') type = i < 0 ? 'foret' : 'champ';
      else type = i < 0 ? 'bosquet' : 'champ';   // autoroute : abords dégagés
      pieces.push({ type, i, j, rot: 0, opts: { variante: variante(i, j) } });
    }
  }
  return pieces;
}

const ns = (j, opts = {}) => ({ type: 'route', i: 0, j, rot: 0, opts });
const ew = (i, opts = {}) => ({ type: 'route', i, j: 0, rot: 1, opts });

/**
 * Plans prédéfinis. Chaque plan accepte des options :
 *  croix : { theme }   — carrefour en croix, routes de ville ou de campagne
 *  rue : {}            — rue avec piste cyclable à l'est, places, passage piéton, rue transversale
 *  campagne : {}       — sortie de village puis route de campagne en lisière de forêt
 *  autoroute : {}      — autoroute à 2×2 voies avec bretelle et voie d'insertion
 *  giratoire : { theme }
 */
export function layout(name, opts = {}) {
  const theme = opts.theme || { campagne: 'campagne', autoroute: 'autoroute' }[name] || 'ville';
  const urban = theme === 'ville';
  const road = urban ? { centre: 'discontinue', trottoir: true } : { centre: 'discontinue', rive: true };
  let pieces;
  switch (name) {
    case 'croix':
      pieces = [{ type: 'croix', i: 0, j: 0, rot: 0, opts: { trottoir: urban } }];
      for (const k of [1, 2, 3]) pieces.push(ns(k, road), ns(-k, road), ew(k, road), ew(-k, road));
      break;
    case 'giratoire':
      pieces = [{ type: 'giratoire', i: 0, j: 0, rot: 0, opts: { trottoir: urban } }];
      for (const k of [2, 3]) pieces.push(ns(k, road), ns(-k, road), ew(k, road), ew(-k, road));
      break;
    case 'rue': {
      const r = { centre: 'discontinue', trottoir: true, piste: 'est' };
      pieces = [{ type: 'te', i: 0, j: 0, rot: 0, opts: { trottoir: true, piste: 'est' } },
        ns(1, { ...r, centre: 'aucune', zebra: RUE.zebraZ - TILE }), ns(2, { ...r, places: 'est', libre: 1 }), ns(3, r),
        ns(-1, r), ns(-2, r), ns(-3, r)];
      for (const k of [1, 2, 3]) pieces.push(ew(k, { centre: 'discontinue', trottoir: true }));
      break;
    }
    case 'campagne':
      pieces = [];
      // Ligne médiane continue sur la zone de visibilité réduite (z de -30 à -90), sauf option ligne: 'discontinue'
      for (let j = 3; j >= -9; j--) pieces.push(ns(j, { centre: opts.ligne !== 'discontinue' && j <= -2 && j >= -4 ? 'continue' : 'discontinue', rive: j <= 0, trottoir: j > 0 }));
      break;
    case 'parking':
      // Parking (deux tuiles) bordé au nord par une rue est-ouest avec trottoirs
      pieces = [{ type: 'parking', i: 0, j: 0, rot: 0, opts: { sortie: true } }, { type: 'parking', i: -1, j: 0, rot: 0, opts: {} }];
      for (const k of [-3, -2, -1, 0, 1, 2, 3]) pieces.push({ type: 'route', i: k, j: -1, rot: 1, opts: { centre: 'discontinue', trottoir: true } });
      break;
    case 'autoroute':
      pieces = [];
      for (let j = 4; j >= -8; j--) {
        // Sans bretelle : route à deux chaussées séparées (voie express) ou autoroute en section courante
        const insertion = opts.bretelle === false ? null : j === 3 ? 'bretelle' : j >= 0 && j <= 2 ? 'voie' : j === -1 ? 'biseau' : null;
        pieces.push({ type: 'autoroute', i: 0, j, rot: 0, opts: { insertion } });
      }
      break;
    default:
      throw new Error(`Plan inconnu : ${name}`);
  }
  const filled = fill(pieces, theme, 3, opts.camera);
  // Les longues routes (campagne, autoroute) sortent du rayon : on ajoute du décor le long du tracé
  if (name === 'campagne' || name === 'autoroute') {
    for (let j = -4; j >= -9; j--) for (const i of [-3, -2, -1, 1, 2, 3]) {
      if (name === 'autoroute' && Math.abs(i) === 1) continue;
      if (!filled.some((p) => cellsOf(p).includes(`${i},${j}`))) {
        const type = name === 'campagne' ? (i < 0 ? 'foret' : 'champ') : (i < 0 ? 'bosquet' : 'champ');
        filled.push({ type, i, j, rot: 0, opts: { variante: variante(i, j) } });
      }
    }
  }
  return { name, theme, pieces: filled, key: `${name}:${theme}:${opts.ligne || ''}:${opts.bretelle === false ? 'sans-bretelle' : ''}:${opts.camera || 'est'}` };
}

/** Vérifie qu'aucune pièce n'en chevauche une autre ; renvoie la liste des cases en double. */
export function overlaps(plan) {
  const seen = new Map(), dup = [];
  for (const p of plan.pieces) for (const c of cellsOf(p)) { if (seen.has(c)) dup.push(c); seen.set(c, p.type); }
  return dup;
}

/** Plan associé à un site de question (les anciens noms de sites restent valables). */
export function layoutForScene(scene) {
  const name = { intersection: 'croix', giratoire: 'giratoire', rue: 'rue', campagne: 'campagne', autoroute: 'autoroute', parking: 'parking' }[scene.site];
  if (!name) throw new Error(`Site inconnu : ${scene.site}`);
  return layout(name, scene.layoutOpts || {});
}
