// Les 10 thèmes de l'épreuve théorique générale (liste reprise des sites de préparation, ex. Le Permis Libre).
// Le tirage aléatoire répartit les questions entre ces thèmes pour couvrir tout le programme.
export const DOMAINS = [
  { id: 'circulation', label: 'La circulation routière', court: 'Circulation' },
  { id: 'route', label: 'La route', court: 'Route' },
  { id: 'usagers', label: 'Les autres usagers', court: 'Autres usagers' },
  { id: 'conducteur', label: 'Le conducteur', court: 'Conducteur' },
  { id: 'notions', label: 'Notions diverses (permis, documents)', court: 'Notions diverses' },
  { id: 'mecanique', label: 'Mécanique et équipements', court: 'Mécanique' },
  { id: 'vehicule', label: 'Prendre et quitter son véhicule', court: 'Prendre et quitter' },
  { id: 'securite', label: 'Sécurité du passager et du véhicule', court: 'Sécurité' },
  { id: 'secours', label: 'Premiers secours', court: 'Premiers secours' },
  { id: 'environnement', label: 'Environnement', court: 'Environnement' },
];
export const DOMAIN_IDS = DOMAINS.map((d) => d.id);
export const domainLabel = (id) => DOMAINS.find((d) => d.id === id)?.label || '';
