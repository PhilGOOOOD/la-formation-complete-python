// Voyants du tableau de bord, dessinés en vectoriel sur canvas (pictogrammes simplifiés, à faire valider).
// Couleurs : rouge = alerte, orange = anomalie, vert ou bleu = information (source : Codes Rousseau, fiche « voyants »).
const COLORS = { rouge: '#ff3b30', orange: '#ff9f0a', vert: '#30d158', bleu: '#3d8bff' };
export const VOYANTS = {
  huile: { couleur: 'rouge', desc: 'burette d’huile rouge avec une goutte' },
  temperature: { couleur: 'rouge', desc: 'thermomètre rouge plongé dans des vagues' },
  batterie: { couleur: 'rouge', desc: 'batterie rouge avec ses bornes plus et moins' },
  moteur: { couleur: 'orange', desc: 'silhouette de moteur orange' },
  route: { couleur: 'bleu', desc: 'phare bleu avec des rayons horizontaux' },
  croisement: { couleur: 'vert', desc: 'phare vert avec des rayons inclinés vers le bas' },
  'brouillard-ar': { couleur: 'orange', desc: 'phare orange avec des rayons horizontaux traversés par une ligne ondulée' },
};

function lamp(ctx, c, rays) {
  // Phare : demi-ellipse tournée vers la gauche, rayons à gauche
  ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = 9; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(150, 70); ctx.bezierCurveTo(205, 70, 205, 186, 150, 186); ctx.closePath(); ctx.fill();
  ctx.beginPath(); for (const [x1, y1, x2, y2] of rays) { ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); } ctx.stroke();
}
const DRAW = {
  huile(ctx, c) {
    ctx.fillStyle = c; ctx.strokeStyle = c; ctx.lineWidth = 9; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath(); ctx.moveTo(70, 160); ctx.lineTo(170, 160); ctx.lineTo(205, 120); ctx.lineTo(160, 112); ctx.lineTo(130, 112); ctx.lineTo(120, 128); ctx.lineTo(70, 128); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(205, 120); ctx.lineTo(228, 104); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(230, 132); ctx.quadraticCurveTo(240, 150, 230, 156); ctx.quadraticCurveTo(220, 150, 230, 132); ctx.fill();
    ctx.beginPath(); ctx.moveTo(48, 118); ctx.lineTo(70, 138); ctx.stroke();
  },
  temperature(ctx, c) {
    ctx.fillStyle = c; ctx.strokeStyle = c; ctx.lineWidth = 9; ctx.lineCap = 'round';
    ctx.fillRect(122, 52, 12, 92); ctx.beginPath(); ctx.arc(128, 152, 18, 0, Math.PI * 2); ctx.fill();
    for (const y of [70, 92, 114]) { ctx.beginPath(); ctx.moveTo(140, y); ctx.lineTo(164, y); ctx.stroke(); }
    for (const y of [186, 206]) { ctx.beginPath(); ctx.moveTo(60, y); for (let x = 60; x <= 196; x += 34) ctx.quadraticCurveTo(x + 8, y - 12, x + 17, y), ctx.quadraticCurveTo(x + 26, y + 12, x + 34, y); ctx.stroke(); }
  },
  batterie(ctx, c) {
    ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = 10; ctx.lineCap = 'round';
    ctx.strokeRect(62, 88, 132, 92); ctx.fillRect(80, 70, 22, 18); ctx.fillRect(154, 70, 22, 18);
    ctx.beginPath(); ctx.moveTo(80, 130); ctx.lineTo(104, 130); ctx.moveTo(92, 118); ctx.lineTo(92, 142); ctx.moveTo(152, 130); ctx.lineTo(176, 130); ctx.stroke();
  },
  moteur(ctx, c) {
    ctx.strokeStyle = c; ctx.lineWidth = 10; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(70, 110); ctx.lineTo(96, 110); ctx.lineTo(96, 92); ctx.lineTo(150, 92); ctx.lineTo(150, 110); ctx.lineTo(176, 110); ctx.lineTo(176, 96); ctx.lineTo(206, 96); ctx.lineTo(206, 176); ctx.lineTo(176, 176); ctx.lineTo(166, 192); ctx.lineTo(96, 192); ctx.lineTo(80, 170); ctx.lineTo(56, 170); ctx.lineTo(56, 124); ctx.lineTo(70, 124); ctx.closePath(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(110, 80); ctx.lineTo(136, 80); ctx.stroke();
  },
  route(ctx, c) { lamp(ctx, c, [[48, 82, 128, 82], [48, 110, 128, 110], [48, 138, 128, 138], [48, 166, 128, 166]]); },
  croisement(ctx, c) { lamp(ctx, c, [[52, 100, 128, 84], [52, 128, 128, 112], [52, 156, 128, 140], [52, 184, 128, 168]]); },
  'brouillard-ar'(ctx, c) {
    // Phare tourné vers la droite (feu arrière), rayons horizontaux et ligne ondulée
    ctx.save(); ctx.translate(256, 0); ctx.scale(-1, 1);
    lamp(ctx, c, [[52, 92, 128, 92], [52, 128, 128, 128], [52, 164, 128, 164]]);
    ctx.restore();
    ctx.strokeStyle = c; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(160, 70); ctx.bezierCurveTo(140, 110, 180, 140, 160, 186); ctx.stroke();
  },
};

/** Image d'un voyant allumé sur un fond de tableau de bord (data URL). */
export function voyantImage(code) {
  const v = VOYANTS[code];
  if (!v) throw new Error(`Voyant inconnu : ${code}`);
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const ctx = c.getContext('2d');
  const g = ctx.createRadialGradient(128, 128, 20, 128, 128, 150);
  g.addColorStop(0, '#24282e'); g.addColorStop(1, '#0c0e11');
  ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(4, 4, 248, 248, 36); ctx.fill();
  const col = COLORS[v.couleur];
  ctx.shadowColor = col; ctx.shadowBlur = 18;
  DRAW[code](ctx, col);
  return c.toDataURL('image/png');
}
