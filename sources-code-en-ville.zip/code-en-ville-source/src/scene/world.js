// Moteur de rendu : caméra isométrique, lumière, sol, météo, rendu à la demande et qualité adaptative.
// Le décor de chaque question est construit à part par le kit (src/scene/kit.js) et posé dans `decor`.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import * as tex from './textures.js';
import { ROAD_HALF, GIRATOIRE } from './routes.js';
import { asphaltMaterials } from './kit.js';

const ISO_DIR = new THREE.Vector3(1, 1.3, 1).normalize(); // un peu plus plongeant que l'isométrie stricte : moins d'immeubles devant les voitures
/** Directions de caméra : vue depuis le sud-est (par défaut) ou depuis le sud-ouest. */
export const VIEW_DIRS = { est: ISO_DIR, ouest: new THREE.Vector3(-1, 1.3, 1).normalize() };

export function createWorld(canvas) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.info.autoReset = false;

  const scene = new THREE.Scene();
  scene.background = tex.sky();
  // Brume légère sur les lointains seulement (la caméra est à 200 m de sa cible)
  scene.fog = new THREE.Fog('#d6e2ea', 300, 520);
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environmentIntensity = 0.55;

  // Caméra orthographique en vue isométrique
  const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 1, 600);
  // focus : position à l'écran (fractions) où doit apparaître la cible, pour laisser la place à la carte de question
  const view = { target: new THREE.Vector3(), zoom: 30, dir: ISO_DIR.clone(), focus: { x: 0.5, y: 0.5 },
    mode: 'iso', // 'iso' (vue du dessus) ou 'conducteur' (à la place du conducteur)
    driver: { x: 0, z: 0, yaw: 0 }, mirrorRect: null };
  // Vue conducteur : yeux à 1,2 m, regard légèrement plongeant ; rétroviseur intérieur rendu dans une texture
  const driverCam = new THREE.PerspectiveCamera(52, 1, 0.08, 1200);
  const mirrorCam = new THREE.PerspectiveCamera(20, 3.4, 0.3, 80);
  const mirrorTarget = new THREE.WebGLRenderTarget(512, 150, { samples: 2 });
  const hud = new THREE.Scene();
  const hudCam = new THREE.OrthographicCamera(0, 1, 1, 0, -1, 1);
  // Image du rétroviseur inversée gauche-droite, comme dans un vrai miroir
  const mirrorGeo = new THREE.PlaneGeometry(1, 1);
  { const uv = mirrorGeo.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setX(i, 1 - uv.getX(i)); }
  const mirrorQuad = new THREE.Mesh(mirrorGeo, new THREE.MeshBasicMaterial({ map: mirrorTarget.texture, depthTest: false }));
  hud.add(mirrorQuad);

  // Lumière : ciel + soleil rasant de fin de matinée
  scene.add(new THREE.HemisphereLight('#cfe3ff', '#6b5a43', 0.9));
  const sun = new THREE.DirectionalLight('#fff1dc', 2.6);
  sun.position.set(-45, 60, 20);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -45; sun.shadow.camera.right = 45;
  sun.shadow.camera.top = 45; sun.shadow.camera.bottom = -45;
  sun.shadow.camera.near = 10; sun.shadow.camera.far = 200;
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.03;
  scene.add(sun, sun.target);

  buildGround(scene);
  const decor = new THREE.Group(); decor.name = 'decor';
  scene.add(decor);

  const dynamic = new THREE.Group(); dynamic.name = 'situation';
  scene.add(dynamic);

  // ——— Météo et moment : beau, pluie, brouillard, neige, nuit ———
  const skies = { beau: scene.background, pluie: tex.sky('pluie'), nuit: tex.sky('nuit'), neige: tex.sky('neige') };
  const rain = createRain(); rain.visible = false; scene.add(rain);
  const hemi = scene.children.find((o) => o.isHemisphereLight);
  let weather = 'beau';
  const MOODS = {
    //            ciel     soleil  couleur      hémi  environnement exposition
    beau: { sky: 'beau', sun: 2.6, sunColor: '#fff1dc', hemi: 0.9, env: 0.55, exposure: 1.05 },
    pluie: { sky: 'pluie', sun: 0.9, sunColor: '#fff1dc', hemi: 0.75, env: 0.8, exposure: 1.05 },
    brouillard: { sky: 'beau', sun: 1.2, sunColor: '#fff1dc', hemi: 0.9, env: 0.55, exposure: 1.05 },
    neige: { sky: 'neige', sun: 0.8, sunColor: '#f4f6ff', hemi: 1.0, env: 0.7, exposure: 1.0 },
    nuit: { sky: 'nuit', sun: 0.32, sunColor: '#9fb6ff', hemi: 0.16, env: 0.12, exposure: 0.95 },
  };
  function setWeather(kind) {
    weather = MOODS[kind] ? kind : 'beau';
    const mood = MOODS[weather];
    const wet = weather === 'pluie';
    setFog(weather === 'brouillard' || weather === 'neige', weather === 'neige' ? '#dfe4ea' : '#c9d0d6');
    scene.background = skies[mood.sky];
    sun.intensity = mood.sun; sun.color.set(mood.sunColor);
    hemi.intensity = mood.hemi;
    scene.environmentIntensity = mood.env;
    renderer.toneMappingExposure = mood.exposure;
    for (const m of asphaltMaterials()) { m.roughness = wet ? 0.38 : 0.92; m.color.set(wet ? '#c9ccd2' : weather === 'neige' ? '#e9edf2' : '#ffffff'); }
    rain.visible = wet || weather === 'neige';
    rain.material.color.set(weather === 'neige' ? '#ffffff' : '#c7d6e6');
    rain.material.opacity = weather === 'neige' ? 0.9 : 0.55;
    dirty = true;
  }
  /** Brouillard ou neige : visibilité réduite à quelques dizaines de mètres (R413-4). Les distances dépendent de la vue. */
  let fogOn = false, fogColor = '#c9d0d6';
  function setFog(on, color = '#c9d0d6') { fogOn = on; fogColor = color; updateFog(); }
  function updateFog() {
    const driver = view.mode === 'conducteur';
    // Vue du dessus : la caméra est à 200 m de sa cible ; vue conducteur : distances réelles depuis les yeux
    const [near, far] = fogOn ? (driver ? (weather === 'neige' ? [15, 110] : [6, 48]) : [205, 255]) : (driver ? [90, 520] : [300, 520]);
    scene.fog = new THREE.Fog(fogOn ? fogColor : weather === 'nuit' ? '#0b1426' : '#d6e2ea', near, far);
    dirty = true;
  }
  /** Animation de la pluie ou de la neige ; renvoie true si l'image doit être redessinée. */
  function update(dt) {
    if (!rain.visible) return false;
    rain.position.set(view.target.x, 0, view.target.z);
    const snow = weather === 'neige';
    const speed = snow ? 3.5 : 26, len = snow ? 0.18 : 0.9;
    const pos = rain.geometry.attributes.position;
    for (let i = 0; i < pos.count; i += 2) {
      let y = pos.getY(i) - dt * speed;
      if (y < 0) y += 30;
      pos.setY(i, y); pos.setY(i + 1, y + len);
    }
    pos.needsUpdate = true;
    dirty = true;
    return true;
  }

  // ——— Rendu à la demande et qualité adaptative ———
  let dirty = true;
  const requestRender = () => { dirty = true; };
  const QUALITY = {
    haute: { ratio: Math.min(window.devicePixelRatio || 1, 2), shadows: true, map: 2048 },
    moyenne: { ratio: Math.min(window.devicePixelRatio || 1, 1.25), shadows: true, map: 1024 },
    basse: { ratio: 1, shadows: false, map: 512 },
  };
  let quality = 'haute';
  function setQuality(level) {
    if (!QUALITY[level]) return;
    quality = level;
    const q = QUALITY[level];
    renderer.setPixelRatio(q.ratio);
    renderer.shadowMap.enabled = q.shadows;
    sun.castShadow = q.shadows;
    if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; }
    sun.shadow.mapSize.set(q.map, q.map);
    scene.traverse((o) => { if (o.material) [].concat(o.material).forEach((m) => { m.needsUpdate = true; }); });
    resize();
  }
  /** Dessine l'image si quelque chose a changé ; renvoie true si un rendu a eu lieu. */
  function renderIfNeeded(force = false) {
    if (!dirty && !force) return false;
    dirty = false;
    renderer.info.reset(); // les compteurs couvrent toute l'image, rétroviseur compris
    if (view.mode !== 'conducteur') { renderer.render(scene, camera); return true; }
    poseDriver();
    // Vue avant (avec calcul des ombres), puis rétroviseur dans sa texture en réutilisant les mêmes ombres,
    // enfin l'image du rétroviseur posée par-dessus la vue avant
    renderer.render(scene, driverCam);
    if (view.mirrorRect) {
      renderer.shadowMap.autoUpdate = false;
      renderer.setRenderTarget(mirrorTarget); renderer.render(scene, mirrorCam); renderer.setRenderTarget(null);
      renderer.shadowMap.autoUpdate = true;
      renderer.autoClear = false; renderer.render(hud, hudCam); renderer.autoClear = true;
    }
    return true;
  }
  /** Place les caméras conducteur et rétroviseur selon la position et le cap de la voiture du joueur. */
  function poseDriver() {
    const { x, z, yaw } = view.driver;
    const fx = Math.sin(yaw), fz = Math.cos(yaw);
    // Siège conducteur à gauche : 0,38 m à gauche de l'axe, un peu en arrière du centre
    const ex = x + fz * 0.38 - fx * 0.15, ez = z - fx * 0.38 - fz * 0.15;
    driverCam.position.set(ex, 1.22, ez);
    driverCam.lookAt(ex + fx * 10, 1.22 - 0.55, ez + fz * 10);
    mirrorCam.position.set(ex + fx * 0.6 - fz * 0.38, 1.35, ez + fz * 0.6 + fx * 0.38);
    mirrorCam.lookAt(mirrorCam.position.x - fx * 10, 1.1, mirrorCam.position.z - fz * 10);
  }

  function resize() {
    const w = canvas.clientWidth || window.innerWidth, h = canvas.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    applyCamera(w / h);
    layoutDriver(w, h);
  }
  /** Vue conducteur : le point de fuite est placé dans la zone non couverte par la carte de question. */
  function layoutDriver(w, h) {
    const fx = view.focus.x, fy = view.focus.y;
    const fullW = 2 * Math.max(fx, 1 - fx) * w, fullH = 2 * Math.max(fy, 1 - fy) * h;
    driverCam.aspect = w / h;
    driverCam.setViewOffset(fullW, fullH, fullW / 2 - fx * w, fullH / 2 - fy * h, w, h);
    driverCam.updateProjectionMatrix();
    const mw = Math.min(330, w * 0.3), mh = mw * 0.29;
    const cx = fx * w;
    view.mirrorRect = { x: cx - mw / 2, y: Math.max(56, h * 0.07), w: mw, h: mh };
    mirrorCam.aspect = mw / mh; mirrorCam.updateProjectionMatrix();
    Object.assign(hudCam, { left: 0, right: w, top: h, bottom: 0 }); hudCam.updateProjectionMatrix();
    const r = view.mirrorRect;
    mirrorQuad.scale.set(r.w, r.h, 1); mirrorQuad.position.set(r.x + r.w / 2, h - (r.y + r.h / 2), 0);
    dirty = true;
  }
  /** Bascule entre la vue du dessus et la vue conducteur. */
  function setMode(mode) {
    view.mode = mode === 'conducteur' ? 'conducteur' : 'iso';
    updateFog();
    resize();
  }
  function applyCamera(aspect = (canvas.clientWidth || 1) / (canvas.clientHeight || 1)) {
    const half = view.zoom / 2;
    // Sur écran étroit (téléphone), on garde la largeur utile en élargissant la hauteur.
    const hw = aspect >= 1 ? half * aspect : half;
    const hh = aspect >= 1 ? half : half / aspect;
    const { x: fx, y: fy } = view.focus;
    Object.assign(camera, { left: -2 * hw * fx, right: 2 * hw * (1 - fx), top: 2 * hh * fy, bottom: -2 * hh * (1 - fy) });
    camera.position.copy(view.target).addScaledVector(view.dir, 200);
    camera.lookAt(view.target);
    camera.updateProjectionMatrix();
    dirty = true;
    // Le soleil suit la zone filmée pour garder des ombres nettes
    const focusPt = view.mode === 'conducteur'
      ? new THREE.Vector3(view.driver.x + Math.sin(view.driver.yaw) * 22, 0, view.driver.z + Math.cos(view.driver.yaw) * 22) : view.target;
    sun.position.copy(focusPt).add(new THREE.Vector3(view.dir.x > 0 ? -45 : 45, 60, 20));
    sun.target.position.copy(focusPt);
  }

  setQuality(window.__QUALITE || 'haute');
  return { renderer, scene, camera, view, dynamic, decor, sun, resize, applyCamera, requestRender, renderIfNeeded, setQuality, setMode, driverCam,
    setWeather, update, get weather() { return weather; }, get quality() { return quality; } };
}

function mat(opts) { return new THREE.MeshStandardMaterial(opts); }

function createRain(count = 1400) {
  const pts = new Float32Array(count * 6);
  for (let i = 0; i < count; i++) {
    const x = (Math.random() - 0.5) * 90, z = (Math.random() - 0.5) * 90, y = Math.random() * 30;
    pts.set([x, y, z, x + 0.12, y + 0.9, z + 0.12], i * 6);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pts, 3));
  const rain = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: '#c7d6e6', transparent: true, opacity: 0.55 }));
  rain.frustumCulled = false; rain.name = 'pluie';
  return rain;
}

function buildGround(group) {
  const g = tex.grass(); g.repeat.set(500, 500);
  const n = tex.photoNormal('herbe', 500);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000).rotateX(-Math.PI / 2), mat({ map: g, roughness: 1, ...(n ? { normalMap: n } : {}) }));
  ground.position.set(0, -0.02, -60);
  ground.receiveShadow = true;
  group.add(ground);
}


export function signAnchor(site, approach) {
  if (site === 'giratoire') {
    const { cx, cz, outer } = GIRATOIRE;
    const r = { S: 0, E: Math.PI / 2, N: Math.PI, W: -Math.PI / 2 }[approach] || 0;
    const v = new THREE.Vector3(ROAD_HALF + 1.4, 0, outer + 2.2).applyAxisAngle(new THREE.Vector3(0, 1, 0), r);
    return { x: cx + v.x, z: cz + v.z, rotY: r };
  }
  const anchors = {
    S: { x: ROAD_HALF + 1.2, z: ROAD_HALF + 2.2, rotY: 0 },
    N: { x: -(ROAD_HALF + 1.2), z: -(ROAD_HALF + 2.2), rotY: Math.PI },
    E: { x: ROAD_HALF + 2.2, z: -(ROAD_HALF + 1.2), rotY: Math.PI / 2 },
    W: { x: -(ROAD_HALF + 2.2), z: ROAD_HALF + 1.2, rotY: -Math.PI / 2 },
  };
  return anchors[approach];
}

/** Marquage au sol lié au panneau : ligne continue (stop) ou discontinue (cédez le passage). */
export function createYieldMarking(type, site, approach) {
  const g = new THREE.Group(); g.name = `marquage-${type}`;
  const mark = new THREE.MeshStandardMaterial({ color: '#f4f4ef', roughness: 0.55 });
  // Ligne sur la seule voie d'arrivée (de l'axe au bord droit), juste avant la chaussée croisée
  const offset = site === 'giratoire' ? GIRATOIRE.outer + 0.35 : ROAD_HALF + 0.35;
  const width = 0.5;
  const seg = (x0, x1) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(x1 - x0, width).rotateX(-Math.PI / 2), mark); m.position.set((x0 + x1) / 2, 0.028, 0); g.add(m); };
  if (type === 'stop') seg(0, ROAD_HALF);
  else for (let x = 0.1; x < ROAD_HALF - 0.2; x += 1.0) seg(x, x + 0.6);
  // Orientation : construit pour une arrivée par le sud puis tourné
  const rot = { S: 0, N: Math.PI, E: Math.PI / 2, W: -Math.PI / 2 }[approach] || 0;
  g.rotation.y = rot;
  const base = site === 'giratoire' ? { x: GIRATOIRE.cx, z: GIRATOIRE.cz } : { x: 0, z: 0 };
  const local = new THREE.Vector3(0, 0, offset).applyAxisAngle(new THREE.Vector3(0, 1, 0), rot);
  g.position.set(base.x + local.x, 0, base.z + local.z);
  return g;
}
