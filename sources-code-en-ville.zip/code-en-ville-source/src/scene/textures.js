// Textures : photographies CC0 (src/scene/photos.js) quand elles sont chargées, sinon dessin procédural sur canvas.
import * as THREE from 'three';
import { PHOTOS } from './photos.js';

/** Texture répétée à partir d'une photo ; `repeat` : nombre de répétitions pour 12 m (unité des coordonnées de texture du kit). */
function photo(name, kind = 'color', repeat = 1) {
  const img = PHOTOS[name]?.[kind];
  if (!img) return null;
  const t = new THREE.Texture(img);
  t.needsUpdate = true;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat, repeat);
  t.anisotropy = 8;
  if (kind === 'color') t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
/** Texture de relief (normal map) d'une photo, ou null. */
export const photoNormal = (name, repeat = 1) => photo(name, 'normal', repeat);
export const photoColor = (name, repeat = 1) => photo(name, 'color', repeat);

function canvas(w, h = w) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return [c, c.getContext('2d')];
}

function finish(c, { repeat = 1, srgb = true, anisotropy = 4 } = {}) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat, repeat);
  t.anisotropy = anisotropy;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Bruit multi-échelle pour l'enrobé, le trottoir, l'herbe. */
function grain(ctx, size, base, spread, count, alpha = 0.5) {
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, size, size);
  for (let i = 0; i < count; i++) {
    const v = Math.floor(Math.random() * spread);
    const r = Math.random() < 0.85 ? Math.random() * 1.2 + 0.3 : Math.random() * 3 + 1;
    ctx.fillStyle = `rgba(${v},${v},${v},${alpha * Math.random()})`;
    ctx.beginPath();
    ctx.arc(Math.random() * size, Math.random() * size, r, 0, Math.PI * 2);
    ctx.fill();
  }
}

export function asphalt() {
  const p = photo('enrobe', 'color', 3); if (p) return p;
  const s = 512; const [c, ctx] = canvas(s);
  grain(ctx, s, '#4a4c50', 255, 26000, 0.32);
  // Taches et reprises d'enrobé, plus sombres
  for (let i = 0; i < 14; i++) {
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, 60 + Math.random() * 90);
    g.addColorStop(0, 'rgba(20,20,24,0.16)'); g.addColorStop(1, 'rgba(20,20,24,0)');
    ctx.save(); ctx.translate(Math.random() * s, Math.random() * s);
    ctx.fillStyle = g; ctx.fillRect(-160, -160, 320, 320); ctx.restore();
  }
  return finish(c, { repeat: 1 });
}

export function pavement() {
  const p = photo('trottoir', 'color', 6); if (p) return p;
  const s = 256; const [c, ctx] = canvas(s);
  grain(ctx, s, '#b9b4aa', 200, 6000, 0.25);
  ctx.strokeStyle = 'rgba(90,85,78,0.35)'; ctx.lineWidth = 2;
  for (let i = 0; i <= s; i += 64) {
    ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, s); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(s, i); ctx.stroke();
  }
  return finish(c);
}

export function grass() {
  const p = photo('herbe', 'color', 3); if (p) return p;
  const s = 256; const [c, ctx] = canvas(s);
  ctx.fillStyle = '#5f8a3f'; ctx.fillRect(0, 0, s, s);
  for (let i = 0; i < 9000; i++) {
    const g = 90 + Math.random() * 80;
    ctx.fillStyle = `rgba(${g * 0.55},${g},${g * 0.35},${0.5 * Math.random()})`;
    ctx.fillRect(Math.random() * s, Math.random() * s, 1.5, 3);
  }
  return finish(c);
}

/** Façade : couleur d'enduit + fenêtres avec reflets de ciel. */
export function facade(wall, floors, cols, brique = false) {
  const w = 256, h = 64 * floors; const [c, ctx] = canvas(w, h);
  ctx.fillStyle = wall; ctx.fillRect(0, 0, w, h);
  const base = PHOTOS[brique ? 'brique' : 'enduit']?.color;
  if (base) {
    // Enduit (teinté de la couleur du mur) ou brique réelle, en mosaïque
    for (let y = 0; y < h; y += 128) for (let x = 0; x < w; x += 128) ctx.drawImage(base, x, y, 128, 128);
    if (!brique) { ctx.globalCompositeOperation = 'multiply'; ctx.fillStyle = wall; ctx.fillRect(0, 0, w, h); ctx.globalCompositeOperation = 'source-over'; }
  } else grain(ctx, Math.max(w, h), wall, 255, 2500, 0.06);
  const cw = w / cols;
  for (let f = 0; f < floors; f++) {
    for (let i = 0; i < cols; i++) {
      const x = i * cw + cw * 0.22, y = f * 64 + 14, ww = cw * 0.56, wh = 38;
      const g = ctx.createLinearGradient(0, y, 0, y + wh);
      const lit = Math.random() < 0.12;
      g.addColorStop(0, lit ? '#f6d48a' : '#9fc0d8');
      g.addColorStop(1, lit ? '#c9954a' : '#3d566b');
      ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x - 2, y - 2, ww + 4, wh + 5);
      ctx.fillStyle = g; ctx.fillRect(x, y, ww, wh);
      ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.fillRect(x, y + wh / 2 - 1, ww, 2);
      ctx.fillRect(x + ww / 2 - 1, y, 2, wh);
    }
  }
  const t = finish(c, { anisotropy: 8 });
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

/** Ciel en dégradé, utilisé comme fond de scène. */
export function sky(kind = 'beau') {
  const [c, ctx] = canvas(16, 512);
  const g = ctx.createLinearGradient(0, 0, 0, 512);
  const stops = { pluie: ['#5d6a78', '#8c98a4', '#b4bcc3'], nuit: ['#050a18', '#0d1a33', '#1d2b45'], neige: ['#9aa6b2', '#c4ccd4', '#e2e6ea'] }[kind] || ['#6f9fcf', '#bcd6ea', '#efe6d6'];
  g.addColorStop(0, stops[0]);
  g.addColorStop(0.55, stops[1]);
  g.addColorStop(1, stops[2]);
  ctx.fillStyle = g; ctx.fillRect(0, 0, 16, 512);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Panneaux de signalisation (faces dessinées en vectoriel sur canvas). */
export function signFace(type) {
  const s = 256; const [c, ctx] = canvas(s);
  ctx.clearRect(0, 0, s, s);
  if (type === 'stop') {
    // Octogone rouge, liseré blanc, inscription STOP
    const oct = (r) => { ctx.beginPath(); for (let i = 0; i < 8; i++) { const a = Math.PI / 8 + (i * Math.PI) / 4; ctx.lineTo(s / 2 + r * Math.cos(a), s / 2 + r * Math.sin(a)); } ctx.closePath(); };
    ctx.fillStyle = '#ffffff'; oct(124); ctx.fill();
    ctx.fillStyle = '#c8102e'; oct(112); ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 74px Arial, Helvetica, sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('STOP', s / 2, s / 2 + 4);
  } else if (type === 'piste') {
    // Piste ou bande cyclable obligatoire : disque bleu, vélo blanc
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(128, 128, 123, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#1d4f9c'; ctx.beginPath(); ctx.arc(128, 128, 115, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 11; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath(); ctx.arc(82, 150, 32, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(174, 150, 32, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(82, 150); ctx.lineTo(112, 102); ctx.lineTo(156, 102); ctx.lineTo(174, 150);
    ctx.moveTo(112, 102); ctx.lineTo(132, 150); ctx.lineTo(156, 102); ctx.moveTo(104, 88); ctx.lineTo(122, 88);
    ctx.moveTo(150, 86); ctx.lineTo(164, 86); ctx.stroke();
  } else if (type === 'sortie-agglo') {
    // Sortie d'agglomération : panneau blanc bordé de rouge, nom de la commune barré d'une bande rouge
    ctx.fillStyle = '#ffffff'; ctx.fillRect(6, 72, 244, 112);
    ctx.strokeStyle = '#c8102e'; ctx.lineWidth = 9; ctx.strokeRect(12, 78, 232, 100);
    ctx.fillStyle = '#111111'; ctx.font = 'bold 44px Arial, Helvetica, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('LES PRÉS', 128, 131);
    ctx.strokeStyle = '#c8102e'; ctx.lineWidth = 12; ctx.beginPath(); ctx.moveTo(30, 168); ctx.lineTo(226, 90); ctx.stroke();
  } else if (type === 'cedez') {
    // Triangle pointe en bas, bordure rouge, fond blanc
    const tri = (m) => { ctx.beginPath(); ctx.moveTo(m, m * 1.3); ctx.lineTo(s - m, m * 1.3); ctx.lineTo(s / 2, s - m * 0.6); ctx.closePath(); };
    ctx.fillStyle = '#ffffff'; ctx.lineJoin = 'round';
    tri(8); ctx.fill();
    ctx.strokeStyle = '#c8102e'; ctx.lineWidth = 26; tri(26); ctx.stroke();
  }
  return finish(c, { anisotropy: 8 });
}

/** Revers gris métallique d'un panneau. */
export function signBack() {
  const [c, ctx] = canvas(64);
  grain(ctx, 64, '#9aa0a6', 255, 400, 0.15);
  return finish(c);
}
