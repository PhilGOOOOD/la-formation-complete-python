// Kit d'accessoires de scène : feux tricolores, lampadaires, passage à niveau, triangle, borne, passage piéton.
// Chaque accessoire renvoie { object, tick?(time) → bool, setState?(état), setBarrier?(k) }.
import * as THREE from 'three';
import { ROAD_HALF } from './routes.js';

const cache = new Map();
function sharedRes(key, make) { if (!cache.has(key)) { const r = make(); r.userData.shared = true; cache.set(key, r); } return cache.get(key); }
const std = (key, opts) => sharedRes(`m:${key}`, () => new THREE.MeshStandardMaterial(opts));
const cube = () => sharedRes('g:cube', () => new THREE.BoxGeometry(1, 1, 1));
function box(parent, mat, x, y, z, w, h, d, cast = true) { const m = new THREE.Mesh(cube(), mat); m.scale.set(w, h, d); m.position.set(x, y, z); m.castShadow = cast; m.receiveShadow = true; parent.add(m); return m; }
const ROT = { S: 0, N: Math.PI, E: Math.PI / 2, W: -Math.PI / 2 };
/** Place un objet construit pour l'arrivée par le sud sur la branche demandée d'un carrefour centré en (0,0). */
function onApproach(obj, approach, local) {
  const r = ROT[approach] || 0;
  const v = new THREE.Vector3(local.x, 0, local.z).applyAxisAngle(new THREE.Vector3(0, 1, 0), r);
  obj.position.set(v.x, 0, v.z); obj.rotation.y = r;
  return obj;
}
/** Disque lumineux au sol (lumière d'un lampadaire, de nuit). */
function glowDisc(radius, color) {
  const tex = sharedRes('t:glow', () => {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const ctx = c.getContext('2d'); const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
    g.addColorStop(0, 'rgba(255,255,255,0.9)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, 128, 128);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
  });
  const m = new THREE.Mesh(sharedRes('g:disc', () => new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2)),
    sharedRes(`m:glow:${color}`, () => new THREE.MeshBasicMaterial({ map: tex, color, transparent: true, opacity: 0.75, depthWrite: false, blending: THREE.AdditiveBlending })));
  m.scale.set(radius * 2, 1, radius * 2); m.position.y = 0.06; m.renderOrder = 2;
  return m;
}

/** Une tête de feu (trois lampes) sur son mât ; renvoie le groupe et ses trois matériaux. */
function lightHead(mats, colors) {
  const g = new THREE.Group();
  const pole = std('poteau-feu', { color: '#4b5157', metalness: 0.7, roughness: 0.4 });
  // Tête de feu à hauteur réaliste (bas du boîtier vers 2 m), légèrement agrandie pour rester lisible de haut
  box(g, pole, 0, 1.3, 0, 0.14, 2.6, 0.14, false);
  box(g, std('boitier-feu', { color: '#15171a', roughness: 0.6 }), 0, 2.75, 0.05, 0.62, 1.5, 0.38); // seul le boîtier porte une ombre
  const lamp = sharedRes('g:lampe', () => new THREE.SphereGeometry(0.21, 16, 10));
  [['rouge', 3.2], ['jaune', 2.75], ['vert', 2.3]].forEach(([k, y]) => { const l = new THREE.Mesh(lamp, mats[k]); l.position.set(0, y, 0.22); l.scale.z = 0.5; g.add(l); });
  g.scale.setScalar(1.2);
  return g;
}
/**
 * Feu tricolore d'une arrivée ; état : rouge | jaune | vert | jaune-clignotant | eteint.
 * Deux têtes allumées ensemble : l'une à droite avant le carrefour, l'autre de l'autre côté (visible depuis le siège du conducteur).
 */
function trafficLight(spec) {
  const g = new THREE.Group(); g.name = `feu-${spec.approach}`;
  const colors = { rouge: ['#4a0a0a', '#ff2a1a'], jaune: ['#4a3500', '#ffb000'], vert: ['#063a1c', '#19e06a'] };
  const mats = {};
  for (const k of Object.keys(colors)) mats[k] = new THREE.MeshStandardMaterial({ color: colors[k][0], emissive: colors[k][1], emissiveIntensity: 0, roughness: 0.3 });
  const near = lightHead(mats, colors); near.position.set(ROAD_HALF + 1.0, 0, ROAD_HALF + 2.0); near.rotation.y = 0.35;
  const far = lightHead(mats, colors); far.position.set(ROAD_HALF + 1.0, 0, -(ROAD_HALF + 2.0)); far.rotation.y = 0.1;
  g.add(near, far);
  onApproach(g, spec.approach, { x: 0, z: 0 });
  let state = spec.state || 'rouge';
  const apply = (on = true) => {
    for (const k of Object.keys(mats)) mats[k].emissiveIntensity = 0;
    if (state === 'jaune-clignotant') mats.jaune.emissiveIntensity = on ? 3.2 : 0;
    else if (mats[state]) mats[state].emissiveIntensity = 3.2;
  };
  apply();
  let lastOn = true;
  return {
    object: g,
    get state() { return state; },
    setState(s) { state = s; apply(); },
    tick(time) {
      if (state !== 'jaune-clignotant') return false;
      const on = Math.floor(time / 0.6) % 2 === 0;
      if (on === lastOn) return false;
      lastOn = on; apply(on); return true;
    },
  };
}

/** Lampadaire ; de nuit, la tête s'allume et éclaire le sol. */
function streetLamp(spec, { night }) {
  const g = new THREE.Group(); g.name = 'lampadaire';
  const metal = std('lampadaire', { color: '#5b6168', metalness: 0.7, roughness: 0.4 });
  box(g, metal, 0, 3.2, 0, 0.14, 6.4, 0.14);
  box(g, metal, 0.7, 6.35, 0, 1.5, 0.1, 0.12);
  const head = std(`tete-lampadaire:${night}`, { color: '#e8e2cf', emissive: '#ffd9a0', emissiveIntensity: night ? 5 : 0, roughness: 0.4 });
  box(g, head, 1.35, 6.25, 0, 0.6, 0.12, 0.34, false);
  if (night) { const d = glowDisc(7.5, '#ffcf8a'); d.position.x = 1.35; g.add(d); }
  g.position.set(spec.x, 0, spec.z);
  g.rotation.y = spec.x > 0 ? Math.PI : 0; // la tête penche vers la chaussée
  return { object: g };
}

/** Passage à niveau en travers de la route de campagne : rails, demi-barrières et feux rouges clignotants. */
function levelCrossing(spec) {
  const g = new THREE.Group(); g.name = 'passage-niveau';
  const z = spec.z;
  const rail = std('rail', { color: '#9aa1a8', metalness: 0.9, roughness: 0.3 });
  const ballast = std('ballast', { color: '#6f6a63', roughness: 1 });
  box(g, ballast, 0, 0.02, z, 120, 0.04, 3.6, false);
  for (const dz of [-0.72, 0.72]) box(g, rail, 0, 0.14, z + dz, 120, 0.12, 0.1, false);
  const sleeperGeo = cube();
  const sleepers = new THREE.InstancedMesh(sleeperGeo, std('traverse', { color: '#4a3b2e', roughness: 1 }), 100);
  const mtx = new THREE.Matrix4();
  for (let i = 0; i < 100; i++) sleepers.setMatrixAt(i, mtx.compose(new THREE.Vector3(-60 + i * 1.2, 0.07, z), new THREE.Quaternion(), new THREE.Vector3(0.25, 0.08, 2.6)));
  sleepers.receiveShadow = true; g.add(sleepers);
  // Demi-barrières (rayées rouge et blanc) et feux, côté droit de chaque sens
  const stripes = sharedRes('m:barriere', () => {
    const c = document.createElement('canvas'); c.width = 128; c.height = 8;
    const ctx = c.getContext('2d'); for (let i = 0; i < 8; i++) { ctx.fillStyle = i % 2 ? '#ffffff' : '#c8102e'; ctx.fillRect(i * 16, 0, 16, 8); }
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
    return new THREE.MeshStandardMaterial({ map: t, roughness: 0.5 });
  });
  const post = std('poteau-pn', { color: '#f2f2f2', roughness: 0.5 });
  const arms = [];
  const reds = [new THREE.MeshStandardMaterial({ color: '#4a0a0a', emissive: '#ff2a1a', emissiveIntensity: 0 }), new THREE.MeshStandardMaterial({ color: '#4a0a0a', emissive: '#ff2a1a', emissiveIntensity: 0 })];
  const lamp = sharedRes('g:lampe', () => new THREE.SphereGeometry(0.2, 16, 10));
  for (const s of [1, -1]) {
    const base = new THREE.Group(); base.position.set(s * (ROAD_HALF + 1.2), 0, z + s * 3.2); base.rotation.y = s > 0 ? 0 : Math.PI; g.add(base);
    box(base, post, 0, 1.4, 0, 0.22, 2.8, 0.22);
    // Feux rouges jumelés, face aux conducteurs qui arrivent
    box(base, std('boitier-feu', { color: '#15171a', roughness: 0.6 }), 0, 2.7, 0.18, 1.3, 0.6, 0.2, false);
    [-0.34, 0.34].forEach((dx, i) => { const l = new THREE.Mesh(lamp, reds[i]); l.position.set(dx, 2.7, 0.32); l.scale.set(1.2, 1.2, 0.5); base.add(l); });
    const pivot = new THREE.Group(); pivot.position.set(-s * 0.2 * s, 1.0, 0); base.add(pivot);
    const arm = box(pivot, stripes, -2.1, 0, 0, 4.2, 0.18, 0.12);
    arm.castShadow = true;
    arms.push(pivot);
  }
  g.scale.setScalar(1);
  let closed = { ouvert: 0, fermeture: 0.5, ferme: 1 }[spec.state || 'ouvert'];
  let flashing = spec.feux !== false && spec.state !== 'ouvert' ? true : !!spec.feux;
  const applyBarrier = () => arms.forEach((p) => { p.rotation.z = -(1 - closed) * (Math.PI / 2 - 0.05); });
  applyBarrier();
  let phase = -1;
  return {
    object: g,
    setBarrier(k) { closed = k; applyBarrier(); },
    get barrier() { return closed; },
    setFlashing(on) { flashing = on; if (!on) { reds.forEach((m) => { m.emissiveIntensity = 0; }); phase = -1; } },
    tick(time) {
      if (!flashing) return false;
      const p = Math.floor(time / 0.5) % 2;
      if (p === phase) return false;
      phase = p; reds[0].emissiveIntensity = p ? 0 : 3.5; reds[1].emissiveIntensity = p ? 3.5 : 0;
      return true;
    },
  };
}

function warningTriangle(spec) {
  const g = new THREE.Group(); g.name = 'triangle';
  const shape = new THREE.Shape([new THREE.Vector2(-0.45, 0), new THREE.Vector2(0.45, 0), new THREE.Vector2(0, 0.78)]);
  const hole = new THREE.Path([new THREE.Vector2(-0.25, 0.1), new THREE.Vector2(0, 0.55), new THREE.Vector2(0.25, 0.1)]);
  shape.holes.push(hole);
  const tri = new THREE.Mesh(sharedRes('g:triangle', () => new THREE.ShapeGeometry(shape)), std('triangle', { color: '#d1121f', emissive: '#7a0008', emissiveIntensity: 0.6, roughness: 0.3, side: THREE.DoubleSide }));
  tri.position.y = 0.06; tri.rotation.x = -0.15; tri.castShadow = true; g.add(tri);
  g.scale.setScalar(1.8);
  g.position.set(spec.x, 0, spec.z); g.rotation.y = spec.rotY ?? 0.4;
  return { object: g };
}

function roadsideMarker(spec) {
  const g = new THREE.Group(); g.name = 'borne';
  box(g, std('borne', { color: '#f4f4f0', roughness: 0.6 }), 0, 0.5, 0, 0.45, 1.0, 0.3);
  box(g, std('borne-tete', { color: '#c8102e', roughness: 0.5 }), 0, 1.08, 0, 0.47, 0.22, 0.32);
  g.scale.setScalar(1.4); g.position.set(spec.x, 0, spec.z);
  return { object: g };
}

/** Bandes de passage piéton en travers d'une branche de carrefour (à 7 m du centre). */
function zebra(spec) {
  const g = new THREE.Group(); g.name = 'passage-pieton';
  const paint = std('peinture-zebra', { color: '#f2f2ee', roughness: 0.6 });
  const strip = sharedRes('g:bande', () => new THREE.PlaneGeometry(0.5, 2.6).rotateX(-Math.PI / 2));
  // Construit pour la branche est (bandes parallèles à l'axe de la route, donc selon x)
  for (let z = -ROAD_HALF + 0.5; z < ROAD_HALF; z += 1) { const m = new THREE.Mesh(strip, paint); m.rotation.y = Math.PI / 2; m.position.set(7.2, 0.03, z); m.receiveShadow = true; g.add(m); }
  // La branche est correspond à une rotation de -90° par rapport à « est » ; on tourne le groupe autour du centre
  g.rotation.y = { E: 0, N: Math.PI / 2, W: Math.PI, S: -Math.PI / 2 }[spec.approach] || 0;
  return { object: g };
}

export function createProp(spec, opts = {}) {
  switch (spec.type) {
    case 'feu': return trafficLight(spec);
    case 'lampadaire': return streetLamp(spec, opts);
    case 'pn': return levelCrossing(spec);
    case 'triangle': return warningTriangle(spec);
    case 'borne': return roadsideMarker(spec);
    case 'zebra': return zebra(spec);
    default: throw new Error(`Accessoire inconnu : ${spec.type}`);
  }
}
