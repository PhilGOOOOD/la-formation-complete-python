// Trajectoires des véhicules — géométrie pure (pas de Three.js), testable sous Node.
// Repère : plan XZ, X vers l'est, Z vers le sud (le nord est en -Z).
// Circulation à droite : chaque voie est décalée de LANE vers la droite du sens de marche.

export const LANE = 2;            // décalage de l'axe d'une voie par rapport au centre de la chaussée
export const ROAD_HALF = 4;       // demi-largeur de chaussée (2 voies de 4 m)
export const CAR_HALF_LEN = 2.15; // demi-longueur d'une voiture
export const GIRATOIRE = { cx: 0, cz: 0, island: 7, outer: 14, laneR: 10.5 };

const HEADINGS = { N: { x: 0, z: -1 }, S: { x: 0, z: 1 }, E: { x: 1, z: 0 }, W: { x: -1, z: 0 } };
// Un véhicule qui vient du sud roule vers le nord, etc.
const INBOUND = { S: 'N', N: 'S', E: 'W', W: 'E' };

export const add = (a, b) => ({ x: a.x + b.x, z: a.z + b.z });
export const sub = (a, b) => ({ x: a.x - b.x, z: a.z - b.z });
export const mul = (a, k) => ({ x: a.x * k, z: a.z * k });
export const len = (a) => Math.hypot(a.x, a.z);
/** Vecteur « droite » du conducteur pour un cap donné (Y vers le haut). */
export const rightOf = (h) => ({ x: -h.z, z: h.x });

function sampleLine(a, b, step = 0.5) {
  const n = Math.max(1, Math.ceil(len(sub(b, a)) / step));
  return Array.from({ length: n }, (_, i) => add(a, mul(sub(b, a), (i + 1) / n)));
}
function sampleQuad(a, c, b, n = 24) {
  const pts = [];
  for (let i = 1; i <= n; i++) {
    const t = i / n, u = 1 - t;
    pts.push({ x: u * u * a.x + 2 * u * t * c.x + t * t * b.x, z: u * u * a.z + 2 * u * t * c.z + t * t * b.z });
  }
  return pts;
}
function sampleArc(center, r, a0, a1, step = 0.4) {
  const n = Math.max(2, Math.ceil(Math.abs(a1 - a0) * r / step));
  return Array.from({ length: n }, (_, i) => {
    const a = a0 + (a1 - a0) * ((i + 1) / n);
    return { x: center.x + r * Math.cos(a), z: center.z + r * Math.sin(a) };
  });
}

/** Ajoute les longueurs cumulées et renvoie une route exploitable. */
function finalize(points, holdPoint) {
  const cum = [0];
  for (let i = 1; i < points.length; i++) cum.push(cum[i - 1] + len(sub(points[i], points[i - 1])));
  let holdIndex = 0, best = Infinity;
  points.forEach((p, i) => { const d = len(sub(p, holdPoint)); if (d < best) { best = d; holdIndex = i; } });
  return { points, cum, length: cum[cum.length - 1], hold: cum[holdIndex] };
}

/** Position et cap le long d'une route à la distance s. */
export function pointAt(route, s) {
  const { points, cum } = route;
  const d = Math.min(Math.max(s, 0), route.length);
  let i = 1;
  while (i < cum.length - 1 && cum[i] < d) i++;
  const a = points[i - 1], b = points[i];
  const seg = cum[i] - cum[i - 1] || 1;
  const t = (d - cum[i - 1]) / seg;
  const p = add(a, mul(sub(b, a), t));
  return { x: p.x, z: p.z, angle: Math.atan2(b.x - a.x, b.z - a.z) };
}

/** Route dans le carrefour en croix centré sur (0,0). action : straight | right | left */
export function intersectionRoute(from, action, { reach = 40, holdGap = 0.7 } = {}) {
  const h = HEADINGS[INBOUND[from]];
  const r = rightOf(h);
  const lane = mul(r, LANE);
  const start = add(mul(h, -reach), lane);
  const holdPoint = add(mul(h, -(ROAD_HALF + holdGap + CAR_HALF_LEN)), lane);
  const entry = add(mul(h, -ROAD_HALF), lane);
  let pts = [start, ...sampleLine(start, entry)];
  if (action === 'straight') {
    pts.push(...sampleLine(entry, add(mul(h, reach), lane)));
  } else {
    const out = action === 'right' ? r : mul(r, -1);
    const r2 = rightOf(out);
    const exitPt = add(mul(out, ROAD_HALF), mul(r2, LANE));
    const ctrl = add(mul(r, LANE), mul(r2, LANE));
    pts.push(...sampleQuad(entry, ctrl, exitPt));
    pts.push(...sampleLine(exitPt, add(mul(out, reach), mul(r2, LANE))));
  }
  return finalize(pts, holdPoint);
}

/** Routes du carrefour à sens giratoire (anneau parcouru dans le sens antihoraire vu de dessus). */
export function giratoireRoute(kind) {
  const { cx, cz, outer, laneR } = GIRATOIRE;
  const c = { x: cx, z: cz };
  const deg = (d) => (d * Math.PI) / 180;
  const ringPt = (a) => ({ x: cx + laneR * Math.cos(deg(a)), z: cz + laneR * Math.sin(deg(a)) });

  if (kind === 'ring-east') {
    // Le joueur arrive du sud, entre sur l'anneau puis sort à l'est.
    const start = { x: cx + LANE, z: cz + 50 };
    const holdPoint = { x: cx + LANE, z: cz + outer + 0.8 + CAR_HALF_LEN };
    const entry = { x: cx + LANE, z: cz + outer };
    const join = ringPt(62);
    const pts = [start, ...sampleLine(start, entry)];
    pts.push(...sampleQuad(entry, { x: cx + LANE + 0.6, z: cz + laneR + 0.6 }, join, 16));
    pts.push(...sampleArc(c, laneR, deg(62), deg(24)));
    const exitPt = { x: cx + outer, z: cz + LANE };
    pts.push(...sampleQuad(ringPt(24), { x: cx + outer - 1.2, z: cz + LANE + 1.4 }, exitPt, 14));
    pts.push(...sampleLine(exitPt, { x: cx + 60, z: cz + LANE }));
    return finalize(pts, holdPoint);
  }
  if (kind === 'ring-north') {
    // Véhicule déjà engagé sur l'anneau, venant de la gauche du joueur, qui sort au nord.
    const pts = [ringPt(215)];
    pts.push(...sampleArc(c, laneR, deg(215), deg(-62)));
    const exitPt = { x: cx + LANE, z: cz - outer };
    pts.push(...sampleQuad(ringPt(-62), { x: cx + LANE + 1.4, z: cz - outer + 1.2 }, exitPt, 14));
    pts.push(...sampleLine(exitPt, { x: cx + LANE, z: cz - 60 }));
    return finalize(pts, ringPt(150));
  }
  throw new Error(`Route de giratoire inconnue : ${kind}`);
}

// ——— Autres environnements : coordonnées locales (joueur vers le nord = -Z), décalées par l'origine du site ———
// Depuis la v0.3, chaque scène est construite seule autour de l'origine avec le kit de tuiles (20 m) :
// toutes les origines valent 0 et les constantes ci-dessous sont alignées sur les bords de tuiles.
export const RUE = { ox: 0, oz: 0, pisteX: 7.4, pisteMin: 6.6, pisteMax: 8.2, bayX: 5.3, bayMin: 4.2, bayMax: 6.4,
  baysFrom: 30, baysTo: 50, freeBayZ: 37.5, zebraZ: 13, sidewalk: 8.4 };
export const CAMPAGNE = { ox: 0, oz: 0, signZ: 3, solidFrom: -30, solidTo: -90 };
export const AUTOROUTE = { ox: 0, oz: 0, median: 1.5, leftLane: 3.25, rightLane: 6.75, edge: 8.5, bau: 11,
  insertX: 10.25, insertFrom: 70, insertEnd: -10, mergeEnd: -30 };
export const SITES = {
  intersection: { ox: 0, oz: 0 },
  giratoire: { ox: GIRATOIRE.cx, oz: GIRATOIRE.cz },
  rue: RUE, campagne: CAMPAGNE, autoroute: AUTOROUTE,
};

/** Route décrite par une suite de points locaux (lignes droites échantillonnées). */
function localRoute(site, keyPoints, holdLocal) {
  const { ox, oz } = SITES[site];
  const w = (p) => ({ x: p.x + ox, z: p.z + oz });
  const pts = [w(keyPoints[0])];
  for (let i = 1; i < keyPoints.length; i++) {
    const k = keyPoints[i];
    if (k.ctrl) pts.push(...sampleQuad(pts[pts.length - 1], w(k.ctrl), w(k), 18));
    else pts.push(...sampleLine(pts[pts.length - 1], w(k)));
  }
  return finalize(pts, w(holdLocal));
}

/** Changement de voie progressif (courbe en S) entre deux abscisses sur une distance donnée. */
function laneChange(x0, x1, zStart, zEnd, n = 10) {
  const out = [];
  for (let i = 1; i <= n; i++) {
    const t = i / n, k = t * t * (3 - 2 * t);
    out.push({ x: x0 + (x1 - x0) * k, z: zStart + (zEnd - zStart) * t });
  }
  return out;
}

const LOCAL_ROUTES = {
  rue: {
    // Le joueur tourne à droite dans la rue transversale et traverse la piste cyclable.
    'right-cross': () => localRoute('rue', [{ x: LANE, z: 40 }, { x: LANE, z: ROAD_HALF }, { x: ROAD_HALF, z: LANE, ctrl: { x: LANE, z: LANE } }, { x: 45, z: LANE }], { x: LANE, z: 7 }),
    // Cycliste sur la piste unidirectionnelle, vers le nord.
    'piste-north': () => localRoute('rue', [{ x: RUE.pisteX, z: 44 }, { x: RUE.pisteX, z: -40 }], { x: RUE.pisteX, z: 12.5 }),
    // Le joueur se gare dans la place libre, en marche avant.
    park: () => localRoute('rue', [{ x: LANE, z: 72 }, { x: LANE, z: RUE.freeBayZ + 7 }, { x: RUE.bayX, z: RUE.freeBayZ - 1, ctrl: { x: LANE + 0.4, z: RUE.freeBayZ + 1.5 } }, { x: RUE.bayX, z: RUE.freeBayZ - 2 }], { x: LANE, z: 49 }),
  },
  campagne: {
    'rural-straight': () => localRoute('campagne', [{ x: LANE, z: 44 }, { x: LANE, z: -40 }], { x: LANE, z: 9 }),
    tractor: () => localRoute('campagne', [{ x: LANE, z: -34 }, { x: LANE, z: -170 }], { x: LANE, z: -50 }),
    // Cycliste au bord droit de la chaussée
    'velo-rive': () => localRoute('campagne', [{ x: 3.1, z: -34 }, { x: 3.1, z: -170 }], { x: 3.1, z: -50 }),
    // Dépassement immédiat sur ligne discontinue
    'rural-overtake': () => localRoute('campagne', [{ x: LANE, z: -12 }, { x: LANE, z: -44 },
      ...laneChange(LANE, -LANE, -44, -56), { x: -LANE, z: -68 }, ...laneChange(-LANE, LANE, -68, -82), { x: LANE, z: -175 }], { x: LANE, z: -41.5 }),
    // Dépassement d'un cycliste en chevauchant seulement l'axe (roues gauches au-delà de la ligne)
    'velo-overtake': () => localRoute('campagne', [{ x: LANE, z: -12 }, { x: LANE, z: -44 },
      ...laneChange(LANE, -0.2, -44, -54), { x: -0.2, z: -66 }, ...laneChange(-0.2, LANE, -66, -78), { x: LANE, z: -175 }], { x: LANE, z: -41.5 }),
    // Reste derrière le tracteur pendant la ligne continue, puis dépasse quand elle devient discontinue.
    'rural-follow': () => localRoute('campagne', [{ x: LANE, z: -12 }, { x: LANE, z: -92 },
      ...laneChange(LANE, -LANE, -92, -104), { x: -LANE, z: -120 }, ...laneChange(-LANE, LANE, -120, -134), { x: LANE, z: -175 }], { x: LANE, z: -41.5 }),
  },
  autoroute: {
    'motorway-right': () => localRoute('autoroute', [{ x: AUTOROUTE.rightLane, z: 80 }, { x: AUTOROUTE.rightLane, z: -150 }], { x: AUTOROUTE.rightLane, z: 17 }),
    merge: () => localRoute('autoroute', [{ x: AUTOROUTE.insertX, z: 52 }, { x: AUTOROUTE.insertX, z: AUTOROUTE.insertEnd },
      ...laneChange(AUTOROUTE.insertX, AUTOROUTE.rightLane, AUTOROUTE.insertEnd, AUTOROUTE.mergeEnd), { x: AUTOROUTE.rightLane, z: -150 }], { x: AUTOROUTE.insertX, z: 6 }),
    'motorway-cruise': () => localRoute('autoroute', [{ x: AUTOROUTE.rightLane, z: 60 }, { x: AUTOROUTE.rightLane, z: -150 }], { x: AUTOROUTE.rightLane, z: 8 }),
  },
};

// Routes ajoutées en v0.4 (scènes plus variées)
Object.assign(LOCAL_ROUTES.rue, {
  // Tout droit dans la rue, arrêt possible avant le passage piéton (z = 13)
  'rue-straight': () => localRoute('rue', [{ x: LANE, z: 70 }, { x: LANE, z: -60 }], { x: LANE, z: RUE.zebraZ + 1.3 + CAR_HALF_LEN + 1.2 }),
  // Voiture garée sur la place libre (côté droit pour qui roule vers le nord), avant vers le nord
  'rue-gare': () => localRoute('rue', [{ x: RUE.bayX, z: 39.5 }, { x: RUE.bayX, z: RUE.freeBayZ }], { x: RUE.bayX, z: RUE.freeBayZ }),
  // Cycliste qui remonte la voie de circulation (vers le nord), derrière la voiture garée
  'rue-velo-voie': () => localRoute('rue', [{ x: 3.1, z: 75 }, { x: 3.1, z: -40 }], { x: 3.1, z: 47 }),
});
Object.assign(LOCAL_ROUTES.campagne, {
  // Véhicule en sens inverse (voie de gauche du joueur)
  'rural-oncoming': () => localRoute('campagne', [{ x: -LANE, z: -90 }, { x: -LANE, z: 70 }], { x: -LANE, z: -22 }),
  // Véhicule qui précède le joueur
  'rural-lead': () => localRoute('campagne', [{ x: LANE, z: 20 }, { x: LANE, z: -170 }], { x: LANE, z: -16 }),
  // Approche d'un passage à niveau (rails à z = -20) : arrêt avant la voie ferrée
  'pn-approach': () => localRoute('campagne', [{ x: LANE, z: 40 }, { x: LANE, z: -90 }], { x: LANE, z: -20 + 4.5 + CAR_HALF_LEN }),
  // Voiture en panne, immobilisée en partie sur la voie de droite
  'rural-breakdown': () => localRoute('campagne', [{ x: LANE, z: 20 }, { x: 3.3, z: 0 }, { x: 3.3, z: -10 }], { x: 3.3, z: -10 }),
  // Voiture garée sur l'accotement droit
  'rural-shoulder': () => localRoute('campagne', [{ x: 5.6, z: 20 }, { x: 5.6, z: -10 }], { x: 5.6, z: -10 }),
});
Object.assign(LOCAL_ROUTES.autoroute, {
  'motorway-left': () => localRoute('autoroute', [{ x: AUTOROUTE.leftLane, z: 60 }, { x: AUTOROUTE.leftLane, z: -150 }], { x: AUTOROUTE.leftLane, z: 8 }),
  'motorway-bau': () => localRoute('autoroute', [{ x: AUTOROUTE.rightLane, z: 60 }, { x: AUTOROUTE.rightLane, z: 30 }, ...laneChange(AUTOROUTE.rightLane, 9.8, 30, 16), { x: 9.8, z: 6 }], { x: 9.8, z: 6 }),
});
// Parking (route est-ouest au nord, à z = -20 ; voie vers l'est z = -18, voie vers l'ouest z = -22)
export const PARKING = { roadZ: -20, aisle: 0, exitX: 0 };
LOCAL_ROUTES.parking = {
  // Le joueur sort du parking en traversant le trottoir puis tourne à droite (vers l'est)
  'parking-exit': () => localRoute('parking', [{ x: -16, z: 0 }, { x: -2, z: 0 }, { x: PARKING.exitX, z: -3, ctrl: { x: PARKING.exitX, z: 0 } }, { x: PARKING.exitX, z: -15 },
    { x: 3, z: -18, ctrl: { x: PARKING.exitX, z: -18 } }, { x: 60, z: -18 }], { x: PARKING.exitX, z: -13.2 }),
  'road-east': () => localRoute('parking', [{ x: -70, z: -18 }, { x: 70, z: -18 }], { x: -14, z: -18 }),
  'road-west': () => localRoute('parking', [{ x: 70, z: -22 }, { x: -70, z: -22 }], { x: 14, z: -22 }),
};
SITES.parking = { ox: 0, oz: 0 };

/** Rotation d'un point local d'un quart de tour k (même convention que Three.js : S → E pour k = 1). */
export function rotateQuarter(p, k = 0) {
  let { x, z } = p;
  for (let i = 0; i < (((k % 4) + 4) % 4); i++) [x, z] = [z, -x];
  return { ...p, x: x + 0, z: z + 0 };
}
/** Quarts de tour qui amènent la branche sud sur la branche demandée. */
export const QUARTER_OF = { S: 0, E: 1, N: 2, W: 3 };

/** Convertit une position locale d'un site en position monde. */
export function toWorld(site, p) {
  const { ox, oz } = SITES[site];
  return { x: p.x + ox, z: p.z + oz };
}

/** Véhicule immobile : route minuscule orientée selon `angle` (rad, même convention que pointAt). */
function staticRoute(site, at) {
  const p = toWorld(site, at);
  const a = at.angle ?? 0;
  return finalize([p, { x: p.x + Math.sin(a) * 0.05, z: p.z + Math.cos(a) * 0.05 }], p);
}

/** Construit la route d'un véhicule décrit dans une scène. */
export function routeFor(vehicle, site) {
  let r;
  if (vehicle.at) return staticRoute(site, vehicle.at);
  if (vehicle.path) r = localRoute(site, vehicle.path, vehicle.hold || vehicle.path[0]);
  else if (site === 'giratoire') r = giratoireRoute(vehicle.action);
  else if (site === 'intersection') r = intersectionRoute(vehicle.from, vehicle.action);
  else {
    const build = LOCAL_ROUTES[site]?.[vehicle.action];
    if (!build) throw new Error(`Route inconnue : ${site}/${vehicle.action}`);
    r = build();
  }
  if (vehicle.rot) r = { ...r, points: r.points.map((p) => rotateQuarter(p, vehicle.rot)) };
  if (vehicle.holdShift) r = { ...r, hold: Math.max(0, Math.min(r.length - 1, r.hold + vehicle.holdShift)) };
  return r;
}
