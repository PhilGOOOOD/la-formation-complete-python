// Mise en scène : construit chaque situation à partir des kits (décor, véhicules, panneaux, accessoires),
// anime les véhicules, les feux et la caméra (motion design).
import * as THREE from 'three';
import { routeFor, pointAt, toWorld } from './routes.js';
import { createCar, createTractor, createCyclist, createVan, createTruck, createBus, createMoto, createEmergency, createPedestrian, createTrain, PAINTS } from './vehicles.js';
import { signAnchor, createYieldMarking, VIEW_DIRS } from './world.js';
import { createSign } from './signs.js';
import { createProp } from './props.js';
import { signByCode } from '../data/signs-catalog.js';
import { buildLayout, compactLayout } from './kit.js';
import { layoutForScene, layout } from '../data/layouts.js';
import { ease } from '../engine/tween.js';

// Cadrages par défaut de chaque site (coordonnées locales au site) ; une scène peut préciser le sien.
const SITE_VIEW = {
  intersection: { x: 1.5, z: 3, zoom: 34 },
  giratoire: { x: 1, z: 6, zoom: 44 },
  rue: { x: 4, z: 10, zoom: 36 },
  campagne: { x: 2, z: 0, zoom: 40 },
  autoroute: { x: 7, z: 8, zoom: 46 },
  parking: { x: 0, z: -6, zoom: 34 },
};
const HOME_VIEW = { target: new THREE.Vector3(0, 0, 0), zoom: 95, dir: VIEW_DIRS.est };
function viewFor(scene) {
  const v = { ...SITE_VIEW[scene.site], ...(scene.camera || {}) };
  const w = toWorld(scene.site, v);
  return { target: new THREE.Vector3(w.x, 0, w.z), zoom: v.zoom, dir: VIEW_DIRS[scene.layoutOpts?.camera] || VIEW_DIRS.est };
}

/** Étiquette A/B/C flottante au-dessus d'un endroit de la scène, reprise des cases de réponse. */
function createLabel(letter, scale = 1) {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#ffffff'; ctx.strokeStyle = '#111111'; ctx.lineWidth = 10;
  ctx.beginPath(); ctx.roundRect(10, 10, 108, 108, 16); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#111111'; ctx.font = 'bold 76px Arial, Helvetica, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(letter, 64, 70);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const g = new THREE.Group(); g.name = `etiquette-${letter}`;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, depthTest: false }));
  sprite.scale.set(2.2, 2.2, 1); sprite.position.y = 3.2; sprite.renderOrder = 10;
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.1, 6), new THREE.MeshBasicMaterial({ color: '#111111', depthTest: false }));
  stem.position.y = 1.05; stem.renderOrder = 9;
  const dot = new THREE.Mesh(new THREE.CircleGeometry(0.45, 24).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: '#111111', depthTest: false }));
  dot.position.y = 0.05; dot.renderOrder = 9;
  g.add(sprite, stem, dot);
  g.scale.setScalar(scale);
  return g;
}
const CRUISE = 9; // vitesse de démonstration (m/s), lisible à l'écran
// Les panneaux tournés vers le sud sont légèrement pivotés vers la caméra pour rester lisibles
const SIGN_TOWARD_CAMERA = 0.4;

/** Libère la mémoire graphique d'un objet retiré de la scène (sauf ressources partagées entre véhicules). */
function disposeTree(root) {
  root.traverse((o) => {
    if (o.isInstancedMesh) o.dispose();
    if (o.geometry && !o.geometry.userData.shared) o.geometry.dispose();
    for (const m of [].concat(o.material || [])) {
      if (m.userData.shared) continue;
      for (const key of ['map', 'alphaMap']) m[key]?.dispose();
      m.dispose();
    }
  });
}

/** Fabrique le véhicule (ou l'usager) décrit dans une scène. */
function createActorModel(v) {
  const paint = PAINTS[v.paint] || v.paint;
  switch (v.kind) {
    case 'tracteur': return createTractor();
    case 'velo': return createCyclist();
    case 'camionnette': return createVan(paint || '#e9ecef', { player: !!v.player });
    case 'camion': return createTruck(paint || undefined);
    case 'bus': return createBus(paint || undefined);
    case 'moto': return createMoto(paint || undefined, { tombe: !!v.tombe });
    case 'pompiers': case 'smur': case 'police': return createEmergency(v.kind);
    case 'pieton': return createPedestrian({ enfant: !!v.enfant, couche: !!v.couche, casque: !!v.casque });
    case 'train': return createTrain();
    // Vue rapprochée d'une voiture immobile : pas d'anneau « vous », il masquerait la voiture
    default: return createCar(paint || (v.player ? PAINTS.joueur : PAINTS.gris), { player: !!v.player && !v.at, capot: !!v.capot, highlight: v.highlight, coffre: !!v.coffre });
  }
}
const TURN_RIGHT = ['right', 'ring-east', 'right-cross', 'park', 'parking-exit'];

export function createDirector(world, timeline, sfx) {
  const actors = new Map();
  const props = [];
  const motionQuery = window.matchMedia?.('(prefers-reduced-motion: reduce)');
  let reducedMotion = motionQuery?.matches ?? false;
  motionQuery?.addEventListener?.('change', (e) => { reducedMotion = e.matches; });
  let playToken = 0; // seule la dernière résolution lancée anime les véhicules
  let currentScene = null;
  let clock = 0;
  let follow = null; // acteur suivi par la caméra pendant la résolution
  let generation = 0; // invalide une résolution en cours quand on change de situation
  let viewMode = 'iso'; // vue choisie pour la situation en cours : 'iso' ou 'conducteur'

  // ——— Décor en kit : reconstruit seulement quand le plan change, avec une animation d'assemblage ———
  let decorKey = null;
  let decorRoot = null;
  let decorDone = Promise.resolve();
  function ensureLayout(plan) {
    if (plan.key === decorKey) return decorDone; // même décor : on attend la fin de son assemblage éventuel
    decorKey = plan.key;
    decorDone = assemble(plan);
    return decorDone;
  }
  async function assemble(plan) {
    for (const child of [...world.decor.children]) { world.decor.remove(child); disposeTree(child); }
    const { root, pieces } = buildLayout(plan);
    decorRoot = root;
    world.decor.add(root);
    world.requestRender();
    if (reducedMotion) { compactLayout(root); return; }
    // Les routes se posent d'abord, du centre vers l'extérieur, puis le décor « pousse »
    const jobs = pieces.map((p) => {
      const o = p.object;
      const delay = (p.road ? 0 : 0.35) + p.distance * 0.07 + (p.trees ? 0.5 : 0);
      o.scale.set(1, p.road ? 1 : 0.001, 1);
      if (p.road) o.position.y = -1.2;
      return timeline.tween({ duration: p.road ? 0.4 : 0.55, delay, easing: ease.outBack, onUpdate: (k) => {
        if (p.road) o.position.y = -1.2 * (1 - k); else o.scale.y = Math.max(0.001, k);
        world.requestRender();
      } });
    });
    await Promise.all(jobs);
    // Fusion seulement si ce décor est toujours celui affiché (un autre a pu le remplacer pendant l'animation)
    if (decorRoot === root) { compactLayout(root); world.requestRender(); }
  }
  /** Décor de fond de l'écran d'accueil. */
  function prepareHome() { return ensureLayout(layout('croix', { theme: 'ville' })); }

  function clear() {
    if (viewMode !== 'iso') { viewMode = 'iso'; world.setMode('iso'); }
    generation++;
    playToken++;
    follow = null;
    currentScene = null;
    for (const child of [...world.dynamic.children]) { world.dynamic.remove(child); disposeTree(child); }
    actors.clear();
    props.length = 0;
    world.requestRender();
  }

  function place(actor, s) {
    actor.s = s;
    const p = pointAt(actor.route, s);
    actor.car.object.position.set(p.x, 0, p.z);
    actor.car.object.rotation.y = p.angle;
    if (actor.spec?.at?.tilt) actor.car.object.rotation.z = actor.spec.at.tilt; // véhicule accidenté
    world.requestRender();
  }

  /** Déplace la caméra vers un cadrage (cible, zoom et côté de vue), avec une courbe douce. */
  function moveCamera(to, duration = 1.6) {
    if (to === 'accueil') to = HOME_VIEW;
    const fromT = world.view.target.clone(), fromZ = world.view.zoom, fromD = world.view.dir.clone();
    const toD = to.dir || fromD;
    if (reducedMotion || duration === 0) {
      world.view.target.copy(to.target); world.view.zoom = to.zoom; world.view.dir.copy(toD); world.applyCamera();
      return Promise.resolve();
    }
    return timeline.tween({ duration, easing: ease.inOutCubic, onUpdate: (k) => {
      world.view.target.lerpVectors(fromT, to.target, k);
      world.view.zoom = fromZ + (to.zoom - fromZ) * k;
      world.view.dir.lerpVectors(fromD, toD, k).normalize();
      world.applyCamera();
    } });
  }

  const night = () => world.weather === 'nuit';
  /** Feux de départ d'un véhicule : explicites, sinon croisement de nuit, aspect de jour sinon. */
  const initialLights = (v) => (v.lights !== undefined ? v.lights : night() ? 'croisement' : undefined);

  /** Construit la situation d'une question et fait entrer les véhicules jusqu'à leur point d'attente. */
  async function setup(scene, { vue = null } = {}) {
    clear();
    currentScene = scene;
    world.setWeather(scene.weather || 'beau');
    const assembly = ensureLayout(layoutForScene(scene));
    follow = null;
    for (const s of scene.signs || []) {
      const sign = createSign(s.type);
      const code = signByCode(s.type)?.code;
      if (s.approach) {
        const a = signAnchor(scene.site, s.approach);
        sign.position.set(a.x, 0.16, a.z); sign.rotation.y = a.rotY + (a.rotY === 0 ? SIGN_TOWARD_CAMERA : 0);
        world.dynamic.add(sign);
        if (code === 'AB4' || code === 'AB3a') world.dynamic.add(createYieldMarking(code === 'AB4' ? 'stop' : 'cedez', scene.site, s.approach));
      } else {
        const p = toWorld(scene.site, s);
        sign.position.set(p.x, 0.16, p.z); sign.rotation.y = (s.rotY || 0) + SIGN_TOWARD_CAMERA;
        world.dynamic.add(sign);
        if (s.marking) world.dynamic.add(createYieldMarking(code === 'AB4' ? 'stop' : 'cedez', scene.site, s.marking));
      }
    }
    for (const spec of scene.props || []) {
      const prop = createProp(spec, { night: night() });
      prop.spec = spec;
      if (spec.type === 'pn' || spec.type === 'triangle' || spec.type === 'borne' || spec.type === 'lampadaire') {
        const p = toWorld(scene.site, { x: prop.object.position.x, z: prop.object.position.z });
        prop.object.position.x = p.x; prop.object.position.z = p.z;
      }
      world.dynamic.add(prop.object);
      if (spec.type === 'feu') world.dynamic.add(createYieldMarking('stop', scene.site, spec.approach)); // ligne d'arrêt des feux
      props.push(prop);
    }
    for (const l of scene.labels || []) {
      const label = createLabel(l.id, l.scale || 1);
      const p = toWorld(scene.site, l);
      label.position.set(p.x, l.y || 0, p.z);
      world.dynamic.add(label);
    }
    for (const v of scene.vehicles) {
      const car = createActorModel(v);
      const route = routeFor(v, scene.site);
      const blinker = v.hazard ? 'both' : v.action === 'left' || v.action === 'merge' ? 'left' : TURN_RIGHT.includes(v.action) ? 'right' : null;
      const actor = { id: v.id, car, route, s: 0, player: !!v.player, blinker, lights: initialLights(v), siren: !!v.siren, spec: v };
      car.setBlinker(blinker);
      car.setLights(actor.lights);
      car.setSiren?.(actor.siren);
      world.dynamic.add(car.object);
      actors.set(v.id, actor);
      place(actor, v.at ? 0 : Math.max(0, route.hold - 26));
    }
    applyView(vue || scene.vue || 'iso'); // vue imposée par le joueur, sinon celle conseillée par la scène
    const cam = moveCamera(viewFor(scene), 1.8);
    // Entrée des véhicules : décélération jusqu'au point d'attente, légèrement décalée
    const arrivals = [...actors.values()].map((a, i) => {
      const from = a.s, to = a.route.hold;
      if (reducedMotion || from === to) { place(a, to); return Promise.resolve(); }
      return timeline.tween({ duration: 2.6, delay: 0.25 + i * 0.25, easing: ease.outCubic, onUpdate: (k) => place(a, from + (to - from) * k) });
    });
    sfx?.engine(true);
    await Promise.all([cam, assembly, ...arrivals]);
    sfx?.engine(false);
  }

  /** Remet feux, barrières et véhicules dans leur état de départ (pour « Revoir la scène »). */
  function resetState() {
    for (const a of actors.values()) { place(a, a.route.hold); a.car.setBlinker(a.blinker); a.car.setLights(a.lights); }
    for (const p of props) {
      if (p.spec.type === 'feu') p.setState(p.spec.state);
      if (p.spec.type === 'pn') { p.setBarrier({ ouvert: 0, fermeture: 0.5, ferme: 1 }[p.spec.state || 'ouvert']); p.setFlashing(p.spec.feux !== false && (p.spec.state !== 'ouvert' || !!p.spec.feux)); }
    }
  }
  function moveBarriers(state) {
    const pn = props.find((p) => p.spec.type === 'pn');
    if (!pn) return Promise.resolve();
    const to = state === 'ferme' ? 1 : 0, from = pn.barrier;
    if (state === 'ferme') pn.setFlashing(true);
    const done = reducedMotion ? (pn.setBarrier(to), Promise.resolve())
      : timeline.tween({ duration: 1.4, easing: ease.inOutCubic, onUpdate: (k) => { pn.setBarrier(from + (to - from) * k); world.requestRender(); } });
    return done.then(() => { if (state !== 'ferme') pn.setFlashing(false); world.requestRender(); });
  }

  /** Joue le bon ordre de passage, étape par étape. */
  async function resolve() {
    if (!currentScene) return;
    const gen = generation;
    const token = ++playToken;
    resetState();
    if (currentScene.follow) {
      // On repart du cadrage de la question pour que « Revoir la scène » rejoue le même mouvement
      const v = viewFor(currentScene);
      world.view.target.copy(v.target); world.view.zoom = v.zoom; world.view.dir.copy(v.dir); world.applyCamera();
      const a = actors.get(currentScene.follow);
      follow = a ? { actor: a, offset: v.target.clone().sub(a.car.object.position) } : null;
    }
    sfx?.engine(true);
    const all = [];
    for (const step of currentScene.resolution || []) {
      if (gen !== generation || token !== playToken) return;
      if (step.wait) { await timeline.wait(reducedMotion ? step.wait / 3 : step.wait); continue; }
      if (step.lights) { for (const [id, mode] of Object.entries(step.lights)) actors.get(id)?.car.setLights(mode); world.requestRender(); continue; }
      if (step.feux) { for (const p of props) if (p.spec.type === 'feu' && step.feux[p.spec.approach]) p.setState(step.feux[p.spec.approach]); world.requestRender(); sfx?.select?.(); continue; }
      if (step.pn) { await moveBarriers(step.pn); continue; }
      if (!step.go) continue;
      // Chaque mouvement : identifiant seul (départ arrêté, 34 m) ou { id, dist, speed, easing }
      const moves = step.go.map((m) => {
        const spec = typeof m === 'string' ? { id: m } : m;
        const a = actors.get(spec.id);
        const from = a.s, to = Math.min(a.route.length, from + (spec.dist ?? 34));
        const duration = Math.max(0.1, (to - from) / (spec.speed ?? CRUISE));
        return timeline.tween({ duration, easing: ease[spec.easing || 'inQuad'], onUpdate: (k) => { if (token === playToken) place(a, from + (to - from) * k); } })
          .then(() => { if (token === playToken && !spec.keepBlinker && a.blinker !== 'both') a.car.setBlinker(null); });
      });
      all.push(...moves);
      // Par défaut, l'étape suivante démarre quand le véhicule prioritaire a dégagé le carrefour ;
      // avec sync, elle attend la fin de tous les mouvements de l'étape.
      if (step.sync) await Promise.all(moves);
      else await Promise.race([Promise.all(moves), timeline.wait(reducedMotion ? 0.4 : 1.6)]);
    }
    await Promise.all(all);
    if (gen === generation && token === playToken) { sfx?.engine(false); follow = null; }
  }

  /** Voiture du joueur qui peut porter la vue conducteur (pas une voiture vue de près, capot ouvert). */
  function playerActor() { return [...actors.values()].find((a) => a.player) || null; }
  function canDrive() { const p = playerActor(); return !!p && !p.spec.at && !p.spec.kind; }
  /** Applique la vue : en vue conducteur, la voiture du joueur est masquée (on est à l'intérieur). */
  function applyView(mode) {
    viewMode = mode === 'conducteur' && canDrive() ? 'conducteur' : 'iso';
    const p = playerActor();
    // On est dans la voiture : sa carrosserie est masquée, mais le faisceau de ses phares reste visible
    if (p) for (const c of p.car.object.children) if (c.name !== 'faisceau') c.visible = viewMode !== 'conducteur';
    syncDriver();
    world.setMode(viewMode);
    world.requestRender();
    return viewMode;
  }
  function syncDriver() {
    const p = playerActor();
    if (!p || viewMode !== 'conducteur') return false;
    const o = p.car.object, d = world.view.driver;
    if (d.x === o.position.x && d.z === o.position.z && d.yaw === o.rotation.y) return false;
    d.x = o.position.x; d.z = o.position.z; d.yaw = o.rotation.y;
    world.applyCamera(); // l'ombre du soleil suit le regard du conducteur
    return true;
  }

  function tick(dt) {
    clock += dt;
    if (syncDriver()) world.requestRender();
    if (follow) {
      // La caméra glisse vers le véhicule suivi en gardant le décalage du cadrage initial
      const goal = follow.actor.car.object.position.clone().add(follow.offset);
      world.view.target.lerp(goal, Math.min(1, dt * 2.5));
      world.applyCamera();
    }
    for (const a of actors.values()) {
      const r = a.car.tick(clock);
      if (r.changed) world.requestRender();
      if (r.lit && a.player) sfx?.blink();
    }
    for (const p of props) if (p.tick?.(clock)) world.requestRender();
  }

  return {
    setup, resolve, tick, moveCamera, clear, prepareHome,
    /** Change de vue pendant une situation ; renvoie la vue effectivement appliquée. */
    setView: (mode) => applyView(mode),
    get view() { return viewMode; },
    get canDrive() { return canDrive(); },
    set reducedMotion(v) { reducedMotion = !!v; },
    get reducedMotion() { return reducedMotion; },
    /** État lisible par les tests automatisés. */
    snapshot() {
      return [...actors.values()].map((a) => ({ id: a.id, s: +a.s.toFixed(2), hold: +a.route.hold.toFixed(2),
        x: +a.car.object.position.x.toFixed(2), z: +a.car.object.position.z.toFixed(2), blinker: a.car.blinker, lights: a.car.lights ?? null }));
    },
    /** États des accessoires (feux, barrières) pour les tests. */
    propsState() {
      return props.map((p) => ({ type: p.spec.type, ...(p.spec.type === 'feu' ? { approach: p.spec.approach, state: p.state } : {}), ...(p.spec.type === 'pn' ? { barrier: +p.barrier.toFixed(2) } : {}) }));
    },
  };
}
