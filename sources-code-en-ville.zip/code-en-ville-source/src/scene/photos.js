// Textures photographiques (ambientCG, licence CC0 — voir src/assets/tex/LICENCE.txt), intégrées à la page.
// Couleur en 512 px, relief (normal map) en 256 px : environ 440 Ko au total.
import enrobeC from '../assets/tex/enrobe-c.jpg';
import enrobeN from '../assets/tex/enrobe-n.jpg';
import herbeC from '../assets/tex/herbe-c.jpg';
import herbeN from '../assets/tex/herbe-n.jpg';
import trottoirC from '../assets/tex/trottoir-c.jpg';
import trottoirN from '../assets/tex/trottoir-n.jpg';
import enduitC from '../assets/tex/enduit-c.jpg';
import enduitN from '../assets/tex/enduit-n.jpg';
import briqueC from '../assets/tex/brique-c.jpg';
import briqueN from '../assets/tex/brique-n.jpg';
import tuileC from '../assets/tex/tuile-c.jpg';
import tuileN from '../assets/tex/tuile-n.jpg';
import ballastC from '../assets/tex/ballast-c.jpg';
import ballastN from '../assets/tex/ballast-n.jpg';

const SOURCES = {
  enrobe: [enrobeC, enrobeN], herbe: [herbeC, herbeN], trottoir: [trottoirC, trottoirN], enduit: [enduitC, enduitN],
  brique: [briqueC, briqueN], tuile: [tuileC, tuileN], ballast: [ballastC, ballastN],
};
/** Images décodées : { enrobe: { color, normal }, … } ; vide tant que loadPhotos() n'est pas terminé. */
export const PHOTOS = {};
let loading = null;
/** Décode toutes les images une seule fois (à appeler avant de construire le premier décor). */
export function loadPhotos() {
  if (loading) return loading;
  const decode = (src) => { const img = new Image(); img.src = src; return img.decode().then(() => img, () => null); };
  loading = Promise.all(Object.entries(SOURCES).map(async ([k, [c, n]]) => {
    const [color, normal] = await Promise.all([decode(c), decode(n)]);
    if (color) PHOTOS[k] = { color, normal };
  }));
  return loading;
}
