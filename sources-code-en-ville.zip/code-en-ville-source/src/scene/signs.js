// Kit de panneaux — dessin vectoriel sur canvas et objets 3D partagés.
// Chaque face est dessinée une seule fois puis réutilisée (texture et géométrie en cache) : un panneau
// supplémentaire dans une scène ne coûte qu'un maillage de plus.
import * as THREE from 'three';
import { signByCode, signShape } from '../data/signs-catalog.js';

const RED = '#c8102e', BLUE = '#1d4f9c', BLACK = '#111111', WHITE = '#ffffff', YELLOW = '#f6c400';
const S = 256;

// ——— Outils de dessin ———
function poly(ctx, pts) { ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.closePath(); }
function triangleUp(ctx, inset) { poly(ctx, [[S / 2, 14 + inset * 1.6], [S - 10 - inset * 1.4, S - 26 - inset * 0.7], [10 + inset * 1.4, S - 26 - inset * 0.7]]); }
function triangleDown(ctx, inset) { poly(ctx, [[10 + inset * 1.4, 30 + inset * 0.7], [S - 10 - inset * 1.4, 30 + inset * 0.7], [S / 2, S - 14 - inset * 1.6]]); }
function circle(ctx, r) { ctx.beginPath(); ctx.arc(S / 2, S / 2, r, 0, Math.PI * 2); }
function stroke(ctx, w, color = BLACK) { ctx.lineWidth = w; ctx.strokeStyle = color; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.stroke(); }
function text(ctx, t, size, y = S / 2 + 4, color = BLACK) {
  ctx.fillStyle = color; ctx.font = `bold ${size}px Arial, Helvetica, sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(t, S / 2, y);
}
function dangerBase(ctx) {
  ctx.lineJoin = 'round';
  triangleUp(ctx, 0); ctx.fillStyle = WHITE; ctx.fill();
  triangleUp(ctx, 12); stroke(ctx, 22, RED);
}
function interdictionBase(ctx, fill = WHITE) {
  circle(ctx, 124); ctx.fillStyle = WHITE; ctx.fill();
  circle(ctx, 104); ctx.fillStyle = fill; ctx.fill();
  circle(ctx, 104); stroke(ctx, 26, RED);
}
function obligationBase(ctx) { circle(ctx, 124); ctx.fillStyle = WHITE; ctx.fill(); circle(ctx, 116); ctx.fillStyle = BLUE; ctx.fill(); }
function squareBase(ctx) {
  ctx.fillStyle = WHITE; ctx.beginPath(); ctx.roundRect(8, 8, S - 16, S - 16, 16); ctx.fill();
  ctx.fillStyle = BLUE; ctx.beginPath(); ctx.roundRect(18, 18, S - 36, S - 36, 10); ctx.fill();
}
function arrow(ctx, pts, head, color = BLACK, w = 22) {
  ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); stroke(ctx, w, color);
  poly(ctx, head); ctx.fillStyle = color; ctx.fill();
}
function bike(ctx, color = WHITE) {
  ctx.strokeStyle = color; ctx.lineWidth = 11; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.arc(82, 150, 32, 0, Math.PI * 2); ctx.stroke();
  ctx.beginPath(); ctx.arc(174, 150, 32, 0, Math.PI * 2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(82, 150); ctx.lineTo(112, 102); ctx.lineTo(156, 102); ctx.lineTo(174, 150);
  ctx.moveTo(112, 102); ctx.lineTo(132, 150); ctx.lineTo(156, 102); ctx.moveTo(104, 88); ctx.lineTo(122, 88);
  ctx.moveTo(150, 86); ctx.lineTo(164, 86); ctx.stroke();
}
function townPlate(ctx, barred) {
  ctx.fillStyle = WHITE; ctx.fillRect(6, 72, 244, 112);
  ctx.strokeStyle = RED; ctx.lineWidth = 9; ctx.strokeRect(12, 78, 232, 100);
  text(ctx, 'LES PRÉS', 44, 131);
  if (barred) { ctx.strokeStyle = RED; ctx.lineWidth = 12; ctx.beginPath(); ctx.moveTo(30, 168); ctx.lineTo(226, 90); ctx.stroke(); }
}

const DRAW = {
  AB1(ctx) { dangerBase(ctx); ctx.beginPath(); ctx.moveTo(96, 112); ctx.lineTo(160, 190); ctx.moveTo(160, 112); ctx.lineTo(96, 190); stroke(ctx, 16); },
  AB2(ctx) { dangerBase(ctx); ctx.fillStyle = BLACK; ctx.fillRect(116, 92, 24, 108); ctx.fillRect(92, 128, 72, 13); },
  AB3a(ctx) { ctx.lineJoin = 'round'; triangleDown(ctx, 0); ctx.fillStyle = WHITE; ctx.fill(); triangleDown(ctx, 14); stroke(ctx, 26, RED); },
  AB4(ctx) {
    const oct = (r) => poly(ctx, Array.from({ length: 8 }, (_, i) => { const a = Math.PI / 8 + (i * Math.PI) / 4; return [S / 2 + r * Math.cos(a), S / 2 + r * Math.sin(a)]; }));
    oct(124); ctx.fillStyle = WHITE; ctx.fill(); oct(112); ctx.fillStyle = RED; ctx.fill(); text(ctx, 'STOP', 74, S / 2 + 4, WHITE);
  },
  AB6(ctx) {
    const d = (r) => poly(ctx, [[S / 2, S / 2 - r], [S / 2 + r, S / 2], [S / 2, S / 2 + r], [S / 2 - r, S / 2]]);
    d(124); ctx.fillStyle = '#3a3a3a'; ctx.fill(); d(118); ctx.fillStyle = WHITE; ctx.fill(); d(78); ctx.fillStyle = YELLOW; ctx.fill();
  },
  AB7(ctx) { DRAW.AB6(ctx); ctx.beginPath(); ctx.moveTo(70, 186); ctx.lineTo(186, 70); stroke(ctx, 14); },
  A1a(ctx) { dangerBase(ctx); ctx.beginPath(); ctx.moveTo(110, 200); ctx.lineTo(110, 156); ctx.quadraticCurveTo(110, 116, 160, 108); stroke(ctx, 18); },
  A2b(ctx) { dangerBase(ctx); ctx.beginPath(); ctx.moveTo(70, 186); ctx.lineTo(96, 186); ctx.quadraticCurveTo(128, 120, 160, 186); ctx.lineTo(186, 186); stroke(ctx, 12); },
  A3(ctx) { dangerBase(ctx); ctx.beginPath(); ctx.moveTo(96, 196); ctx.lineTo(96, 170); ctx.lineTo(112, 140); ctx.lineTo(112, 104); ctx.moveTo(160, 196); ctx.lineTo(160, 170); ctx.lineTo(144, 140); ctx.lineTo(144, 104); stroke(ctx, 12); },
  A14(ctx) { dangerBase(ctx); ctx.fillStyle = BLACK; ctx.beginPath(); ctx.roundRect(119, 96, 18, 66, 6); ctx.fill(); ctx.beginPath(); ctx.arc(128, 182, 11, 0, Math.PI * 2); ctx.fill(); },
  B0(ctx) { interdictionBase(ctx); },
  B1(ctx) { circle(ctx, 124); ctx.fillStyle = WHITE; ctx.fill(); circle(ctx, 116); ctx.fillStyle = RED; ctx.fill(); ctx.fillStyle = WHITE; ctx.fillRect(48, 110, 160, 36); },
  B2a(ctx) { interdictionBase(ctx); arrow(ctx, [[146, 186], [146, 122], [100, 122]], [[104, 98], [72, 122], [104, 146]]); ctx.beginPath(); ctx.moveTo(62, 62); ctx.lineTo(194, 194); stroke(ctx, 18, RED); },
  B2b(ctx) { interdictionBase(ctx); arrow(ctx, [[110, 186], [110, 122], [156, 122]], [[152, 98], [184, 122], [152, 146]]); ctx.beginPath(); ctx.moveTo(62, 62); ctx.lineTo(194, 194); stroke(ctx, 18, RED); },
  B6a1(ctx) { interdictionBase(ctx, BLUE); ctx.beginPath(); ctx.moveTo(64, 64); ctx.lineTo(192, 192); stroke(ctx, 24, RED); },
  B6d(ctx) { interdictionBase(ctx, BLUE); ctx.beginPath(); ctx.moveTo(64, 64); ctx.lineTo(192, 192); ctx.moveTo(192, 64); ctx.lineTo(64, 192); stroke(ctx, 24, RED); },
  B22a(ctx) { obligationBase(ctx); bike(ctx); },
  C1a(ctx) { squareBase(ctx); text(ctx, 'P', 160, S / 2 + 10, WHITE); },
  C12(ctx) { squareBase(ctx); arrow(ctx, [[128, 210], [128, 92]], [[92, 100], [128, 52], [164, 100]], WHITE, 30); },
  EB10(ctx) { townPlate(ctx, false); },
  EB20(ctx) { townPlate(ctx, true); },
  // ——— Ajouts v0.4 : pictogrammes simplifiés, à faire valider ———
  A7(ctx) { dangerBase(ctx); ctx.fillStyle = BLACK; ctx.fillRect(84, 150, 88, 14); for (const x of [84, 112, 140, 168]) ctx.fillRect(x - 5, 130, 10, 64); ctx.fillRect(84, 176, 88, 10); },
  A8(ctx) {
    dangerBase(ctx); ctx.fillStyle = BLACK;
    ctx.fillRect(78, 148, 100, 36); ctx.fillRect(140, 118, 38, 34); ctx.fillRect(88, 124, 16, 26); ctx.fillRect(84, 116, 24, 10);
    for (const x of [96, 128, 162]) { ctx.beginPath(); ctx.arc(x, 192, 11, 0, Math.PI * 2); ctx.fill(); }
  },
  A13a(ctx) { dangerBase(ctx); walker(ctx, 104, 112, 0.8); walker(ctx, 150, 124, 0.66); },
  A13b(ctx) { dangerBase(ctx); ctx.fillStyle = BLACK; for (let x = 82; x < 180; x += 22) ctx.fillRect(x, 194, 12, 8); walker(ctx, 128, 102, 0.9); },
  A17(ctx) {
    dangerBase(ctx); ctx.fillStyle = BLACK; ctx.beginPath(); ctx.roundRect(108, 92, 40, 108, 10); ctx.fill();
    [[RED, 112], [YELLOW, 146], ['#1f9d55', 180]].forEach(([c, y]) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(128, y, 13, 0, Math.PI * 2); ctx.fill(); });
  },
  AB25(ctx) {
    dangerBase(ctx);
    for (let k = 0; k < 3; k++) {
      const a0 = -Math.PI / 2 + k * (2 * Math.PI / 3), a1 = a0 + 1.45;
      ctx.beginPath(); ctx.arc(128, 160, 36, a0, a1); stroke(ctx, 12);
      const hx = 128 + 36 * Math.cos(a1), hy = 160 + 36 * Math.sin(a1), t = a1 + Math.PI / 2;
      poly(ctx, [[hx + 14 * Math.cos(t), hy + 14 * Math.sin(t)], [hx + 11 * Math.cos(t - 2.2), hy + 11 * Math.sin(t - 2.2)], [hx + 11 * Math.cos(t + 2.2), hy + 11 * Math.sin(t + 2.2)]]);
      ctx.fillStyle = BLACK; ctx.fill();
    }
  },
  B3(ctx) { interdictionBase(ctx); carTop(ctx, 96, RED); carTop(ctx, 160, BLACK); },
  B34(ctx) {
    circle(ctx, 124); ctx.fillStyle = WHITE; ctx.fill(); circle(ctx, 118); stroke(ctx, 6, '#8a8f95');
    carTop(ctx, 96, '#9aa0a6'); carTop(ctx, 160, '#9aa0a6');
    ctx.save(); circle(ctx, 116); ctx.clip();
    for (let d = -60; d <= 60; d += 20) { ctx.beginPath(); ctx.moveTo(56 + d, 200 + d); ctx.lineTo(200 + d, 56 + d); stroke(ctx, 6, BLACK); }
    ctx.restore();
  },
  C20a(ctx) {
    squareBase(ctx); poly(ctx, [[128, 44], [214, 200], [42, 200]]); ctx.fillStyle = WHITE; ctx.fill();
    ctx.fillStyle = BLACK; for (let x = 80; x < 180; x += 20) ctx.fillRect(x, 182, 11, 8); walker(ctx, 128, 104, 0.75);
  },
  C207(ctx) {
    squareBase(ctx); ctx.fillStyle = WHITE;
    poly(ctx, [[96, 214], [116, 120], [140, 120], [160, 214]]); ctx.fill();
    ctx.fillRect(44, 100, 168, 18); ctx.fillRect(56, 118, 14, 30); ctx.fillRect(186, 118, 14, 30);
    ctx.fillStyle = BLUE; ctx.fillRect(126, 150, 4, 16); ctx.fillRect(126, 180, 4, 18);
  },
};
/** Silhouette de piéton en marche (centre de la tête en x, y), échelle k. */
function walker(ctx, x, y, k) {
  ctx.fillStyle = BLACK; ctx.beginPath(); ctx.arc(x, y, 11 * k, 0, Math.PI * 2); ctx.fill();
  ctx.save(); ctx.translate(x, y); ctx.scale(k, k);
  ctx.beginPath(); ctx.moveTo(0, 14); ctx.lineTo(-4, 54); ctx.moveTo(-4, 54); ctx.lineTo(-22, 92); ctx.moveTo(-4, 54); ctx.lineTo(16, 90);
  ctx.moveTo(0, 22); ctx.lineTo(-20, 46); ctx.moveTo(0, 22); ctx.lineTo(20, 42);
  ctx.restore(); stroke(ctx, 11 * k);
}
/** Voiture vue de l'arrière (pictogramme B3 / B34). */
function carTop(ctx, x, color) {
  ctx.fillStyle = color; ctx.beginPath(); ctx.roundRect(x - 26, 112, 52, 46, 10); ctx.fill();
  ctx.fillRect(x - 32, 136, 64, 20); ctx.fillRect(x - 28, 156, 12, 14); ctx.fillRect(x + 16, 156, 12, 14);
  ctx.fillStyle = WHITE; ctx.fillRect(x - 18, 120, 36, 12);
}

// ——— Ajouts v0.5 : pictogrammes simplifiés (à faire valider par un moniteur) ———
function scaled(ctx, x, y, k, fn) { ctx.save(); ctx.translate(x, y); ctx.scale(k, k); fn(); ctx.restore(); }
function whiteDisc(ctx) { circle(ctx, 124); ctx.fillStyle = WHITE; ctx.fill(); circle(ctx, 119); stroke(ctx, 5, '#8a8f95'); }
/** Fines bandes diagonales noires des panneaux de fin. */
function finBands(ctx) { ctx.save(); circle(ctx, 116); ctx.clip(); for (let d = -84; d <= 84; d += 14) { ctx.beginPath(); ctx.moveTo(40 + d, 216 + d); ctx.lineTo(216 + d, 40 + d); stroke(ctx, 4); } ctx.restore(); }
const redBar = (ctx) => { ctx.beginPath(); ctx.moveTo(62, 62); ctx.lineTo(194, 194); stroke(ctx, 18, RED); };
function bikeAt(ctx, x, y, k, color) { scaled(ctx, x - 128 * k, y - 128 * k, k, () => bike(ctx, color)); }
function walkerDraw(ctx, x, y, k, color) {
  ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, 11 * k, 0, Math.PI * 2); ctx.fill();
  ctx.save(); ctx.translate(x, y); ctx.scale(k, k);
  ctx.beginPath(); ctx.moveTo(0, 14); ctx.lineTo(-4, 54); ctx.moveTo(-4, 54); ctx.lineTo(-22, 92); ctx.moveTo(-4, 54); ctx.lineTo(16, 90);
  ctx.moveTo(0, 22); ctx.lineTo(-20, 46); ctx.moveTo(0, 22); ctx.lineTo(20, 42);
  ctx.restore(); stroke(ctx, 11 * k, color);
}
function curveSign(ctx, pts, mirror) {
  dangerBase(ctx); ctx.save(); if (mirror) { ctx.translate(S, 0); ctx.scale(-1, 1); }
  ctx.beginPath(); pts(ctx); stroke(ctx, 16); ctx.restore();
}
function whiteArrow(ctx, pts, head) { arrow(ctx, pts, head, WHITE, 26); }
function zonePlate(ctx, inner) {
  ctx.fillStyle = WHITE; ctx.beginPath(); ctx.roundRect(8, 8, S - 16, S - 16, 14); ctx.fill();
  ctx.strokeStyle = '#30353b'; ctx.lineWidth = 4; ctx.beginPath(); ctx.roundRect(14, 14, S - 28, S - 28, 10); ctx.stroke();
  if (inner) { ctx.fillStyle = inner; ctx.beginPath(); ctx.roundRect(24, 24, S - 48, S - 48, 8); ctx.fill(); }
}
function smallText(ctx, t, size, y, color = BLACK) { text(ctx, t, size, y, color); }
function serviceBase(ctx) { squareBase(ctx); ctx.fillStyle = WHITE; ctx.fillRect(56, 56, 144, 144); }
function withPanonceau(ctx, inner) {
  // Panneau en haut (réduit) et panonceau de distance « 150 m » en dessous ; le reste du canevas reste transparent
  scaled(ctx, 40, 0, 0.69, () => inner());
  ctx.fillStyle = WHITE; ctx.fillRect(56, 186, 144, 58); ctx.strokeStyle = BLACK; ctx.lineWidth = 6; ctx.strokeRect(59, 189, 138, 52);
  text(ctx, '150 m', 40, 216);
}
Object.assign(DRAW, {
  A1b(ctx) { curveSign(ctx, (c) => { c.moveTo(110, 200); c.lineTo(110, 156); c.quadraticCurveTo(110, 116, 160, 108); }, true); },
  A1c(ctx) { curveSign(ctx, (c) => { c.moveTo(104, 204); c.quadraticCurveTo(100, 176, 132, 166); c.quadraticCurveTo(164, 156, 136, 132); c.quadraticCurveTo(108, 112, 150, 100); }, false); },
  A1d(ctx) { curveSign(ctx, (c) => { c.moveTo(104, 204); c.quadraticCurveTo(100, 176, 132, 166); c.quadraticCurveTo(164, 156, 136, 132); c.quadraticCurveTo(108, 112, 150, 100); }, true); },
  A2a(ctx) { dangerBase(ctx); ctx.beginPath(); ctx.moveTo(66, 170); ctx.lineTo(86, 170); ctx.quadraticCurveTo(106, 204, 126, 170); ctx.quadraticCurveTo(150, 128, 170, 170); ctx.lineTo(190, 170); stroke(ctx, 12); },
  A3a(ctx) { dangerBase(ctx); ctx.beginPath(); ctx.moveTo(100, 200); ctx.lineTo(100, 104); ctx.moveTo(164, 200); ctx.lineTo(164, 168); ctx.lineTo(136, 138); ctx.lineTo(136, 104); stroke(ctx, 12); },
  A3b(ctx) { dangerBase(ctx); ctx.beginPath(); ctx.moveTo(156, 200); ctx.lineTo(156, 104); ctx.moveTo(92, 200); ctx.lineTo(92, 168); ctx.lineTo(120, 138); ctx.lineTo(120, 104); stroke(ctx, 12); },
  A4(ctx) {
    dangerBase(ctx); ctx.fillStyle = BLACK; ctx.beginPath(); ctx.roundRect(104, 96, 48, 52, 10); ctx.fill(); ctx.fillRect(96, 120, 64, 22);
    ctx.beginPath(); ctx.moveTo(108, 156); ctx.bezierCurveTo(88, 172, 128, 182, 100, 204); ctx.moveTo(148, 156); ctx.bezierCurveTo(128, 172, 168, 182, 140, 204); stroke(ctx, 7);
  },
  A15b(ctx) {
    dangerBase(ctx); ctx.fillStyle = BLACK; ctx.beginPath(); ctx.ellipse(124, 150, 38, 18, -0.25, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.moveTo(96, 160); ctx.lineTo(80, 196); ctx.moveTo(112, 162); ctx.lineTo(104, 198); ctx.moveTo(140, 150); ctx.lineTo(160, 190); ctx.moveTo(150, 146); ctx.lineTo(176, 180);
    ctx.moveTo(156, 138); ctx.lineTo(166, 116); ctx.moveTo(166, 116); ctx.lineTo(160, 96); ctx.moveTo(166, 116); ctx.lineTo(182, 100); stroke(ctx, 8);
    ctx.beginPath(); ctx.ellipse(170, 120, 12, 8, -0.5, 0, Math.PI * 2); ctx.fill();
  },
  A16(ctx) { dangerBase(ctx); poly(ctx, [[72, 196], [184, 196], [72, 132]]); ctx.fillStyle = BLACK; ctx.fill(); ctx.fillStyle = BLACK; ctx.font = 'bold 30px Arial, Helvetica, sans-serif'; ctx.textAlign = 'center'; ctx.fillText('10%', 150, 150); },
  A18(ctx) { dangerBase(ctx); arrow(ctx, [[148, 200], [148, 124]], [[132, 128], [148, 100], [164, 128]], BLACK, 12); arrow(ctx, [[108, 104], [108, 172]], [[92, 168], [108, 198], [124, 168]], BLACK, 12); },
  A19(ctx) {
    dangerBase(ctx); poly(ctx, [[74, 196], [74, 110], [104, 100], [112, 196]]); ctx.fillStyle = BLACK; ctx.fill();
    for (const [x, y, r] of [[130, 120, 9], [150, 150, 11], [128, 176, 8], [168, 186, 10]]) { ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); }
  },
  A21(ctx) { dangerBase(ctx); bikeAt(ctx, 128, 168, 0.5, BLACK); },
  A24(ctx) {
    dangerBase(ctx); ctx.fillStyle = BLACK; ctx.fillRect(84, 104, 8, 96);
    poly(ctx, [[92, 108], [176, 120], [176, 140], [92, 136]]); ctx.fillStyle = RED; ctx.fill();
    ctx.fillStyle = WHITE; ctx.fillRect(120, 112, 14, 26); ctx.fillRect(150, 118, 12, 21);
    ctx.strokeStyle = BLACK; ctx.lineWidth = 3; poly(ctx, [[92, 108], [176, 120], [176, 140], [92, 136]]); ctx.stroke();
  },
  AB3b(ctx) { withPanonceau(ctx, () => DRAW.AB3a(ctx)); },
  AB5(ctx) { withPanonceau(ctx, () => { DRAW.AB3a(ctx); text(ctx, 'STOP', 36, 96, BLACK); }); },
  B2c(ctx) { interdictionBase(ctx); arrow(ctx, [[150, 190], [150, 116], [146, 96], [128, 88], [110, 96], [106, 116], [106, 150]], [[88, 146], [106, 178], [124, 146]]); redBar(ctx); },
  B7b(ctx) {
    interdictionBase(ctx); ctx.fillStyle = BLACK;
    ctx.beginPath(); ctx.roundRect(90, 76, 76, 26, 8); ctx.fill(); ctx.beginPath(); ctx.roundRect(100, 62, 56, 22, 8); ctx.fill();
    ctx.beginPath(); ctx.arc(104, 106, 9, 0, Math.PI * 2); ctx.arc(152, 106, 9, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(100, 176, 16, 0, Math.PI * 2); ctx.moveTo(172, 176); ctx.arc(156, 176, 16, 0, Math.PI * 2); stroke(ctx, 7);
    ctx.beginPath(); ctx.moveTo(100, 176); ctx.lineTo(124, 150); ctx.lineTo(150, 150); ctx.lineTo(156, 176); stroke(ctx, 9);
  },
  B9a(ctx) { interdictionBase(ctx); walkerDraw(ctx, 128, 80, 1.1, BLACK); },
  B9b(ctx) { interdictionBase(ctx); bikeAt(ctx, 128, 140, 0.68, BLACK); },
  B12(ctx) { interdictionBase(ctx); poly(ctx, [[112, 58], [144, 58], [128, 84]]); ctx.fillStyle = BLACK; ctx.fill(); poly(ctx, [[112, 198], [144, 198], [128, 172]]); ctx.fill(); text(ctx, '3,5 m', 50, S / 2 + 4); },
  B13(ctx) { interdictionBase(ctx); text(ctx, '3,5 t', 66, S / 2 + 4); },
  B15(ctx) { interdictionBase(ctx); arrow(ctx, [[150, 196], [150, 104]], [[130, 108], [150, 70], [170, 108]], BLACK, 16); arrow(ctx, [[104, 64], [104, 152]], [[84, 148], [104, 186], [124, 148]], RED, 16); },
  B16(ctx) {
    interdictionBase(ctx); poly(ctx, [[80, 112], [104, 112], [176, 80], [176, 176], [104, 144], [80, 144]]); ctx.fillStyle = BLACK; ctx.fill(); redBar(ctx);
  },
  B31(ctx) { whiteDisc(ctx); finBands(ctx); },
  B33(ctx) { whiteDisc(ctx); text(ctx, '70', 104, S / 2 + 6, '#9aa0a6'); finBands(ctx); },
  'B21-1'(ctx) { obligationBase(ctx); ctx.beginPath(); ctx.moveTo(104, 200); ctx.lineTo(104, 160); ctx.quadraticCurveTo(104, 118, 150, 118); stroke(ctx, 26, WHITE); poly(ctx, [[146, 92], [190, 118], [146, 144]]); ctx.fillStyle = WHITE; ctx.fill(); },
  B21a1(ctx) { obligationBase(ctx); whiteArrow(ctx, [[86, 86], [158, 158]], [[136, 178], [180, 180], [178, 136]]); },
  B21b(ctx) { obligationBase(ctx); whiteArrow(ctx, [[128, 206], [128, 92]], [[96, 100], [128, 54], [160, 100]]); },
  B21c1(ctx) { obligationBase(ctx); whiteArrow(ctx, [[110, 206], [110, 116], [158, 116]], [[154, 88], [196, 116], [154, 144]]); },
  B21e(ctx) {
    obligationBase(ctx); ctx.beginPath(); ctx.moveTo(128, 206); ctx.lineTo(128, 120); ctx.moveTo(80, 120); ctx.lineTo(176, 120); stroke(ctx, 24, WHITE);
    ctx.fillStyle = WHITE; poly(ctx, [[84, 96], [48, 120], [84, 144]]); ctx.fill(); poly(ctx, [[172, 96], [208, 120], [172, 144]]); ctx.fill();
  },
  B22b(ctx) { obligationBase(ctx); walkerDraw(ctx, 128, 74, 1.15, WHITE); },
  B25(ctx) { obligationBase(ctx); text(ctx, '30', 104, S / 2 + 6, WHITE); },
  B26(ctx) {
    obligationBase(ctx); ctx.beginPath(); ctx.arc(128, 128, 62, 0, Math.PI * 2); stroke(ctx, 22, WHITE);
    ctx.fillStyle = BLUE; for (let a = 0; a < Math.PI * 2; a += Math.PI / 6) { ctx.beginPath(); ctx.arc(128 + 62 * Math.cos(a), 128 + 62 * Math.sin(a), 6, 0, Math.PI * 2); ctx.fill(); }
    ctx.beginPath(); ctx.arc(128, 128, 22, 0, Math.PI * 2); stroke(ctx, 10, WHITE);
  },
  B40(ctx) { obligationBase(ctx); bike(ctx); redBar(ctx); },
  B30(ctx) { zonePlate(ctx); smallText(ctx, 'ZONE', 46, 64); scaled(ctx, 64, 92, 0.5, () => { interdictionBase(ctx); text(ctx, '30', 120, S / 2 + 8); }); },
  B51(ctx) {
    zonePlate(ctx); smallText(ctx, 'ZONE', 46, 64, '#9aa0a6');
    scaled(ctx, 64, 92, 0.5, () => { circle(ctx, 120); stroke(ctx, 14, '#9aa0a6'); text(ctx, '30', 120, S / 2 + 8, '#9aa0a6'); });
    ctx.beginPath(); ctx.moveTo(40, 220); ctx.lineTo(216, 40); stroke(ctx, 10);
  },
  B52(ctx) {
    zonePlate(ctx, BLUE); smallText(ctx, 'ZONE DE', 30, 54, WHITE); smallText(ctx, 'RENCONTRE', 28, 84, WHITE);
    scaled(ctx, 84, 108, 0.34, () => { interdictionBase(ctx); text(ctx, '20', 130, S / 2 + 8); });
    walkerDraw(ctx, 72, 140, 0.55, WHITE); scaled(ctx, 160, 168, 0.32, () => bike(ctx));
  },
  B54(ctx) { zonePlate(ctx, BLUE); walkerDraw(ctx, 128, 58, 1.0, WHITE); smallText(ctx, 'AIRE', 26, 188, WHITE); smallText(ctx, 'PIÉTONNE', 26, 214, WHITE); },
  C4a(ctx) { squareBase(ctx); text(ctx, '70', 110, S / 2 + 8, WHITE); },
  C6(ctx) {
    squareBase(ctx); ctx.fillStyle = WHITE; ctx.beginPath(); ctx.roundRect(60, 74, 136, 96, 14); ctx.fill();
    ctx.fillStyle = BLUE; ctx.fillRect(72, 88, 112, 34); ctx.fillStyle = WHITE; ctx.fillRect(126, 88, 4, 34);
    ctx.beginPath(); ctx.arc(88, 176, 13, 0, Math.PI * 2); ctx.arc(168, 176, 13, 0, Math.PI * 2); ctx.fill();
  },
  C13a(ctx) { squareBase(ctx); ctx.fillStyle = WHITE; ctx.fillRect(110, 92, 36, 130); ctx.fillStyle = RED; ctx.fillRect(70, 62, 116, 30); },
  C18(ctx) { squareBase(ctx); arrow(ctx, [[160, 206], [160, 96]], [[136, 102], [160, 60], [184, 102]], WHITE, 18); arrow(ctx, [[96, 52], [96, 156]], [[72, 152], [96, 194], [120, 152]], RED, 18); },
  C107(ctx) {
    squareBase(ctx); ctx.fillStyle = WHITE; ctx.beginPath(); ctx.roundRect(66, 104, 124, 58, 14); ctx.fill(); ctx.beginPath(); ctx.roundRect(84, 74, 88, 40, 10); ctx.fill();
    ctx.fillStyle = BLUE; ctx.fillRect(92, 82, 72, 22); ctx.beginPath(); ctx.arc(88, 132, 9, 0, Math.PI * 2); ctx.arc(168, 132, 9, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = WHITE; ctx.fillRect(74, 160, 22, 26); ctx.fillRect(160, 160, 22, 26);
  },
  C111(ctx) { squareBase(ctx); ctx.fillStyle = WHITE; ctx.beginPath(); ctx.moveTo(56, 210); ctx.lineTo(56, 130); ctx.arc(128, 130, 72, Math.PI, 0); ctx.lineTo(200, 210); ctx.closePath(); ctx.fill(); ctx.fillStyle = BLUE; ctx.beginPath(); ctx.moveTo(84, 210); ctx.lineTo(84, 136); ctx.arc(128, 136, 44, Math.PI, 0); ctx.lineTo(172, 210); ctx.closePath(); ctx.fill(); },
  C113(ctx) { squareBase(ctx); bike(ctx); },
  C115(ctx) {
    ctx.fillStyle = WHITE; ctx.beginPath(); ctx.roundRect(8, 8, S - 16, S - 16, 16); ctx.fill();
    ctx.fillStyle = '#1f7a3a'; ctx.beginPath(); ctx.roundRect(18, 18, S - 36, S - 36, 10); ctx.fill();
    walkerDraw(ctx, 82, 72, 1.0, WHITE); scaled(ctx, 110, 92, 0.55, () => bike(ctx));
  },
  CE1(ctx) { serviceBase(ctx); ctx.fillStyle = RED; ctx.fillRect(110, 72, 36, 112); ctx.fillRect(72, 110, 112, 36); },
  CE15a(ctx) {
    serviceBase(ctx); ctx.fillStyle = BLACK; ctx.fillRect(92, 76, 56, 104); ctx.fillStyle = WHITE; ctx.fillRect(102, 88, 36, 26);
    ctx.fillStyle = BLACK; ctx.fillRect(84, 176, 72, 10); ctx.beginPath(); ctx.moveTo(148, 96); ctx.lineTo(168, 108); ctx.lineTo(168, 160); ctx.lineTo(158, 168); stroke(ctx, 6);
  },
});

function drawSpeed(ctx, v) { interdictionBase(ctx); text(ctx, String(v), v >= 100 ? 88 : 104, S / 2 + 6); }

/** Dessine la face d'un panneau sur un contexte 256×256. */
export function drawSign(ctx, code) {
  const s = signByCode(code);
  if (!s) throw new Error(`Panneau inconnu : ${code}`);
  ctx.clearRect(0, 0, S, S);
  if (s.valeur) drawSpeed(ctx, s.valeur); else DRAW[s.code](ctx);
}

/** Image du panneau (data URL) pour la carte de question. */
export function signImage(code) {
  const c = document.createElement('canvas'); c.width = c.height = S;
  drawSign(c.getContext('2d'), code);
  return c.toDataURL('image/png');
}

// ——— Objets 3D (en cache, partagés entre toutes les scènes) ———
const cache = { tex: new Map(), geo: new Map(), mats: new Map() };
function shared(o) { o.userData.shared = true; return o; }

function faceTexture(code) {
  const key = signByCode(code).code;
  if (!cache.tex.has(key)) {
    const c = document.createElement('canvas'); c.width = c.height = S;
    drawSign(c.getContext('2d'), key);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
    cache.tex.set(key, shared(t));
  }
  return cache.tex.get(key);
}

function shapeGeometry(shapeName) {
  if (!cache.geo.has(shapeName)) {
    const sh = new THREE.Shape();
    const pts = {
      octogone: Array.from({ length: 8 }, (_, i) => { const a = Math.PI / 8 + (i * Math.PI) / 4; return [0.5 + 0.485 * Math.cos(a), 0.5 - 0.485 * Math.sin(a)]; }),
      'triangle-bas': [[10 / S, 1 - 30 / S], [1 - 10 / S, 1 - 30 / S], [0.5, 14 / S]],
      triangle: [[0.5, 1 - 14 / S], [1 - 10 / S, 26 / S], [10 / S, 26 / S]],
      losange: [[0.5, 1 - 4 / S], [1 - 4 / S, 0.5], [0.5, 4 / S], [4 / S, 0.5]],
      carre: [[8 / S, 8 / S], [1 - 8 / S, 8 / S], [1 - 8 / S, 1 - 8 / S], [8 / S, 1 - 8 / S]],
      rectangle: [[0.02, 0.28], [0.98, 0.28], [0.98, 0.72], [0.02, 0.72]],
      libre: [[0, 0], [1, 0], [1, 1], [0, 1]],
    }[shapeName];
    if (pts) { pts.forEach(([x, y], i) => (i ? sh.lineTo(x, y) : sh.moveTo(x, y))); sh.closePath(); }
    else sh.absarc(0.5, 0.5, 0.485, 0, Math.PI * 2, false);
    const g = new THREE.ShapeGeometry(sh, 24); g.translate(-0.5, -0.5, 0);
    cache.geo.set(shapeName, shared(g));
  }
  return cache.geo.get(shapeName);
}

function material(key, make) { if (!cache.mats.has(key)) cache.mats.set(key, shared(make())); return cache.mats.get(key); }
const postGeo = () => { if (!cache.geo.has('poteau')) cache.geo.set('poteau', shared(new THREE.CylinderGeometry(0.06, 0.06, 1, 10).translate(0, 0.5, 0))); return cache.geo.get('poteau'); };

/** Panneau complet sur poteau, prêt à poser (face vers +Z). Agrandi pour rester lisible en vue aérienne. */
export function createSign(code) {
  const meta = signByCode(code);
  const shape = signShape(code);
  const g = new THREE.Group(); g.name = `panneau-${meta.code}`;
  const size = shape === 'rectangle' ? 3.4 : shape === 'libre' ? 2.2 : 1.7;
  const centerY = shape === 'rectangle' ? 3.0 : 3.1;
  const geo = shapeGeometry(shape);
  const cutout = shape === 'libre'; // panneau et panonceau : le fond transparent du dessin découpe la face
  const front = new THREE.Mesh(geo, material(`face-${meta.code}`, () => new THREE.MeshStandardMaterial({ map: faceTexture(meta.code), roughness: 0.45, metalness: 0.05, ...(cutout ? { transparent: true, alphaTest: 0.5, side: THREE.DoubleSide } : {}) })));
  front.scale.setScalar(size); front.position.set(0, centerY, 0.03); front.castShadow = true;
  const rear = new THREE.Mesh(geo, material('revers', () => new THREE.MeshStandardMaterial({ color: '#a5abb1', metalness: 0.6, roughness: 0.5, side: THREE.BackSide })));
  rear.scale.setScalar(size); rear.position.set(0, centerY, 0);
  const post = new THREE.Mesh(postGeo(), material('poteau', () => new THREE.MeshStandardMaterial({ color: '#8d949b', metalness: 0.8, roughness: 0.35 })));
  post.scale.y = centerY - size * 0.25; post.castShadow = true;
  g.add(post, front);
  if (!cutout) g.add(rear);
  return g;
}
