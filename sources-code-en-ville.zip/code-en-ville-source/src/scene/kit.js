// Kit de décor : pièces de 20 m (routes, carrefours, giratoire, autoroute) et pièces de décor
// (immeubles, maisons, parc, champ, forêt). Toutes les formes et tous les matériaux sont créés une seule
// fois et partagés ; une scène ne crée que des maillages légers qui les référencent.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { TILE, isRoad } from '../data/layouts.js';
import { ROAD_HALF, RUE, AUTOROUTE, GIRATOIRE } from './routes.js';
import * as tex from './textures.js';
import { createCar, PAINTS } from './vehicles.js';

const H = TILE / 2;
const shared = (o) => { o.userData.shared = true; return o; };

// ——— Bibliothèque partagée (formes et matériaux) ———
const lib = { geo: new Map(), mat: new Map() };
function geo(key, make) { if (!lib.geo.has(key)) lib.geo.set(key, shared(make())); return lib.geo.get(key); }
function mat(key, make) { if (!lib.mat.has(key)) lib.mat.set(key, shared(make())); return lib.mat.get(key); }

/** Plan horizontal w × l dont les coordonnées de texture suivent la taille (texture partagée répétée). */
function flat(w, l, texScale = 12) {
  return geo(`plan:${w}x${l}:${texScale}`, () => {
    const g = new THREE.PlaneGeometry(w, l).rotateX(-Math.PI / 2);
    const uv = g.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * w / texScale, uv.getY(i) * l / texScale);
    return g;
  });
}
const repeatTex = (t) => { t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; };
const normalOf = (name, repeat, scale = 0.8) => { const n = tex.photoNormal(name, repeat); return n ? { normalMap: n, normalScale: new THREE.Vector2(scale, scale) } : {}; };
const light = (c, k) => new THREE.Color(c).lerp(new THREE.Color('#ffffff'), k);
const M = {
  asphalt: () => mat('enrobe', () => new THREE.MeshStandardMaterial({ map: repeatTex(tex.asphalt()), roughness: 0.92, ...normalOf('enrobe', 3, 0.7) })),
  pavement: () => mat('trottoir', () => new THREE.MeshStandardMaterial({ map: repeatTex(tex.pavement()), roughness: 0.85, ...normalOf('trottoir', 6, 0.9) })),
  grass: () => mat('herbe', () => new THREE.MeshStandardMaterial({ map: repeatTex(tex.grass()), roughness: 1, ...normalOf('herbe', 3, 0.6) })),
  paint: () => mat('peinture', () => new THREE.MeshStandardMaterial({ color: '#f2f2ee', roughness: 0.6 })),
  piste: () => mat('piste', () => new THREE.MeshStandardMaterial({ color: '#8f4b3f', roughness: 0.85 })),
  hedge: () => mat('haie', () => new THREE.MeshStandardMaterial({ color: '#3d6a2c', roughness: 0.95 })),
  rail: () => mat('glissiere', () => new THREE.MeshStandardMaterial({ color: '#b9bec4', metalness: 0.85, roughness: 0.35 })),
  curb: () => mat('bordure', () => new THREE.MeshStandardMaterial({ color: '#cfcac0', roughness: 0.8 })),
  roof: (c) => mat(`toit:${c}`, () => { const map = tex.photoColor('tuile', 5); return new THREE.MeshStandardMaterial({ color: map ? light(c, 0.55) : c, map, roughness: 0.75, ...normalOf('tuile', 5) }); }),
  wall: (c) => mat(`mur:${c}`, () => { const map = tex.photoColor('enduit', 3); return new THREE.MeshStandardMaterial({ color: c, map, roughness: 0.9 }); }),
  facade: (c, floors, cols, brique) => mat(`facade:${c}:${floors}:${cols}:${brique}`, () => new THREE.MeshStandardMaterial({ map: tex.facade(c, floors, cols, brique), roughness: 0.85 })),
  field: (kind) => mat(`champ:${kind}`, () => new THREE.MeshStandardMaterial({ map: repeatTex(fieldTexture(kind)), roughness: 1 })),
};
/** Tous les matériaux d'enrobé (pour l'effet de pluie). */
export function asphaltMaterials() { return [M.asphalt()]; }

function fieldTexture(kind) {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const ctx = c.getContext('2d');
  const [a, b] = { ble: ['#d8b85a', '#c9a64a'], labour: ['#7a5a3c', '#5f452e'], pre: ['#6f9a45', '#5c8538'], colza: ['#d9cf3a', '#b8b02c'] }[kind];
  ctx.fillStyle = a; ctx.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 8) { ctx.fillStyle = b; ctx.fillRect(0, y, 256, kind === 'pre' ? 2 : 4); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

// ——— Primitives de pose ———
function plane(g, material, cx, cz, w, l, y = 0.012, texScale = 12) {
  const m = new THREE.Mesh(flat(w, l, texScale), material);
  m.position.set(cx, y, cz); m.receiveShadow = true; g.add(m); return m;
}
const line = (g, cx, cz, w, l, y = 0.026) => plane(g, M.paint(), cx, cz, w, l, y);
function dashesZ(g, x, z0, z1, dash = 3, gap = 2, width = 0.15) {
  for (let z = z0; z + dash <= z1 + 1e-6; z += dash + gap) line(g, x, z + dash / 2, width, dash);
}
/** Pavé w × h × d dont les coordonnées de texture suivent la taille (pour les matériaux photographiques). */
function slabGeo(w, h, d, texScale = 12) {
  return geo(`pave:${w.toFixed(2)}x${h.toFixed(2)}x${d.toFixed(2)}`, () => {
    const g = new THREE.BoxGeometry(w, h, d);
    const uv = g.attributes.uv;
    const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]]; // faces +x, -x, +y, -y, +z, -z
    for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) { const i = f * 4 + k; uv.setXY(i, uv.getX(i) * dims[f][0] / texScale, uv.getY(i) * dims[f][1] / texScale); }
    return g;
  });
}
function slab(g, material, cx, cy, cz, w, h, d, cast = true) {
  const m = new THREE.Mesh(slabGeo(w, h, d), material); m.position.set(cx, cy, cz); m.castShadow = cast; m.receiveShadow = true; g.add(m); return m;
}
function box(g, material, cx, cy, cz, w, h, d, cast = true) {
  const m = new THREE.Mesh(geo('cube', () => new THREE.BoxGeometry(1, 1, 1)), material);
  m.scale.set(w, h, d); m.position.set(cx, cy, cz); m.castShadow = cast; m.receiveShadow = true; g.add(m); return m;
}
/** Angle de trottoir en L, de même largeur (3 m) que les trottoirs des routes qui y arrivent. */
function corner(g, sx, sz) {
  sidewalk(g, sx * ROAD_HALF, sz * ROAD_HALF, sx * (ROAD_HALF + 3), sz * H);
  sidewalk(g, sx * (ROAD_HALF + 3), sz * ROAD_HALF, sx * H, sz * (ROAD_HALF + 3));
}
const sidewalk = (g, x0, z0, x1, z1) => slab(g, M.pavement(), (x0 + x1) / 2, 0.08, (z0 + z1) / 2, Math.abs(x1 - x0), 0.16, Math.abs(z1 - z0), false);

// ——— Pièces de route (construites pour une route nord-sud, puis tournées) ———
const PIECES = {
  route(g, o) {
    plane(g, M.asphalt(), 0, 0, ROAD_HALF * 2, TILE);
    if (o.centre === 'discontinue') dashesZ(g, 0, -H, H, 3, 2);
    if (o.centre === 'continue') line(g, 0, 0, 0.15, TILE);
    if (o.rive) { dashesZ(g, ROAD_HALF - 0.3, -H, H, 3, 3, 0.2); dashesZ(g, -ROAD_HALF + 0.3, -H, H, 3, 3, 0.2); }
    if (o.trottoir) sidewalk(g, -ROAD_HALF, -H, -ROAD_HALF - 3, H);
    if (o.piste === 'est') {
      plane(g, M.piste(), RUE.pisteX, 0, RUE.pisteMax - RUE.pisteMin, TILE, 0.02);
      bikePicto(g, RUE.pisteX, 0);
      sidewalk(g, RUE.sidewalk, -H, H, H);
      if (o.places === 'est') {
        plane(g, M.asphalt(), (RUE.bayMin + RUE.bayMax) / 2 - 0.1, 0, RUE.bayMax - RUE.bayMin + 0.2, TILE, 0.011);
        line(g, RUE.pisteMin - 0.1, 0, 0.12, TILE);
        for (let z = -H; z <= H + 1e-6; z += 5) line(g, (RUE.bayMin + RUE.bayMax) / 2, z, RUE.bayMax - RUE.bayMin, 0.12);
        // Voitures garées : la place « libre » reste vide
        [-7.5, -2.5, 2.5, 7.5].forEach((z, k) => {
          if (k === o.libre) return;
          const car = createCar([PAINTS.gris, PAINTS.vert, PAINTS.blanc, PAINTS.rouge][k], { decor: true }).object;
          car.position.set(RUE.bayX, 0, z); car.rotation.y = Math.PI; g.add(car);
        });
      } else sidewalk(g, RUE.bayMin - 0.2, -H, RUE.pisteMin - 0.2, H);
    } else if (o.trottoir) sidewalk(g, ROAD_HALF, -H, ROAD_HALF + 3, H);
    if (o.zebra !== undefined) for (let x = -ROAD_HALF + 0.5; x < ROAD_HALF; x += 1) line(g, x, o.zebra, 0.5, 2.6);
  },
  croix(g, o) {
    plane(g, M.asphalt(), 0, 0, ROAD_HALF * 2, TILE);
    plane(g, M.asphalt(), (ROAD_HALF + H) / 2, 0, H - ROAD_HALF, ROAD_HALF * 2);
    plane(g, M.asphalt(), -(ROAD_HALF + H) / 2, 0, H - ROAD_HALF, ROAD_HALF * 2);
    if (o.trottoir) for (const sx of [-1, 1]) for (const sz of [-1, 1]) corner(g, sx, sz);
  },
  te(g, o) {
    plane(g, M.asphalt(), 0, 0, ROAD_HALF * 2, TILE);
    plane(g, M.asphalt(), (ROAD_HALF + H) / 2, 0, H - ROAD_HALF, ROAD_HALF * 2);
    if (o.trottoir) sidewalk(g, -ROAD_HALF, -H, -ROAD_HALF - 3, H);
    if (o.piste === 'est') {
      // La piste longe la rue principale et traverse l'entrée de la rue transversale (pointillés)
      for (const s of [-1, 1]) {
        plane(g, M.piste(), RUE.pisteX, s * (ROAD_HALF + H) / 2, RUE.pisteMax - RUE.pisteMin, H - ROAD_HALF, 0.02);
        sidewalk(g, RUE.sidewalk, s * ROAD_HALF, H, s * H);
        sidewalk(g, ROAD_HALF, s * ROAD_HALF, RUE.pisteMin - 0.2, s * H);
      }
      plane(g, M.piste(), RUE.pisteX, 0, RUE.pisteMax - RUE.pisteMin, ROAD_HALF * 2, 0.022);
      for (let z = -ROAD_HALF + 0.3; z < ROAD_HALF; z += 1) { line(g, RUE.pisteMin, z, 0.12, 0.5, 0.03); line(g, RUE.pisteMax, z, 0.12, 0.5, 0.03); }
    } else if (o.trottoir) for (const s of [-1, 1]) corner(g, 1, s);
  },
  giratoire(g, o) {
    const { island, outer } = GIRATOIRE;
    const ring = new THREE.Mesh(geo('anneau', () => new THREE.RingGeometry(island, outer, 96).rotateX(-Math.PI / 2)), M.asphalt());
    ring.position.y = 0.012; ring.receiveShadow = true; g.add(ring);
    const span = 3 * H; // l'emprise couvre 3 × 3 tuiles
    for (const [cx, cz, w, l] of [[0, (outer - 1 + span) / 2, 8, span - outer + 1], [0, -(outer - 1 + span) / 2, 8, span - outer + 1],
      [(outer - 1 + span) / 2, 0, span - outer + 1, 8], [-(outer - 1 + span) / 2, 0, span - outer + 1, 8]]) plane(g, M.asphalt(), cx, cz, w, l);
    const curb = new THREE.Mesh(geo('ilot-bordure', () => new THREE.CylinderGeometry(island, island, 0.3, 64)), M.curb());
    curb.position.y = 0.15; curb.castShadow = true; curb.receiveShadow = true; g.add(curb);
    const lawn = new THREE.Mesh(geo('ilot-pelouse', () => new THREE.CylinderGeometry(island - 0.35, island - 0.35, 0.34, 64)), M.grass());
    lawn.position.y = 0.17; lawn.receiveShadow = true; g.add(lawn);
    const edge = new THREE.Mesh(geo('anneau-ligne', () => new THREE.RingGeometry(outer - 0.35, outer - 0.2, 96).rotateX(-Math.PI / 2)), M.paint());
    edge.position.y = 0.024; g.add(edge);
    g.userData.trees = [[0, 0, 1.5], [3, 2.4, 0.9], [-2.8, -2, 1]];
    if (o.trottoir) for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      sidewalk(g, sx * ROAD_HALF, sz * (outer + 2), sx * (ROAD_HALF + 3), sz * span);
      sidewalk(g, sx * (outer + 2), sz * ROAD_HALF, sx * span, sz * (ROAD_HALF + 3));
    }
  },
  autoroute(g, o) {
    const A = AUTOROUTE;
    for (const s of [1, -1]) plane(g, M.asphalt(), s * (A.median + A.bau) / 2, 0, A.bau - A.median, TILE);
    plane(g, M.grass(), 0, 0, A.median * 2, TILE, 0.03);
    for (const s of [1, -1]) { line(g, s * (A.median + 0.25), 0, 0.2, TILE); dashesZ(g, s * 5, -H, H, 6, 4, 0.18); }
    line(g, -A.edge, 0, 0.25, TILE);
    if (o.insertion === 'voie' || o.insertion === 'bretelle') {
      plane(g, M.asphalt(), A.insertX, 0, 3.5, TILE);
      dashesZ(g, A.edge, -H, H, 3, 1.5, 0.4);
      line(g, A.insertX + 1.75, 0, 0.2, TILE);
    } else if (o.insertion === 'biseau') {
      // Large au sud (côté voie d'insertion), en pointe au nord ; ShapeGeometry tournée : y → -z
      const shape = new THREE.Shape([new THREE.Vector2(A.edge, -H), new THREE.Vector2(A.edge + 3.5, -H), new THREE.Vector2(A.edge, H)]);
      const t = new THREE.Mesh(geo('biseau', () => new THREE.ShapeGeometry(shape).rotateX(-Math.PI / 2)), M.asphalt());
      t.position.y = 0.012; t.receiveShadow = true; g.add(t);
      line(g, A.edge, 0, 0.25, TILE);
    } else line(g, A.edge, 0, 0.25, TILE);
    if (o.insertion === 'bretelle') {
      const ramp = new THREE.Mesh(flat(7, 26), M.asphalt());
      ramp.rotation.y = 0.42; ramp.position.set(A.insertX + 5.5, 0.011, 9); ramp.receiveShadow = true; g.add(ramp);
    }
    const rails = o.insertion === 'bretelle' ? [-1.1, 1.1, -A.bau - 0.3] : [-1.1, 1.1, -A.bau - 0.3, A.insertX + 2.3];
    for (const x of rails) {
      box(g, M.rail(), x, 0.6, 0, 0.08, 0.32, TILE);
      for (let z = -H + 2; z < H; z += 4) box(g, M.rail(), x, 0.3, z, 0.1, 0.6, 0.1, false);
    }
  },

  parking(g, o) {
    plane(g, M.asphalt(), 0, 0, TILE, TILE);
    // Places en épi droit de part et d'autre d'une allée est-ouest (z de -2,5 à 2,5)
    for (let x = -H; x <= H + 1e-6; x += 2.5) {
      if (o.sortie && Math.abs(x) < 2.6) continue; // passage vers la rue
      line(g, x, -5.75, 0.12, 5.5); line(g, x, 5.75, 0.12, 5.5);
    }
    line(g, 0, -2.6, TILE, 0.12); line(g, 0, 2.6, TILE, 0.12);
    if (o.sortie) plane(g, M.asphalt(), 0, -11.6, 5, 3.4, 0.013); // bateau : traversée du trottoir jusqu'à la rue
    [[-8.75, -5.75, 0], [-3.75, 5.75, 1], [6.25, -5.75, 2], [8.75, 5.75, 3], [-6.25, 5.75, 4]].forEach(([x, z, k]) => {
      if ((k + (o.sortie ? 0 : 2)) % 3 === 2) return;
      const car = createCar([PAINTS.gris, PAINTS.blanc, PAINTS.rouge, PAINTS.noir, PAINTS.vert][k], { decor: true }).object;
      car.position.set(x, 0, z); car.rotation.y = z < 0 ? 0 : Math.PI; g.add(car);
    });
    g.userData.trees = o.sortie ? [[9, -9, 0.8]] : [[-9, 9, 0.8], [9, -9, 0.7]];
  },

  // ——— Pièces de décor ———
  immeubles(g, o) { building(g, -3, -2, 11, 9, 3 + (o.variante % 3), o.variante); building(g, 4.5, 4, 8, 8, 2 + (o.variante % 2), o.variante + 1); },
  maisons(g, o) {
    building(g, -2.5, -1.5, 8, 7, 1 + (o.variante % 2), o.variante);
    if (o.variante % 2 === 0) building(g, 4, 4.5, 7, 6, 1, o.variante + 2);
    g.userData.trees = [[5, -4, 0.9], [-5, 5, 0.8]];
  },
  parc(g, o) { g.userData.trees = [[-4, -3, 1], [3, -4, 0.9], [-2, 4, 1.1], [5, 3, 0.9], [0, 0, 1.2]].filter((_, k) => (k + o.variante) % 5 !== 0); },
  bosquet(g, o) { g.userData.trees = [[-3, -2, 1.2], [2, 3, 1.1], [4, -4, 1]].slice(0, 2 + (o.variante % 2)); },
  champ(g, o) {
    plane(g, M.field(['ble', 'colza', 'pre', 'labour'][o.variante % 4]), 0, 0, TILE - 3, TILE - 3, 0.006);
    box(g, M.hedge(), -H + 0.6, 0.4, 0, 0.8, 0.8, TILE - 2);
  },
  foret(g) {
    const t = [];
    for (let x = -8; x <= 8; x += 3.4) for (let z = -8; z <= 8; z += 3.2) t.push([x + Math.sin(x * 7 + z) * 0.9, z + Math.cos(z * 5 + x) * 0.9, 1.05 + ((x * 13 + z * 7) % 5 + 5) % 5 * 0.12]);
    g.userData.trees = t;
  },
};

const WALLS = ['#d8c7a7', '#c9b28d', '#e2d6c1', '#b7695a', '#a9b4b8', '#d9b48f', '#cbbca4'];
const ROOFS = ['#5a4a42', '#3f454b', '#7a5040', '#4b4f52'];
function building(g, x, z, w, d, floors, seed) {
  const wall = WALLS[seed % WALLS.length];
  const h = floors * 3.1;
  const brique = seed % 3 === 1; // une maison sur trois en brique apparente
  const front = M.facade(wall, floors, 3, brique), side = M.facade(wall, floors, 2, brique);
  // Quatre faces verticales en plans séparés (fusionnables par matériau), le toit couvre le dessus
  const faces = [[front, 0, d / 2, 0, w], [front, 0, -d / 2, Math.PI, w], [side, w / 2, 0, Math.PI / 2, d], [side, -w / 2, 0, -Math.PI / 2, d]];
  for (const [mat, dx, dz, ry, width] of faces) {
    const m = new THREE.Mesh(geo(`facade:${width}x${h}`, () => new THREE.PlaneGeometry(width, h)), mat);
    m.position.set(x + dx, h / 2, z + dz); m.rotation.y = ry; m.castShadow = true; m.receiveShadow = true; g.add(m);
  }
  slab(g, M.roof(ROOFS[seed % ROOFS.length]), x, h + 0.25, z, w + 0.4, 0.5, d + 0.4);
}

function bikePicto(g, x, z) {
  const ring = geo('picto-roue', () => new THREE.RingGeometry(0.22, 0.3, 20).rotateX(-Math.PI / 2));
  for (const dz of [-0.45, 0.45]) { const r = new THREE.Mesh(ring, M.paint()); r.position.set(x, 0.027, z + dz); g.add(r); }
  line(g, x, z, 0.08, 0.9, 0.027);
}

// ——— Arbres : un seul maillage instancié par scène, formes partagées ———
const LEAF_COLORS = ['#3f6f2f', '#4f7f34', '#2f5d2a', '#5d8a3a'].map((c) => new THREE.Color(c));
function treesMesh(list) {
  const trunkGeo = geo('tronc', () => new THREE.CylinderGeometry(0.16, 0.24, 2.4, 8).translate(0, 1.2, 0));
  const leafGeo = geo('feuillage', () => new THREE.IcosahedronGeometry(1, 1));
  const trunkMat = mat('tronc', () => new THREE.MeshStandardMaterial({ color: '#5b4331', roughness: 0.95 }));
  const leafMat = mat('feuillage', () => new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.85 }));
  const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, list.length);
  const leaves = new THREE.InstancedMesh(leafGeo, leafMat, list.length * 3);
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), v = new THREE.Vector3(), sc = new THREE.Vector3();
  list.forEach(([x, z, s], i) => {
    trunks.setMatrixAt(i, m.compose(v.set(x, 0, z), q, sc.setScalar(s)));
    for (let k = 0; k < 3; k++) {
      const a = (i * 2.3 + k * 2.1), r = (1.25 + ((i * 7 + k * 3) % 5) * 0.1) * s;
      v.set(x + Math.cos(a) * 0.6 * s, (2.9 + k * 0.45) * s, z + Math.sin(a) * 0.6 * s);
      leaves.setMatrixAt(i * 3 + k, m.compose(v, q, sc.setScalar(r)));
      leaves.setColorAt(i * 3 + k, LEAF_COLORS[(k + i) & 3]);
    }
  });
  const group = new THREE.Group(); group.name = 'arbres';
  for (const mesh of [trunks, leaves]) { mesh.castShadow = true; mesh.receiveShadow = true; mesh.computeBoundingSphere(); group.add(mesh); }
  return group;
}

/**
 * Construit un plan d'assemblage. Renvoie le groupe de la scène et la liste des pièces
 * (avec leur distance au centre) pour l'animation d'assemblage.
 */
export function buildLayout(plan) {
  const root = new THREE.Group(); root.name = `decor-${plan.key}`;
  const pieces = [];
  const trees = [];
  for (const p of plan.pieces) {
    const build = PIECES[p.type];
    if (!build) throw new Error(`Pièce inconnue : ${p.type}`);
    const g = new THREE.Group(); g.name = `piece-${p.type}`;
    build(g, p.opts || {});
    g.position.set(p.i * TILE, 0, p.j * TILE);
    g.rotation.y = -(p.rot || 0) * Math.PI / 2;
    g.updateMatrixWorld(true);
    for (const [x, z, s] of g.userData.trees || []) {
      const w = new THREE.Vector3(x, 0, z).applyMatrix4(g.matrixWorld);
      trees.push([w.x, w.z, s]);
    }
    root.add(g);
    pieces.push({ object: g, distance: Math.hypot(p.i, p.j), road: isRoad(p) });
  }
  if (trees.length) { const t = treesMesh(trees); root.add(t); pieces.push({ object: t, distance: 0, road: false, trees: true }); }
  return { root, pieces };
}

/**
 * Regroupe, une fois la scène assemblée, tous les morceaux qui partagent un même matériau en un seul
 * maillage : des centaines de tirets, bordures et trottoirs deviennent une poignée d'appels de dessin.
 * Les voitures garées, les arbres instanciés et les bâtiments (plusieurs matériaux) restent à part.
 */
export function compactLayout(root) {
  root.updateMatrixWorld(true);
  const groups = new Map();
  const victims = [];
  root.traverse((o) => {
    if (!o.isMesh || o.isInstancedMesh || Array.isArray(o.material)) return;
    // Les voitures garées du décor (immobiles, matériaux partagés) sont fusionnées avec le reste ; les autres objets composés restent à part
    const parkedCar = o.parent?.name === 'voiture-garee';
    if (o.parent && o.parent.name !== '' && !o.parent.name.startsWith('piece-') && !parkedCar) return;
    const key = `${o.material.uuid}|${o.castShadow}`;
    if (!groups.has(key)) groups.set(key, { material: o.material, cast: o.castShadow, geos: [] });
    const g = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
    for (const name of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(name)) g.deleteAttribute(name);
    if (!g.attributes.uv) { g.dispose(); return; }
    g.applyMatrix4(o.matrixWorld);
    groups.get(key).geos.push(g);
    victims.push(o);
  });
  for (const o of victims) { o.parent.remove(o); if (!o.geometry.userData.shared) o.geometry.dispose(); }
  const merged = new THREE.Group(); merged.name = 'decor-fusionne';
  for (const { material, cast, geos } of groups.values()) {
    if (!geos.length) continue;
    const geometry = mergeGeometries(geos, false);
    for (const g of geos) g.dispose();
    if (!geometry) continue;
    const mesh = new THREE.Mesh(geometry, material);
    mesh.castShadow = cast; mesh.receiveShadow = true;
    merged.add(mesh);
  }
  // Les pièces vidées sont retirées de la scène
  for (const child of [...root.children]) if (child.name.startsWith('piece-') && child.children.length === 0) root.remove(child);
  root.add(merged);
  return merged;
}
