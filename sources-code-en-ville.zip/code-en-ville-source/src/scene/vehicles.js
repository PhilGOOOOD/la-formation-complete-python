// Kit de véhicules modélisés en code : voiture (capot ouvrant, éléments du moteur, éclairages), camionnette,
// camion, bus, moto, véhicules prioritaires, tracteur, cycliste, piéton et train.
// Formes et matériaux communs sont partagés ; seuls les matériaux qui changent d'état (feux, clignotants,
// gyrophares, pièce mise en évidence) sont propres à chaque véhicule.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

export const PAINTS = {
  joueur: '#1f5fbf', rouge: '#b3172a', blanc: '#e9ecef', jaune: '#e8b417', gris: '#6b7177', vert: '#2f6b4f',
  noir: '#1c1f24', orange: '#d9661f', bordeaux: '#6d1a2a', bleuClair: '#5aa0d8',
};

const shared = {};
function sharedMaterials() {
  if (shared.glass) return shared;
  shared.glass = new THREE.MeshPhysicalMaterial({ color: '#1b2430', metalness: 0.2, roughness: 0.05, clearcoat: 1, clearcoatRoughness: 0.05, envMapIntensity: 1.4 });
  shared.tyre = new THREE.MeshStandardMaterial({ color: '#16171a', roughness: 0.9 });
  shared.rim = new THREE.MeshStandardMaterial({ color: '#c9ccd1', metalness: 1, roughness: 0.28 });
  shared.trim = new THREE.MeshStandardMaterial({ color: '#202327', roughness: 0.55, metalness: 0.3 });
  shared.metal = new THREE.MeshStandardMaterial({ color: '#7d838a', roughness: 0.45, metalness: 0.8 });
  shared.dark = new THREE.MeshStandardMaterial({ color: '#2a2d31', roughness: 0.7 });
  shared.skin = new THREE.MeshStandardMaterial({ color: '#d9a982', roughness: 0.7 });
  shared.wheelGeo = new THREE.CylinderGeometry(0.36, 0.36, 0.26, 24).rotateZ(Math.PI / 2);
  shared.rimGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.27, 16).rotateZ(Math.PI / 2);
  shared.lightGeo = new THREE.BoxGeometry(0.42, 0.14, 0.06);
  shared.blinkGeo = new THREE.BoxGeometry(0.16, 0.12, 0.07);
  shared.cube = new THREE.BoxGeometry(1, 1, 1);
  shared.headOff = new THREE.MeshStandardMaterial({ color: '#d9d6cc', roughness: 0.2 });
  shared.tailOff = new THREE.MeshStandardMaterial({ color: '#6a1016', roughness: 0.3 });
  shared.beamGeo = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2).translate(0, 0, 0.5);
  shared.beamMat = new THREE.MeshBasicMaterial({ map: beamTexture(), transparent: true, opacity: 0.55, depthWrite: false, blending: THREE.AdditiveBlending, color: '#fff2c8' });
  for (const r of Object.values(shared)) r.userData.shared = true; // jamais libérées entre deux questions
  return shared;
}
/** Halo des phares au sol : dégradé en éventail. */
function beamTexture() {
  const c = document.createElement('canvas'); c.width = 64; c.height = 128;
  const ctx = c.getContext('2d');
  const g = ctx.createLinearGradient(0, 128, 0, 0);
  g.addColorStop(0, 'rgba(255,255,255,0.95)'); g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(26, 128); ctx.lineTo(38, 128); ctx.lineTo(64, 0); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
const decorPaints = new Map();
function decorPaint(color) {
  if (!decorPaints.has(color)) { const mat = new THREE.MeshStandardMaterial({ color, metalness: 0.5, roughness: 0.35 }); mat.userData.shared = true; decorPaints.set(color, mat); }
  return decorPaints.get(color);
}
const emissive = (color, glow) => new THREE.MeshStandardMaterial({ color, emissive: glow, emissiveIntensity: 0, roughness: 0.3 });
function boxMesh(parent, material, x, y, z, w, h, d, cast = true) {
  const m = new THREE.Mesh(sharedMaterials().cube, material); m.scale.set(w, h, d); m.position.set(x, y, z); m.castShadow = cast; m.receiveShadow = true; parent.add(m); return m;
}

/** Comportement commun : clignotants (gauche, droite, détresse), gyrophares, pièce qui pulse. */
function animated(object, { blink = null, beacons = null, pulse = null, lights = null } = {}) {
  let blinking = null, siren = false, lightMode;
  const api = {
    object,
    setBlinker(side) {
      blinking = side;
      if (!side && blink) { blink.left.emissiveIntensity = 0; blink.right.emissiveIntensity = 0; }
    },
    get blinker() { return blinking; },
    setSiren(on) { siren = !!on; if (!on && beacons) beacons.forEach((m) => { m.emissiveIntensity = 0.2; }); },
    /** mode : null (éteints), 'position', 'croisement', 'route', 'brouillard' ; undefined = aspect de jour. */
    setLights(mode) { lightMode = mode; lights?.(mode); },
    get lights() { return lightMode; },
    /** Appelé à chaque image ; indique si l'aspect a changé et si le clignotant vient de s'allumer. */
    tick(time) {
      let changed = false, lit = false;
      if (blinking && blink) {
        const on = Math.floor(time / 0.4) % 2 === 0;
        const mats = blinking === 'both' ? [blink.left, blink.right] : [blink[blinking]];
        const was = mats[0].emissiveIntensity > 0;
        for (const m of mats) m.emissiveIntensity = on ? 3 : 0;
        changed = on !== was; lit = on && !was;
      }
      if (siren && beacons) {
        const phase = Math.floor(time / 0.18) % 2;
        beacons.forEach((m, i) => { m.emissiveIntensity = (i % 2) === phase ? 4 : 0.2; });
        changed = true;
      }
      if (pulse) { const k = 0.6 + 0.6 * Math.sin(time * 5); for (const m of pulse) m.emissiveIntensity = k; changed = true; }
      return { changed, lit };
    },
  };
  return api;
}

/** Feux d'un véhicule : phares, feux arrière, brouillard et halo au sol. */
function addLights(g, { frontZ, rearZ, y = 0.74, half = 0.6 }) {
  const m = sharedMaterials();
  const head = emissive('#f4f1e6', '#fff4d6'); head.emissiveIntensity = 0.6;
  const tail = emissive('#5a0d12', '#d0101e'); tail.emissiveIntensity = 0.5;
  const fog = emissive('#d9d6c8', '#fff0c0'), fogRear = emissive('#4a0b10', '#ff1a1a');
  for (const x of [half, -half]) {
    const h = new THREE.Mesh(m.lightGeo, head); h.position.set(x, y, frontZ); g.add(h);
    const t = new THREE.Mesh(m.lightGeo, tail); t.position.set(x, y + 0.04, rearZ); g.add(t);
    const f = new THREE.Mesh(m.blinkGeo, fog); f.position.set(x * 1.05, 0.42, frontZ + 0.02); g.add(f);
  }
  const fr = new THREE.Mesh(m.blinkGeo, fogRear); fr.position.set(half, 0.46, rearZ - 0.02); g.add(fr);
  const beam = new THREE.Mesh(m.beamGeo, m.beamMat); beam.name = 'faisceau'; beam.position.set(0, 0.05, frontZ + 0.2); beam.visible = false; beam.renderOrder = 2; g.add(beam);
  return (mode) => {
    const night = mode !== undefined;
    head.emissiveIntensity = !night ? 0.6 : mode === null ? 0 : mode === 'position' ? 0.5 : 2.6;
    tail.emissiveIntensity = !night ? 0.5 : mode === null ? 0 : 1.4;
    fog.emissiveIntensity = mode === 'brouillard' ? 2.4 : 0;
    fogRear.emissiveIntensity = mode === 'brouillard' ? 3 : 0;
    beam.visible = ['croisement', 'route', 'brouillard'].includes(mode);
    const [w, l] = mode === 'route' ? [9, 38] : [6, 13];
    beam.scale.set(w, 1, l);
  };
}
function addBlinkers(g, { x, front, rear, y = 0.74 }) {
  const m = sharedMaterials();
  const blink = { left: emissive('#7a4a00', '#ff9a1a'), right: emissive('#7a4a00', '#ff9a1a') };
  for (const [side, sx] of [['left', x], ['right', -x]]) for (const z of [front, rear]) {
    const b = new THREE.Mesh(m.blinkGeo, blink[side]); b.position.set(sx, y, z); g.add(b);
  }
  return blink;
}
function wheels(g, positions, r = 0.36) {
  const m = sharedMaterials();
  const geo = r === 0.36 ? m.wheelGeo : new THREE.CylinderGeometry(r, r, 0.3, 20).rotateZ(Math.PI / 2);
  for (const [x, z] of positions) { const w = new THREE.Mesh(geo, m.tyre); w.position.set(x, r, z); w.castShadow = true; g.add(w); }
}
function playerHalo(g, r = 2.6) {
  const halo = new THREE.Mesh(new THREE.RingGeometry(r, r + 0.4, 48).rotateX(-Math.PI / 2),
    new THREE.MeshBasicMaterial({ color: '#7fb6ff', transparent: true, opacity: 0.5, depthWrite: false }));
  halo.position.y = 0.06; halo.name = 'halo'; g.add(halo);
}

/**
 * Voiture orientée vers +Z (l'avant), longueur ≈ 4,3 m.
 * options : player (anneau « vous »), capot (capot ouvert, éléments du moteur visibles),
 * highlight ('pneus' | 'batterie' | 'huile' | 'refroidissement' | 'lave-glace'), coffre (coffre de toit).
 */
export function createCar(paint = PAINTS.gris, { player = false, capot = false, highlight = null, coffre = false, decor = false } = {}) {
  const m = sharedMaterials();
  const car = new THREE.Group();
  car.name = decor ? 'voiture-garee' : player ? 'voiture-joueur' : 'voiture';
  // Voiture garée du décor : matériaux tous partagés, sans feux animés, pour être fusionnée avec le décor
  const body = decor ? decorPaint(paint) : new THREE.MeshPhysicalMaterial({ color: paint, metalness: 0.55, roughness: 0.32, clearcoat: 1, clearcoatRoughness: 0.08 });
  const lower = new THREE.Mesh(new RoundedBoxGeometry(1.86, 0.62, 4.3, 4, 0.22), body); lower.position.y = 0.62;
  const cabin = new THREE.Mesh(new RoundedBoxGeometry(1.62, 0.6, 2.3, 4, 0.26), body); cabin.position.set(0, 1.18, -0.25);
  const glass = new THREE.Mesh(new RoundedBoxGeometry(1.66, 0.46, 2.12, 4, 0.2), m.glass); glass.position.set(0, 1.2, -0.25);
  const bumperF = new THREE.Mesh(new RoundedBoxGeometry(1.9, 0.2, 0.18, 2, 0.06), m.trim); bumperF.position.set(0, 0.42, 2.12);
  const bumperR = bumperF.clone(); bumperR.position.z = -2.12;
  for (const mesh of [lower, cabin, glass, bumperF, bumperR]) { mesh.castShadow = true; mesh.receiveShadow = true; car.add(mesh); }

  const pulse = [];
  const tyreMat = highlight === 'pneus' ? m.tyre.clone() : m.tyre;
  if (highlight === 'pneus') { tyreMat.emissive = new THREE.Color('#ffb347'); pulse.push(tyreMat); }
  for (const [x, z] of [[0.86, 1.35], [-0.86, 1.35], [0.86, -1.35], [-0.86, -1.35]]) {
    const w = new THREE.Mesh(m.wheelGeo, tyreMat); w.position.set(x, 0.36, z); w.castShadow = true; car.add(w);
    const r = new THREE.Mesh(m.rimGeo, m.rim); r.position.set(x + Math.sign(x) * 0.01, 0.36, z); car.add(r);
  }
  if (decor) {
    for (const x of [0.6, -0.6]) {
      const h = new THREE.Mesh(m.lightGeo, m.headOff); h.position.set(x, 0.74, 2.16); car.add(h);
      const t = new THREE.Mesh(m.lightGeo, m.tailOff); t.position.set(x, 0.78, -2.16); car.add(t);
    }
    return animated(car);
  }
  const lights = addLights(car, { frontZ: 2.16, rearZ: -2.16 });
  const blink = addBlinkers(car, { x: 0.84, front: 2.15, rear: -2.15 });

  if (capot) {
    // Capot ouvert (charnière près du pare-brise) et éléments du compartiment moteur
    const hinge = new THREE.Group(); hinge.position.set(0, 0.95, 0.95); hinge.rotation.x = -1.05; car.add(hinge);
    boxMesh(hinge, body, 0, 0.02, 0.6, 1.7, 0.05, 1.2);
    const bay = new THREE.MeshStandardMaterial({ color: '#15171a', roughness: 0.9 });
    boxMesh(car, bay, 0, 0.94, 1.45, 1.66, 0.04, 1.2, false);
    const parts = {
      moteur: () => boxMesh(car, m.metal, 0, 1.08, 1.4, 0.9, 0.26, 0.78),
      batterie: () => { const mat = emissive('#202226', '#ffb347'); boxMesh(car, mat, 0.62, 1.1, 0.95, 0.3, 0.28, 0.24); boxMesh(car, new THREE.MeshStandardMaterial({ color: '#c8102e' }), 0.55, 1.27, 0.9, 0.06, 0.05, 0.06, false); return mat; },
      huile: () => { const mat = emissive('#f2c200', '#ffb347'); const ring = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.018, 8, 16), mat); ring.position.set(0.1, 1.3, 1.45); ring.rotation.x = Math.PI / 2; car.add(ring); return mat; },
      refroidissement: () => { const mat = new THREE.MeshStandardMaterial({ color: '#f3c6d3', emissive: '#ffb347', emissiveIntensity: 0, transparent: true, opacity: 0.85, roughness: 0.2 }); const c = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.24, 16), mat); c.position.set(-0.62, 1.08, 1.0); car.add(c); boxMesh(car, new THREE.MeshStandardMaterial({ color: '#222' }), -0.62, 1.22, 1.0, 0.1, 0.05, 0.1, false); return mat; },
      'lave-glace': () => { const mat = emissive('#1e63c8', '#ffb347'); const c = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.2, 14), mat); c.position.set(-0.62, 1.06, 1.75); car.add(c); return mat; },
    };
    for (const [k, make] of Object.entries(parts)) { const mat = make(); if (k === highlight && mat) pulse.push(mat); }
  }
  if (coffre) { const box = new THREE.Mesh(new RoundedBoxGeometry(1.0, 0.36, 1.9, 3, 0.15), m.dark); box.position.set(0, 1.66, -0.3); box.castShadow = true; car.add(box); }
  if (player) playerHalo(car);
  return animated(car, { blink, pulse: pulse.length ? pulse : null, lights });
}

/** Camionnette (≈ 5,2 m, haute). */
export function createVan(paint = '#e9ecef', { player = false } = {}) {
  const m = sharedMaterials();
  const g = new THREE.Group(); g.name = 'camionnette';
  const body = new THREE.MeshStandardMaterial({ color: paint, roughness: 0.4, metalness: 0.3 });
  const box = new THREE.Mesh(new RoundedBoxGeometry(2.0, 1.9, 4.0, 3, 0.15), body); box.position.set(0, 1.35, -0.55); box.castShadow = true; g.add(box);
  const nose = new THREE.Mesh(new RoundedBoxGeometry(1.96, 0.9, 1.2, 3, 0.2), body); nose.position.set(0, 0.85, 1.95); nose.castShadow = true; g.add(nose);
  const shield = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.75), m.glass); shield.position.set(0, 1.75, 1.47); shield.rotation.x = -0.3; g.add(shield);
  wheels(g, [[0.9, 1.7], [-0.9, 1.7], [0.9, -1.6], [-0.9, -1.6]], 0.38);
  const lights = addLights(g, { frontZ: 2.56, rearZ: -2.56, y: 0.8, half: 0.7 });
  const blink = addBlinkers(g, { x: 0.92, front: 2.55, rear: -2.56, y: 0.82 });
  if (player) playerHalo(g, 3);
  return animated(g, { blink, lights });
}

/** Poids lourd porteur (≈ 11 m). */
export function createTruck(paint = '#c9ced4') {
  const m = sharedMaterials();
  const g = new THREE.Group(); g.name = 'camion';
  const cabMat = new THREE.MeshStandardMaterial({ color: '#2d5f9a', roughness: 0.45, metalness: 0.3 });
  const cab = new THREE.Mesh(new RoundedBoxGeometry(2.45, 2.6, 2.1, 3, 0.2), cabMat); cab.position.set(0, 1.85, 4.3); cab.castShadow = true; g.add(cab);
  const shield = new THREE.Mesh(new THREE.PlaneGeometry(2.1, 0.9), m.glass); shield.position.set(0, 2.4, 5.36); g.add(shield);
  const cargo = boxMesh(g, new THREE.MeshStandardMaterial({ color: paint, roughness: 0.6 }), 0, 2.1, -1.2, 2.5, 3.0, 8.4);
  cargo.name = 'caisse';
  boxMesh(g, m.dark, 0, 0.6, 0.5, 2.0, 0.3, 10.2);
  wheels(g, [[1.05, 4.1], [-1.05, 4.1], [1.05, -2.6], [-1.05, -2.6], [1.05, -4.0], [-1.05, -4.0]], 0.5);
  const lights = addLights(g, { frontZ: 5.37, rearZ: -5.42, y: 0.9, half: 0.95 });
  const blink = addBlinkers(g, { x: 1.2, front: 5.36, rear: -5.42, y: 0.92 });
  return animated(g, { blink, lights });
}

/** Autobus (≈ 12 m). */
export function createBus(paint = '#2f8f6b') {
  const m = sharedMaterials();
  const g = new THREE.Group(); g.name = 'bus';
  const body = new THREE.Mesh(new RoundedBoxGeometry(2.55, 2.9, 12, 3, 0.25), new THREE.MeshStandardMaterial({ color: paint, roughness: 0.45, metalness: 0.2 }));
  body.position.y = 1.85; body.castShadow = true; g.add(body);
  for (const s of [1, -1]) { const band = new THREE.Mesh(new THREE.PlaneGeometry(10.6, 1.0), m.glass); band.position.set(s * 1.285, 2.3, -0.2); band.rotation.y = s * Math.PI / 2; g.add(band); }
  const front = new THREE.Mesh(new THREE.PlaneGeometry(2.3, 1.4), m.glass); front.position.set(0, 2.2, 6.01); g.add(front);
  wheels(g, [[1.1, 3.8], [-1.1, 3.8], [1.1, -3.6], [-1.1, -3.6]], 0.5);
  const lights = addLights(g, { frontZ: 6.02, rearZ: -6.02, y: 0.85, half: 0.95 });
  const blink = addBlinkers(g, { x: 1.2, front: 6.02, rear: -6.02, y: 0.9 });
  return animated(g, { blink, lights });
}

/** Moto et son pilote ; `tombe` : couchée sur le flanc (scène d'accident). */
export function createMoto(paint = '#b3172a', { tombe = false } = {}) {
  const m = sharedMaterials();
  const g = new THREE.Group(); g.name = 'moto';
  const inner = new THREE.Group(); g.add(inner);
  const body = new THREE.MeshStandardMaterial({ color: paint, roughness: 0.35, metalness: 0.5 });
  const wheel = new THREE.TorusGeometry(0.32, 0.1, 10, 24).rotateY(Math.PI / 2);
  for (const z of [0.72, -0.72]) { const w = new THREE.Mesh(wheel, m.tyre); w.position.set(0, 0.42, z); w.castShadow = true; inner.add(w); }
  boxMesh(inner, body, 0, 0.78, 0.1, 0.36, 0.34, 1.1);
  boxMesh(inner, m.dark, 0, 0.98, -0.35, 0.34, 0.1, 0.7);
  if (!tombe) {
    const jacket = new THREE.MeshStandardMaterial({ color: '#222831', roughness: 0.8 });
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.45, 4, 8), jacket); torso.position.set(0, 1.4, -0.15); torso.rotation.x = 0.4; torso.castShadow = true; inner.add(torso);
    const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 12), new THREE.MeshStandardMaterial({ color: '#f2f2f2', roughness: 0.3 })); helmet.position.set(0, 1.85, 0.05); inner.add(helmet);
  } else { inner.rotation.z = Math.PI / 2; inner.position.y = 0.4; }
  g.scale.setScalar(1.2);
  const head = emissive('#f4f1e6', '#fff4d6'); head.emissiveIntensity = 0.8;
  const h = new THREE.Mesh(m.blinkGeo, head); h.position.set(0, 0.95, 0.72); inner.add(h);
  return animated(g, { lights: (mode) => { head.emissiveIntensity = mode === undefined ? 0.8 : mode === null ? 0 : 2.4; } });
}

/** Véhicules d'intérêt général prioritaires : pompiers, SMUR, police (gyrophares bleus). */
export function createEmergency(kind = 'pompiers') {
  const m = sharedMaterials();
  const g = new THREE.Group(); g.name = `prioritaire-${kind}`;
  const color = { pompiers: '#c41e1e', smur: '#f2f2f2', police: '#f2f2f2' }[kind];
  const body = new THREE.MeshStandardMaterial({ color, roughness: 0.4, metalness: 0.3 });
  const big = kind === 'pompiers';
  const box = new THREE.Mesh(new RoundedBoxGeometry(2.2, big ? 2.4 : 1.8, big ? 6.4 : 4.6, 3, 0.18), body);
  box.position.set(0, big ? 1.6 : 1.3, 0); box.castShadow = true; g.add(box);
  const stripe = new THREE.MeshStandardMaterial({ color: kind === 'pompiers' ? '#f2f2f2' : kind === 'smur' ? '#e8b417' : '#1d4f9c', roughness: 0.5 });
  for (const s of [1, -1]) boxMesh(g, stripe, s * 1.11, big ? 1.2 : 1.0, 0, 0.02, 0.22, big ? 6.2 : 4.4, false);
  const shield = new THREE.Mesh(new THREE.PlaneGeometry(1.9, 0.7), m.glass); shield.position.set(0, big ? 2.2 : 1.8, (big ? 3.2 : 2.3) + 0.01); g.add(shield);
  const half = big ? 3.2 : 2.3;
  wheels(g, [[1.0, half - 1.1], [-1.0, half - 1.1], [1.0, -half + 1.1], [-1.0, -half + 1.1]], 0.45);
  const beacons = [emissive('#0a2a8a', '#3b7bff'), emissive('#0a2a8a', '#3b7bff')];
  [0.55, -0.55].forEach((x, i) => boxMesh(g, beacons[i], x, (big ? 2.8 : 2.2) + 0.12, half - 0.6, 0.4, 0.18, 0.3, false));
  const lights = addLights(g, { frontZ: half + 0.02, rearZ: -half - 0.02, y: 0.85, half: 0.75 });
  const blink = addBlinkers(g, { x: 1.0, front: half, rear: -half, y: 0.9 });
  return animated(g, { blink, beacons, lights });
}

/** Tracteur agricole : grandes roues arrière, cabine vitrée, gyrophare orange. */
export function createTractor() {
  const m = sharedMaterials();
  const g = new THREE.Group(); g.name = 'tracteur';
  const green = new THREE.MeshStandardMaterial({ color: '#2f7a3a', roughness: 0.5, metalness: 0.2 });
  const hood = new THREE.Mesh(new RoundedBoxGeometry(1.2, 1.0, 2.0, 3, 0.12), green); hood.position.set(0, 1.25, 0.9);
  const body = new THREE.Mesh(new RoundedBoxGeometry(1.5, 0.7, 1.4, 3, 0.12), green); body.position.set(0, 1.2, -0.6);
  const cab = new THREE.Mesh(new RoundedBoxGeometry(1.45, 1.3, 1.4, 3, 0.1), m.glass); cab.position.set(0, 2.2, -0.6);
  const roof = new THREE.Mesh(new RoundedBoxGeometry(1.6, 0.12, 1.6, 2, 0.05), green); roof.position.set(0, 2.9, -0.6);
  const beacon = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.16, 12), new THREE.MeshStandardMaterial({ color: '#ff9a1a', emissive: '#ff8a00', emissiveIntensity: 1.5 }));
  beacon.position.set(0.5, 3.04, -0.6);
  for (const mesh of [hood, body, cab, roof]) { mesh.castShadow = true; g.add(mesh); }
  g.add(beacon);
  const big = new THREE.CylinderGeometry(0.8, 0.8, 0.5, 24).rotateZ(Math.PI / 2);
  const small = new THREE.CylinderGeometry(0.45, 0.45, 0.35, 20).rotateZ(Math.PI / 2);
  for (const x of [0.95, -0.95]) {
    const r = new THREE.Mesh(big, m.tyre); r.position.set(x, 0.8, -0.7); r.castShadow = true; g.add(r);
    const f = new THREE.Mesh(small, m.tyre); f.position.set(x * 0.85, 0.45, 1.35); f.castShadow = true; g.add(f);
  }
  return animated(g);
}

/** Cycliste : vélo et silhouette, gilet clair pour rester visible. */
export function createCyclist() {
  const g = new THREE.Group(); g.name = 'cycliste';
  const frame = new THREE.MeshStandardMaterial({ color: '#c0392b', metalness: 0.6, roughness: 0.35 });
  const tyre = sharedMaterials().tyre;
  const wheel = new THREE.TorusGeometry(0.34, 0.04, 8, 24).rotateY(Math.PI / 2);
  for (const z of [0.55, -0.55]) { const w = new THREE.Mesh(wheel, tyre); w.position.set(0, 0.36, z); w.castShadow = true; g.add(w); }
  const bar = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, 1.0), frame); bar.position.set(0, 0.62, 0); g.add(bar);
  const vest = new THREE.MeshStandardMaterial({ color: '#d9f04a', roughness: 0.6 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.2, 0.45, 4, 8), vest); torso.position.set(0, 1.15, -0.05); torso.rotation.x = 0.35; torso.castShadow = true;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.15, 16, 12), sharedMaterials().skin); head.position.set(0, 1.62, 0.12);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.17, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: '#1d4f9c', roughness: 0.4 })); helmet.position.set(0, 1.66, 0.12);
  const legs = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.5, 4, 8), new THREE.MeshStandardMaterial({ color: '#2b2f36', roughness: 0.8 })); legs.position.set(0, 0.72, -0.05); legs.rotation.x = -0.4;
  for (const mesh of [head, helmet, legs]) mesh.castShadow = true;
  g.add(torso, head, helmet, legs);
  g.scale.setScalar(1.1); // légèrement agrandi pour rester lisible en vue aérienne
  return animated(g);
}

const CLOTHES = ['#c0392b', '#2e86c1', '#f1c40f', '#8e44ad', '#16a085', '#d35400'];
let clothesIndex = 0;
/** Piéton (adulte ou enfant) ; `couche` : allongé au sol ; `casque` : motard tombé. */
export function createPedestrian({ enfant = false, couche = false, casque = false } = {}) {
  const m = sharedMaterials();
  const g = new THREE.Group(); g.name = enfant ? 'enfant' : 'pieton';
  const inner = new THREE.Group(); g.add(inner);
  const coat = new THREE.MeshStandardMaterial({ color: casque ? '#222831' : CLOTHES[clothesIndex++ % CLOTHES.length], roughness: 0.75 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.24, 0.6, 4, 10), coat); torso.position.y = 1.15; torso.castShadow = true; inner.add(torso);
  const legs = new THREE.Mesh(new THREE.CapsuleGeometry(0.16, 0.7, 4, 8), m.dark); legs.position.y = 0.5; legs.castShadow = true; inner.add(legs);
  const head = new THREE.Mesh(new THREE.SphereGeometry(casque ? 0.24 : 0.18, 16, 12), casque ? new THREE.MeshStandardMaterial({ color: '#f2f2f2', roughness: 0.3 }) : m.skin);
  head.position.y = 1.78; head.castShadow = true; inner.add(head);
  if (couche) { inner.rotation.x = -Math.PI / 2; inner.position.set(0, 0.25, -0.9); }
  g.scale.setScalar(enfant ? 0.8 : 1.1); // à peine agrandis : lisibles de haut, crédibles depuis le siège du conducteur
  return animated(g);
}

/** Train (locomotive et deux voitures, ≈ 60 m), orienté vers +Z. */
export function createTrain() {
  const m = sharedMaterials();
  const g = new THREE.Group(); g.name = 'train';
  const colors = ['#b8202a', '#d9dde2', '#d9dde2'];
  colors.forEach((c, i) => {
    const car = new THREE.Mesh(new RoundedBoxGeometry(3.0, 3.6, 19, 3, 0.35), new THREE.MeshStandardMaterial({ color: c, roughness: 0.45, metalness: 0.3 }));
    car.position.set(0, 2.3, -i * 20); car.castShadow = true; g.add(car);
    for (const s of [1, -1]) { const band = new THREE.Mesh(new THREE.PlaneGeometry(16, 1.0), m.glass); band.position.set(s * 1.51, 2.8, -i * 20); band.rotation.y = s * Math.PI / 2; g.add(band); }
  });
  const head = emissive('#f4f1e6', '#fff4d6'); head.emissiveIntensity = 2;
  for (const x of [0.8, -0.8]) { const h = new THREE.Mesh(m.lightGeo, head); h.position.set(x, 1.3, 9.52); g.add(h); }
  return animated(g);
}
