// Bruitages synthétisés en direct (Web Audio) : aucun fichier son, poids mémoire quasi nul.
// Volume volontairement bas ; tout passe par un gain maître que l'on peut couper.

export function createSfx() {
  let ctx = null, master = null, engineNodes = null;
  let muted = false;
  const VOLUME = 0.22;

  function ensure() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = muted ? 0 : VOLUME;
    master.connect(ctx.destination);
    return ctx;
  }

  /** Note brève avec enveloppe douce. */
  function tone(freq, { type = 'sine', dur = 0.12, gain = 0.5, delay = 0, slideTo = null } = {}) {
    const c = ensure(); if (!c || muted) return;
    const t0 = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(master);
    o.start(t0); o.stop(t0 + dur + 0.02);
  }

  /** Petit bruit filtré (clic mécanique du clignotant). */
  function click(freq = 2400, gain = 0.25) {
    const c = ensure(); if (!c || muted) return;
    const len = Math.floor(c.sampleRate * 0.025);
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 6);
    const src = c.createBufferSource(); src.buffer = buf;
    const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = freq; bp.Q.value = 3;
    const g = c.createGain(); g.gain.value = gain;
    src.connect(bp).connect(g).connect(master); src.start();
  }

  return {
    /** À appeler depuis un geste de l'utilisateur (règle des navigateurs). */
    unlock() { const c = ensure(); if (c && c.state === 'suspended') c.resume(); },
    get muted() { return muted; },
    set muted(v) {
      muted = !!v;
      if (master) master.gain.setTargetAtTime(muted ? 0 : VOLUME, ctx.currentTime, 0.05);
      if (muted) this.engine(false);
    },
    select() { tone(880, { type: 'triangle', dur: 0.07, gain: 0.25 }); },
    ui() { tone(620, { type: 'sine', dur: 0.06, gain: 0.2 }); },
    correct() { tone(1046.5, { type: 'triangle', dur: 0.18, gain: 0.35 }); tone(1318.5, { type: 'triangle', dur: 0.32, gain: 0.3, delay: 0.1 }); },
    wrong() { tone(330, { type: 'sine', dur: 0.22, gain: 0.32, slideTo: 247 }); },
    tick() { tone(1500, { type: 'sine', dur: 0.03, gain: 0.12 }); },
    blink() { click(2600, 0.18); },
    /** Ronronnement très discret pendant les déplacements. */
    engine(on) {
      const c = ensure(); if (!c) return;
      if (on && !engineNodes && !muted) {
        const o = c.createOscillator(), lfo = c.createOscillator(), lg = c.createGain(), lp = c.createBiquadFilter(), g = c.createGain();
        o.type = 'sawtooth'; o.frequency.value = 52;
        lfo.frequency.value = 7; lg.gain.value = 4; lfo.connect(lg).connect(o.frequency);
        lp.type = 'lowpass'; lp.frequency.value = 180;
        g.gain.setValueAtTime(0.0001, c.currentTime); g.gain.exponentialRampToValueAtTime(0.06, c.currentTime + 0.4);
        o.connect(lp).connect(g).connect(master); o.start(); lfo.start();
        engineNodes = { o, lfo, g };
      } else if (!on && engineNodes) {
        const { o, lfo, g } = engineNodes; engineNodes = null;
        g.gain.setTargetAtTime(0.0001, c.currentTime, 0.15);
        o.stop(c.currentTime + 0.8); lfo.stop(c.currentTime + 0.8);
      }
    },
  };
}
