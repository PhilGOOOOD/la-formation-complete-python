// Moteur de quiz — logique pure, sans DOM ni 3D, testable sous Node.

/** Générateur pseudo-aléatoire reproductible (mulberry32). */
export function createRng(seed = 1) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Mélange de Fisher-Yates, sans modifier le tableau d'origine. */
export function shuffle(list, rng = Math.random) {
  const out = list.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

/** Une réponse est juste si elle contient exactement les bonnes options. */
export function isCorrect(question, selectedIds) {
  const expected = new Set(question.correct);
  const given = new Set(selectedIds);
  if (expected.size !== given.size) return false;
  for (const id of expected) if (!given.has(id)) return false;
  return true;
}

/** Nombre de bonnes réponses d'une question. */
export function expectedCount(question) {
  return question.correct.length;
}

/**
 * Mention affichée sous la question.
 * Mode examen : seule la présence de plusieurs bonnes réponses est signalée, d'après l'exemple donné
 * par la Délégation à la sécurité routière (communiqué du 11/09/2023 sur la nouvelle banque de questions).
 * Mode aide : le nombre exact est indiqué.
 */
export function expectedHint(question, { exact = false } = {}) {
  const n = expectedCount(question);
  if (exact) return `${n} bonne${n > 1 ? 's' : ''} réponse${n > 1 ? 's' : ''}`;
  return n > 1 ? 'Plusieurs bonnes réponses' : '';
}

/** Questions d'un chapitre ('tout' pour le parcours complet). */
export function questionsFor(questions, chapter = 'tout') {
  return chapter === 'tout' ? questions.slice() : questions.filter((q) => q.chapter === chapter);
}

/**
 * Crée une session de quiz.
 * @param {Array} questions banque de questions
 * @param {{order?: 'fixed'|'shuffle', seed?: number, passMark?: number}} options
 *   passMark : proportion de bonnes réponses requise (35/40 à l'examen).
 */
export function createSession(questions, { order = 'fixed', seed = 1, passMark = 35 / 40 } = {}) {
  if (!Array.isArray(questions) || questions.length === 0) {
    throw new Error('La session a besoin d’au moins une question.');
  }
  const list = order === 'shuffle' ? shuffle(questions, createRng(seed)) : questions.slice();
  const answers = [];

  return {
    get total() { return list.length; },
    get index() { return answers.length; },
    get finished() { return answers.length >= list.length; },
    get current() { return this.finished ? null : list[answers.length]; },
    get answers() { return answers.slice(); },
    get score() { return answers.filter((a) => a.correct).length; },

    /** Enregistre la réponse à la question courante ; `timedOut` compte comme une erreur. */
    answer(selectedIds, { timedOut = false } = {}) {
      const q = this.current;
      if (!q) throw new Error('La session est terminée.');
      const selected = timedOut ? [] : Array.from(new Set(selectedIds));
      const correct = !timedOut && isCorrect(q, selected);
      const record = { id: q.id, selected, correct, timedOut };
      answers.push(record);
      return record;
    },

    /** Bilan final ; `passed` applique le même seuil proportionnel que l'examen. */
    result() {
      const score = this.score;
      const total = list.length;
      return {
        score,
        total,
        errors: total - score,
        passed: score >= Math.ceil(total * passMark - 1e-9),
        details: answers.slice(),
      };
    },
  };
}

/** Contrôle de cohérence d'une question ; renvoie la liste des problèmes trouvés. */
export function validateQuestion(q) {
  const problems = [];
  if (!q || typeof q !== 'object') return ['question absente'];
  if (!q.id) problems.push('id manquant');
  if (q.reference) { if (q.reference.length < 10) problems.push('référence trop courte'); }
  else if (!/^[RL]\d{3}-\d+(-\d+)?$/.test(q.article || '')) problems.push(`article invalide : ${q.article}`);
  if (!q.question) problems.push('énoncé manquant');
  if (!q.explanation || q.explanation.length < 40) problems.push('explication trop courte');
  const opts = q.options || [];
  if (opts.length < 2 || opts.length > 4) problems.push('il faut entre 2 et 4 options');
  const ids = opts.map((o) => o.id);
  if (ids.some((id) => !/^[A-D]$/.test(id))) problems.push('les options doivent être notées A à D (raccourcis clavier)');
  if (new Set(ids).size !== ids.length) problems.push('identifiants d’options en double');
  if (!Array.isArray(q.correct) || q.correct.length === 0) problems.push('aucune bonne réponse');
  else for (const c of q.correct) if (!ids.includes(c)) problems.push(`bonne réponse inconnue : ${c}`);
  if (q.correct && q.correct.length === opts.length) problems.push('toutes les options sont justes');
  const scene = q.scene || {};
  if (!['intersection', 'giratoire', 'rue', 'campagne', 'autoroute', 'parking'].includes(scene.site)) problems.push(`site inconnu : ${scene.site}`);
  if (!q.chapter) problems.push('chapitre manquant');
  for (const l of scene.labels || []) if (!ids.includes(l.id)) problems.push(`étiquette sans option correspondante : ${l.id}`);
  const vehicles = scene.vehicles || [];
  if (vehicles.filter((v) => v.player).length !== 1) problems.push('il faut exactement une voiture joueur');
  const vIds = new Set(vehicles.map((v) => v.id));
  for (const step of scene.resolution || []) {
    for (const m of step.go || []) {
      const id = typeof m === 'string' ? m : m.id;
      if (!vIds.has(id)) problems.push(`véhicule inconnu dans la résolution : ${id}`);
    }
  }
  return problems;
}
