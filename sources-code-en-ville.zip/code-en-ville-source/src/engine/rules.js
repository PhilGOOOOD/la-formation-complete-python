// Moteur de règles : calcule la bonne réponse d'une situation à partir des articles du Code de la route.
// Logique pure, sans 3D, testable sous Node. Chaque décision renvoie l'article qui la fonde.
import { intersectionRoute } from '../scene/routes.js';

// ——— Priorités en carrefour en croix ———
const RIGHT_OF = { S: 'E', E: 'N', N: 'W', W: 'S' }; // pour qui arrive du sud, la droite est l'est, etc.
const OPPOSITE = { S: 'N', N: 'S', E: 'W', W: 'E' };

/** Position de l'autre véhicule vue du joueur : droite | gauche | face. */
export function sideOf(meFrom, otherFrom) {
  if (otherFrom === OPPOSITE[meFrom]) return 'face';
  if (otherFrom === RIGHT_OF[meFrom]) return 'droite';
  if (otherFrom === meFrom) return 'meme';
  return 'gauche';
}

/** Les trajectoires de deux véhicules se coupent-elles (ou se rejoignent-elles) dans le carrefour ? */
export function pathsConflict(a, b) {
  const ra = intersectionRoute(a.from, a.action), rb = intersectionRoute(b.from, b.action);
  const inBox = (p) => Math.abs(p.x) < 7 && Math.abs(p.z) < 7;
  const pa = ra.points.filter(inBox), pb = rb.points.filter(inBox);
  for (const p of pa) for (const q of pb) if (Math.hypot(p.x - q.x, p.z - q.z) < 2.2) return true;
  return false;
}

/**
 * Qui passe en premier entre le joueur et un autre véhicule ?
 * regime : 'aucun' (ni panneau ni feu), 'stop' ou 'cedez' — pour l'approche de chacun.
 * Renvoie { first: 'moi' | 'autre' | null, article, alinea?, raison, sansConflit? }.
 */
export function resolvePriority(me, other) {
  const side = sideOf(me.from, other.from);
  if (side === 'meme') throw new Error('Les deux véhicules arrivent par la même route');
  if (!pathsConflict(me, other)) return { first: null, sansConflit: true, article: 'R415-1', raison: 'Les trajectoires ne se coupent pas.' };

  if (side === 'face') {
    if (me.regime !== other.regime) throw new Error('Deux approches opposées ont toujours le même régime dans ce générateur');
    const meLeft = me.action === 'left', otherLeft = other.action === 'left';
    if (meLeft && !otherLeft) return { first: 'autre', article: 'R415-4', alinea: 'III', raison: 'Je tourne à gauche : je cède le passage au véhicule qui arrive en face.' };
    if (otherLeft && !meLeft) return { first: 'moi', article: 'R415-4', alinea: 'III', raison: 'Le véhicule d’en face tourne à gauche : c’est lui qui doit me céder le passage.' };
    throw new Error('Cas non géré par le générateur (deux virages à gauche face à face)');
  }

  const signed = (r) => r === 'stop' || r === 'cedez';
  if (signed(me.regime) && !signed(other.regime)) {
    const a = me.regime === 'stop' ? 'R415-6' : 'R415-7';
    return { first: 'autre', article: a, raison: me.regime === 'stop'
      ? 'Je suis au stop : je marque l’arrêt et je cède le passage aux véhicules de l’autre route.'
      : 'Je suis au cédez-le-passage : je laisse passer les véhicules de l’autre route.' };
  }
  if (!signed(me.regime) && signed(other.regime)) {
    const a = other.regime === 'stop' ? 'R415-6' : 'R415-7';
    return { first: 'moi', article: a, raison: other.regime === 'stop'
      ? 'L’autre véhicule est au stop : il doit me céder le passage.'
      : 'L’autre véhicule a un cédez-le-passage : il doit me laisser passer.' };
  }
  // Panneaux sur deux branches perpendiculaires : R415-6 et R415-7 obligent chacun à céder le passage
  // à l'autre route ; le texte ne tranche pas, donc ces combinaisons sont exclues du générateur.
  if (signed(me.regime) || signed(other.regime)) throw new Error('Panneaux sur deux branches perpendiculaires : combinaison exclue');
  // Même régime des deux côtés : la priorité à droite s'applique
  // Ni panneau ni feu : la priorité à droite s'applique
  return side === 'droite'
    ? { first: 'autre', article: 'R415-5', raison: 'Sans panneau ni feu, la priorité à droite s’applique : le véhicule qui vient de ma droite passe en premier.' }
    : { first: 'moi', article: 'R415-5', raison: 'Sans panneau ni feu, la priorité à droite s’applique : l’autre véhicule vient de ma gauche, je passe en premier.' };
}

// ——— Vitesses maximales (conducteur d'une voiture, R413-2 à R413-5) ———
export const ROAD_TYPES = {
  agglo: 'en agglomération',
  route: 'hors agglomération, sur une route à une voie par sens',
  deuxChaussees: 'sur une route à deux chaussées séparées par un terre-plein central (hors autoroute)',
  autoroute: 'sur une autoroute',
};

/**
 * Vitesse maximale et article applicable.
 * meteo : 'sec' | 'pluie' | 'brouillard' (brouillard = visibilité inférieure à 50 m).
 */
export function speedLimit({ road, meteo = 'sec', probatoire = false }) {
  const candidates = [];
  const base = { agglo: [50, 'R413-3', ''], route: [80, 'R413-2', 'I, 3°'], deuxChaussees: [110, 'R413-2', 'I, 2°'], autoroute: [130, 'R413-2', 'I, 1°'] }[road];
  if (!base) throw new Error(`Type de route inconnu : ${road}`);
  candidates.push({ v: base[0], article: base[1], alinea: base[2], cause: 'base' });
  if (meteo === 'pluie' && road !== 'agglo') {
    const rain = { route: [80, 'II, 3°'], deuxChaussees: [100, 'II, 2°'], autoroute: [110, 'II, 1°'] }[road];
    candidates.push({ v: rain[0], article: 'R413-2', alinea: rain[1], cause: 'pluie' });
  }
  if (probatoire && road !== 'agglo') {
    const p = { route: [80, 'I, 3°'], deuxChaussees: [100, 'I, 2°'], autoroute: [110, 'I, 1°'] }[road];
    candidates.push({ v: p[0], article: 'R413-5', alinea: p[1], cause: 'probatoire' });
  }
  if (meteo === 'brouillard') candidates.push({ v: 50, article: 'R413-4', alinea: '', cause: 'brouillard' });
  // La limite la plus basse s'applique ; à égalité on cite la règle la plus spécifique (dernière ajoutée).
  let best = candidates[0];
  for (const c of candidates) if (c.v <= best.v) best = c;
  return best;
}

// ——— Dépassement d'un véhicule lent sur route à double sens (R412-18, R412-19, R414-4) ———
/** ligne : 'continue' | 'discontinue' ; cible : 'tracteur' | 'velo'. */
export function overtakeRule({ ligne, cible }) {
  if (ligne === 'discontinue') return { permis: true, article: 'R412-18', raison: 'La ligne discontinue peut être franchie : je peux dépasser si la voie de gauche est libre et que je peux me rabattre sans gêner.' };
  if (cible === 'velo') return { permis: true, article: 'R412-19', raison: 'Pour dépasser un cycle, il est permis de chevaucher la ligne continue (sans la franchir), à condition de respecter les règles du dépassement de l’article R414-4 : pouvoir le faire sans danger et laisser au moins 1,50 m d’écart hors agglomération.' };
  return { permis: false, article: 'R412-19', raison: 'La ligne continue interdit de la franchir ou de la chevaucher : je reste derrière.' };
}

// ——— Feux tricolores (R412-29 à R412-33) ———
/**
 * Le joueur peut-il franchir le feu ?
 * state : 'rouge' | 'jaune' | 'jaune-clignotant' | 'vert'
 * arretImpossible : le feu passe au jaune alors que l'arrêt ne peut plus se faire en sécurité.
 * bloque : la sortie du carrefour est encombrée (risque d'y rester immobilisé).
 */
export function trafficLight({ state, arretImpossible = false, bloque = false }) {
  if (state === 'rouge') return { passe: false, article: 'R412-30', raison: 'Le feu rouge, fixe ou clignotant, impose l’arrêt absolu, à la ligne d’arrêt quand elle existe.' };
  if (state === 'jaune') return arretImpossible
    ? { passe: true, article: 'R412-31', raison: 'Le feu jaune fixe impose l’arrêt, sauf si, au moment où il s’allume, le conducteur ne peut plus s’arrêter dans des conditions de sécurité suffisantes.' }
    : { passe: false, article: 'R412-31', raison: 'Le feu jaune fixe impose l’arrêt : j’ai la place de m’arrêter sans danger avant la ligne.' };
  if (state === 'jaune-clignotant') return { passe: true, article: 'R412-32', raison: 'Le feu jaune clignotant signale un danger et autorise le passage, sous réserve des règles de priorité.' };
  if (state === 'vert') return bloque
    ? { passe: false, article: 'R412-33', raison: 'Au feu vert, je ne m’engage dans l’intersection que si mon véhicule ne risque pas d’y être immobilisé et de bloquer la circulation transversale.' }
    : { passe: true, article: 'R412-33', raison: 'Le feu vert autorise le passage.' };
  throw new Error(`État de feu inconnu : ${state}`);
}

// ——— Éclairage la nuit (R416-5 à R416-7) ———
/**
 * Feux principaux à utiliser la nuit. lieu : 'route-sombre' | 'agglo-eclairee' ; croise / suit : présence d'un autre véhicule.
 * Renvoie { feux: 'route' | 'croisement', article, alinea, raison }.
 */
export function headlights({ lieu, croise = false, suit = false }) {
  if (croise) return { feux: 'croisement', article: 'R416-6', alinea: 'II, 1° a', raison: 'Au moment de croiser un autre véhicule, je passe en feux de croisement pour ne pas l’éblouir.' };
  if (suit) return { feux: 'croisement', article: 'R416-6', alinea: 'II, 1° b', raison: 'Quand je suis un autre véhicule à faible distance, je roule en feux de croisement (sauf pendant un dépassement).' };
  if (lieu === 'agglo-eclairee') return { feux: 'croisement', article: 'R416-6', alinea: 'II, 2°', raison: 'En agglomération, sur une route suffisamment éclairée, les feux de route sont exclus.' };
  return { feux: 'route', article: 'R416-5', raison: 'La nuit, sur une route non éclairée et sans risque d’éblouir quelqu’un, les véhicules à moteur circulent en feux de route.' };
}
/** Feux de brouillard autorisés selon la météo (R416-7). meteo : 'brouillard' | 'neige' | 'forte-pluie' | 'pluie' | 'clair'. */
export function fogLights(meteo) {
  return {
    avant: ['brouillard', 'neige', 'forte-pluie'].includes(meteo),
    arriere: ['brouillard', 'neige'].includes(meteo),
    article: 'R416-7',
  };
}

// ——— Distances (R412-12 ; ordres de grandeur pédagogiques pour le temps de réaction) ———
/** Distance parcourue (m) pendant `seconds` à `kmh`. */
export const distanceIn = (kmh, seconds) => Math.round((kmh / 3.6) * seconds);

// ——— Arrêt et stationnement (R417-11) ———
export const PARKING_SPOTS = {
  place: { permis: true, label: 'sur la place matérialisée', article: 'R417-11', alinea: 'I', raison: 'La place matérialisée est prévue pour stationner.' },
  piste: { permis: false, label: 'sur la piste cyclable', article: 'R417-11', alinea: 'I, 8° b', raison: 'La piste cyclable est réservée aux cycles.' },
  passage: { permis: false, label: 'sur le passage piéton', article: 'R417-11', alinea: 'I, 5°', raison: 'Le passage piéton doit rester libre pour les piétons.' },
  avantPassage: { permis: false, label: 'le long du trottoir, juste avant le passage piéton', article: 'R417-11', alinea: 'I, 8° c', raison: 'Les cinq mètres en amont d’un passage piéton, hors emplacement matérialisé, doivent rester dégagés.' },
  trottoir: { permis: false, label: 'sur le trottoir', article: 'R417-11', alinea: 'I, 8° a', raison: 'Le trottoir est réservé aux piétons.' },
};
