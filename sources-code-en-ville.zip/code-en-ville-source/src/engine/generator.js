// Générateur de questions aléatoires (v0.4).
// Le programme est découpé en NOTIONS (une règle ou une connaissance précise). Chaque notion sait fabriquer une
// question avec une mise en scène tirée au hasard dans les kits : branche d'arrivée, type et couleur des véhicules,
// météo, nuit, angle de vue… La bonne réponse vient du moteur de règles ou d'une fiche sourcée.
// Une série est composée par src/engine/plan.js : une notion au plus une fois, les 10 thèmes servis à tour de rôle.
import { createRng } from './quiz.js';
import { resolvePriority, pathsConflict, speedLimit, ROAD_TYPES, overtakeRule, PARKING_SPOTS,
  trafficLight, headlights, fogLights, distanceIn } from './rules.js';
import { planSession } from './plan.js';
import { SIGNS, SIGN_SOURCE, FAMILLES } from '../data/signs-catalog.js';
import { FICHES, PIECES } from '../data/fiches.js';
import { QUARTER_OF, rotateQuarter, RUE, routeFor, pointAt, toWorld } from '../scene/routes.js';

// ——— Outils ———
const pick = (rng, list) => list[Math.floor(rng() * list.length)];
function shuffleWith(rng, list) { const a = list.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const LETTERS = ['A', 'B', 'C', 'D'];
/** Options mélangées (sauf `fixe`) et lettres des bonnes réponses. */
function makeOptions(rng, ok, ko, { fixe = false } = {}) {
  const items = [...ok.map((t) => ({ t, ok: true })), ...ko.map((t) => ({ t, ok: false }))];
  if (items.length > 4) throw new Error('Quatre options au plus');
  const arr = fixe ? items : shuffleWith(rng, items);
  return { options: arr.map((o, i) => ({ id: LETTERS[i], text: o.t })), correct: arr.flatMap((o, i) => (o.ok ? [LETTERS[i]] : [])) };
}
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const lower = (s) => s.charAt(0).toLowerCase() + s.slice(1);

const ARMS = ['S', 'E', 'N', 'W'];
const RIGHT = { S: 'E', E: 'N', N: 'W', W: 'S' };
const LEFT = { S: 'W', W: 'N', N: 'E', E: 'S' };
const OPP = { S: 'N', N: 'S', E: 'W', W: 'E' };
const SIDE_ARM = { droite: (a) => RIGHT[a], gauche: (a) => LEFT[a], face: (a) => OPP[a] };
const SIDE_TEXT = { droite: 'par votre droite', gauche: 'par votre gauche', face: 'en face' };

// Couleurs : le joueur change de couleur d'une question à l'autre (l'anneau lumineux le repère toujours)
const PLAYER_PAINTS = ['joueur', 'rouge', 'blanc', 'gris', 'vert', 'noir', 'orange', 'bordeaux', 'bleuClair'];
const COLORS = [['rouge', 'rouge'], ['blanc', 'blanche'], ['jaune', 'jaune'], ['vert', 'verte'], ['gris', 'grise'], ['noir', 'noire'], ['orange', 'orange']];
/** Usagers « ordinaires » qu'on peut croiser à un carrefour. */
const KINDS = {
  voiture: { un: 'une voiture', ce: 'cette voiture', lui: 'elle' },
  camionnette: { un: 'une camionnette', ce: 'cette camionnette', lui: 'elle' },
  camion: { un: 'un camion', ce: 'ce camion', lui: 'lui' },
  bus: { un: 'un bus', ce: 'ce bus', lui: 'lui' },
  moto: { un: 'une moto', ce: 'cette moto', lui: 'elle' },
};
function otherUser(rng, { ville = true, playerPaint } = {}) {
  const kind = pick(rng, ville ? ['voiture', 'voiture', 'voiture', 'camionnette', 'camion', 'bus', 'moto'] : ['voiture', 'voiture', 'camionnette', 'camion', 'moto']);
  const K = KINDS[kind];
  if (kind !== 'voiture') return { kind, paint: kind === 'moto' ? pick(rng, ['rouge', 'noir', 'jaune']) : undefined, ...K };
  const [paint, fem] = pick(rng, COLORS.filter(([c]) => c !== playerPaint));
  return { kind, paint, un: `une voiture ${fem}`, ce: `la voiture ${fem}`, lui: 'elle' };
}
const playerPaint = (rng) => pick(rng, PLAYER_PAINTS);
const vueOf = (rng) => (rng() < 0.5 ? 'est' : 'ouest');
/** Ambiance visuelle d'une scène de carrefour : météo et éclairage. */
function ambiance(rng) { return pick(rng, ['beau', 'beau', 'beau', 'pluie', 'nuit', 'nuit']); }
/** Lampadaires aux angles d'un carrefour de ville (de nuit). */
const CORNER_LAMPS = [{ x: 6, z: 6 }, { x: -6, z: -6 }, { x: 6, z: -6 }, { x: -6, z: 6 }].map((p) => ({ type: 'lampadaire', ...p }));
/** Cadrage d'un carrefour : entre le centre et la branche d'arrivée du joueur. */
const camFor = (arm, zoom = 34) => ({ ...rotateQuarter({ x: 1.5, z: 3 }, QUARTER_OF[arm]), zoom });
const ACTION_TEXT = { straight: 'allez tout droit', left: 'tournez à gauche, clignotant allumé', right: 'tournez à droite, clignotant allumé' };
const OTHER_ACTION = { straight: 'continue tout droit', left: 'tourne à gauche', right: 'tourne à droite' };

function base(f, uid, extra) {
  return { id: `alea-${f.famille}-${uid}`, chapter: 'aleatoire', genere: f.famille, famille: f.famille, notion: f.id, domaine: f.domaine, theme: f.theme || f.famille, ...extra };
}
const beforeAfter = (K) => [{ id: 'A', text: `avant ${K.lui}` }, { id: 'B', text: `après ${K.lui}` }];

// ——————————————————— Priorités en carrefour ———————————————————
const PRIO = {
  'priorite-droite': { sides: ['droite'], me: 'aucun', other: 'aucun' },
  'priorite-gauche': { sides: ['gauche'], me: 'aucun', other: 'aucun' },
  'stop-moi': { sides: ['droite', 'gauche'], me: 'stop', other: 'aucun' },
  'cedez-moi': { sides: ['droite', 'gauche'], me: 'cedez', other: 'aucun' },
  'stop-autre': { sides: ['droite', 'gauche'], me: 'aucun', other: 'stop' },
  'cedez-autre': { sides: ['droite', 'gauche'], me: 'aucun', other: 'cedez' },
  'tourne-gauche-face': { sides: ['face'], meAction: 'left' },
  'face-tourne-gauche': { sides: ['face'], otherAction: 'left' },
};
const REGIME_ME = { aucun: 'Il n’y a ni panneau ni feu de votre côté.', stop: 'Un stop est placé à votre droite.', cedez: 'Un cédez-le-passage est placé à votre droite.' };
const REGIME_OTHER = { aucun: '', stop: ' Un stop est placé sur sa route.', cedez: ' Un cédez-le-passage est placé sur sa route.' };
function genPriorite(rng, uid, f) {
  const spec = PRIO[f.id];
  for (let attempt = 0; attempt < 200; attempt++) {
    const side = pick(rng, spec.sides);
    const meFrom = pick(rng, ARMS);
    const otherFrom = SIDE_ARM[side](meFrom);
    const faceRegime = side === 'face' ? pick(rng, ['aucun', 'aucun', 'stop', 'cedez']) : null;
    const me = { from: meFrom, action: spec.meAction || pick(rng, side === 'face' ? ['straight', 'right'] : ['straight', 'left', 'right']), regime: faceRegime || spec.me };
    const other = { from: otherFrom, action: spec.otherAction || pick(rng, side === 'face' ? ['straight', 'right'] : ['straight', 'left', 'right']), regime: faceRegime || spec.other };
    if (!pathsConflict(me, other)) continue;
    let res;
    try { res = resolvePriority(me, other); } catch (e) { if (/exclue|non géré/.test(e.message)) continue; throw e; }
    if (!res.first) continue;
    const paint = playerPaint(rng);
    const theme = pick(rng, ['ville', 'ville', 'campagne']);
    const U = otherUser(rng, { ville: theme === 'ville', playerPaint: paint });
    const weather = ambiance(rng);
    const regimeText = side === 'face' && faceRegime !== 'aucun' ? `Vous avez tous les deux ${faceRegime === 'stop' ? 'un stop' : 'un cédez-le-passage'} et vous avez marqué l’arrêt si nécessaire.` : side === 'face' ? REGIME_ME.aucun : REGIME_ME[me.regime];
    const situation = `Vous ${ACTION_TEXT[me.action]}. ${regimeText} ${cap(U.un)} arrive ${SIDE_TEXT[side]} et ${OTHER_ACTION[other.action]}.${side === 'face' ? '' : REGIME_OTHER[other.regime]}`;
    const signs = [];
    if (me.regime !== 'aucun') signs.push({ type: me.regime, approach: meFrom });
    if (other.regime !== 'aucun') signs.push({ type: other.regime, approach: otherFrom });
    const stopWait = me.regime === 'stop' && res.first === 'moi' ? [{ wait: 1.2 }] : [];
    const resolution = res.first === 'moi'
      ? [...stopWait, { go: ['moi'] }, { wait: 0.8 }, { go: ['autre'] }]
      : [{ go: ['autre'] }, { wait: 0.9 }, { go: ['moi'] }];
    const extra = me.regime === 'stop' && res.first === 'moi' ? ' Je marque tout de même l’arrêt à la ligne avant de repartir.' : '';
    return base(f, uid, {
      article: res.article, ...(res.alinea ? { alinea: res.alinea } : {}),
      situation, vue: `Carrefour ${theme === 'ville' ? 'en ville' : 'à la campagne'}${weather === 'nuit' ? ', de nuit' : weather === 'pluie' ? ', sous la pluie' : ''}. ${situation}`,
      question: `Par rapport à ${U.ce}, je passe :`,
      options: beforeAfter(U), correct: [res.first === 'moi' ? 'A' : 'B'],
      explanation: res.raison + extra,
      scene: {
        site: 'intersection', layoutOpts: { theme, camera: vueOf(rng) }, weather, signs, camera: camFor(meFrom),
        props: weather === 'nuit' && theme === 'ville' ? CORNER_LAMPS : [],
        vehicles: [{ id: 'moi', player: true, paint, from: meFrom, action: me.action }, { id: 'autre', kind: U.kind, paint: U.paint, from: otherFrom, action: other.action }],
        resolution,
      },
    });
  }
  throw new Error(`Aucune situation valide pour ${f.id}`);
}

// ——— Giratoire (R415-10) ———
function genGiratoire(rng, uid, f) {
  const arm = pick(rng, ARMS), k = QUARTER_OF[arm];
  const paint = playerPaint(rng);
  const U = otherUser(rng, { playerPaint: paint });
  const anchor = rotateQuarter({ x: 5.4, z: 16.2 }, k);
  const situation = `Vous arrivez à un carrefour à sens giratoire et voulez prendre la première sortie. ${cap(U.un)} circule déjà sur l’anneau et arrive par votre gauche.`;
  return base(f, uid, {
    article: 'R415-10', situation, vue: `Giratoire. ${situation}`,
    question: `Par rapport à ${U.ce}, j’entre dans le giratoire :`, options: beforeAfter(U), correct: ['B'],
    explanation: 'En abordant un carrefour à sens giratoire, je cède le passage aux usagers qui circulent déjà sur l’anneau, quelle que soit la route que je quitte.',
    scene: {
      site: 'giratoire', layoutOpts: { theme: pick(rng, ['ville', 'campagne']), camera: vueOf(rng) }, weather: ambiance(rng),
      signs: [{ type: 'AB3a', x: anchor.x, z: anchor.z, rotY: k * Math.PI / 2, marking: arm }],
      camera: { ...rotateQuarter({ x: 1, z: 6 }, k), zoom: 44 },
      vehicles: [{ id: 'moi', player: true, paint, action: 'ring-east', rot: k }, { id: 'autre', kind: U.kind, paint: U.paint, action: 'ring-north', rot: k }],
      resolution: [{ go: [{ id: 'autre', dist: 30 }] }, { wait: 0.5 }, { go: [{ id: 'moi', dist: 48 }] }],
    },
  });
}

// ——— Véhicule prioritaire (R415-12) ———
const PRIORITAIRES = { pompiers: { un: 'un véhicule de pompiers', ce: 'ce véhicule de pompiers', lui: 'lui' }, smur: { un: 'un véhicule du SMUR (urgence médicale)', ce: 'ce véhicule du SMUR', lui: 'lui' }, police: { un: 'une voiture de police', ce: 'cette voiture de police', lui: 'elle' } };
function genPrioritaire(rng, uid, f) {
  const meFrom = pick(rng, ARMS), otherFrom = LEFT[meFrom];
  const kind = pick(rng, Object.keys(PRIORITAIRES)), U = PRIORITAIRES[kind];
  const action = pick(rng, ['straight', 'left']);
  const situation = `Vous ${ACTION_TEXT[action]}. Il n’y a ni panneau ni feu. ${cap(U.un)} arrive par votre gauche, gyrophares et sirène en marche.`;
  return base(f, uid, {
    article: 'R415-12', situation, vue: `Carrefour. ${situation}`,
    question: `Par rapport à ${U.ce}, je passe :`, options: beforeAfter(U), correct: ['B'],
    explanation: 'Sans ses avertisseurs, la priorité à droite me permettrait de passer avant lui. Mais je dois céder le passage, en toutes circonstances, aux véhicules d’intérêt général prioritaires qui annoncent leur approche avec leurs avertisseurs spéciaux.',
    scene: {
      site: 'intersection', layoutOpts: { theme: 'ville', camera: vueOf(rng) }, weather: pick(rng, ['beau', 'beau', 'nuit', 'pluie']), camera: camFor(meFrom),
      vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), from: meFrom, action }, { id: 'autre', kind, siren: true, from: otherFrom, action: 'straight' }],
      resolution: [{ go: [{ id: 'autre', speed: 13 }] }, { wait: 1 }, { go: ['moi'] }],
    },
  });
}

// ——— Sortie de parking (R415-9) ———
function genDebouche(rng, uid, f) {
  const fromLeft = rng() < 0.5;
  const paint = playerPaint(rng);
  const U = otherUser(rng, { playerPaint: paint });
  const situation = `Vous sortez d’un parking et traversez le trottoir pour rejoindre la route. ${cap(U.un)} arrive par votre ${fromLeft ? 'gauche' : 'droite'}.`;
  return base(f, uid, {
    article: 'R415-9', alinea: 'II', situation, vue: `Sortie de parking sur une rue. ${situation}`,
    question: `Par rapport à ${U.ce}, je passe :`, options: beforeAfter(U), correct: ['B'],
    explanation: 'En débouchant d’un parking, d’un chemin de terre ou d’un accès privé, en franchissant un trottoir, je dois céder le passage à tout autre véhicule, qu’il vienne de droite ou de gauche, et m’engager à vitesse très réduite.',
    scene: {
      site: 'parking', layoutOpts: { camera: vueOf(rng) }, weather: pick(rng, ['beau', 'beau', 'pluie']), camera: { x: 1, z: -12, zoom: 34 },
      vehicles: [{ id: 'moi', player: true, paint, action: 'parking-exit' }, { id: 'autre', kind: U.kind, paint: U.paint, action: fromLeft ? 'road-east' : 'road-west' }],
      resolution: [{ go: [{ id: 'autre', dist: 40, speed: 10 }] }, { wait: 0.6 }, { go: [{ id: 'moi', dist: 40, speed: 7 }] }],
    },
  });
}

// ——————————————————— Feux tricolores ———————————————————
function lightsProps(meFrom, mine, cross = mine === 'jaune-clignotant' ? 'jaune-clignotant' : mine === 'vert' ? 'rouge' : 'vert') {
  const st = { [meFrom]: mine, [OPP[meFrom]]: mine, [RIGHT[meFrom]]: cross, [LEFT[meFrom]]: cross };
  return { props: ARMS.map((a) => ({ type: 'feu', approach: a, state: st[a] })), states: st };
}
const setAxis = (meFrom, mine, cross) => ({ feux: { [meFrom]: mine, [OPP[meFrom]]: mine, [RIGHT[meFrom]]: cross, [LEFT[meFrom]]: cross } });
function genFeux(rng, uid, f) {
  const meFrom = pick(rng, ARMS);
  const paint = playerPaint(rng);
  const weather = pick(rng, ['beau', 'beau', 'pluie', 'nuit']);
  const common = { site: 'intersection', layoutOpts: { theme: 'ville', camera: vueOf(rng) }, weather, props: [], camera: camFor(meFrom, 36) };
  const me = { id: 'moi', player: true, paint, from: meFrom, action: 'straight' };
  const night = weather === 'nuit' ? CORNER_LAMPS : [];
  const mk = (q) => base(f, uid, { ...q, vue: `Carrefour à feux${weather === 'nuit' ? ', de nuit' : ''}. ${q.situation}` });
  switch (f.id) {
    case 'feu-rouge': {
      const r = trafficLight({ state: 'rouge' });
      const L = lightsProps(meFrom, 'rouge');
      const v = rng() < 0.5;
      const opt = v ? makeOptions(rng, ['Non'], ['Oui'], { fixe: true }) : makeOptions(rng, ['à la ligne d’arrêt, avant le feu'], ['à hauteur du feu, même au-delà de la ligne', 'au milieu du carrefour pour mieux voir']);
      return mk({ article: r.article, situation: 'Le feu est rouge. Aucun véhicule ne circule sur la route transversale.',
        question: v ? 'Puis-je franchir le feu ?' : 'Je m’arrête :', ...opt,
        explanation: `${r.raison} Peu importe que la voie soit libre : le rouge impose l’arrêt absolu (4 points de retrait en cas d’infraction).`,
        scene: { ...common, props: [...L.props, ...night], vehicles: [me], resolution: [{ wait: 1 }, setAxis(meFrom, 'vert', 'rouge'), { wait: 0.6 }, { go: ['moi'] }] } });
    }
    case 'feu-jaune': {
      const r = trafficLight({ state: 'jaune' });
      const L = lightsProps(meFrom, 'jaune', 'rouge');
      const opt = makeOptions(rng, ['je m’arrête au feu'], ['j’accélère pour passer avant le rouge', 'je continue à la même vitesse']);
      return mk({ article: r.article, situation: 'Le feu vient de passer au jaune. Vous êtes encore à une vingtaine de mètres et pouvez vous arrêter sans freinage brusque.',
        question: 'Que faites-vous ?', ...opt, explanation: r.raison,
        scene: { ...common, props: [...L.props, ...night], vehicles: [{ ...me, holdShift: -12 }],
          resolution: [{ go: [{ id: 'moi', dist: 11.5, speed: 5, easing: 'outCubic' }] }, setAxis(meFrom, 'rouge', 'vert'), { wait: 1.2 }, setAxis(meFrom, 'vert', 'rouge'), { wait: 0.5 }, { go: ['moi'] }] } });
    }
    case 'feu-jaune-tard': {
      const r = trafficLight({ state: 'jaune', arretImpossible: true });
      const L = lightsProps(meFrom, 'jaune', 'rouge');
      const opt = makeOptions(rng, ['je franchis le feu avec prudence'], ['je freine brutalement pour m’arrêter à tout prix', 'je m’arrête au milieu du carrefour']);
      return mk({ article: r.article, situation: 'Le feu passe au jaune au moment précis où vous arrivez sur la ligne, à vitesse normale. Une voiture vous suit de près : un freinage brutal provoquerait une collision.',
        question: 'Que faites-vous ?', ...opt, explanation: `${r.raison} C’est le cas ici. Mieux vaut, en approchant d’un feu vert depuis longtemps, ralentir un peu pour ne pas se retrouver dans cette situation.`,
        scene: { ...common, props: [...L.props, ...night], vehicles: [{ ...me, holdShift: 1.5 }, { id: 'suiveur', paint: pick(rng, COLORS.filter(([c]) => c !== paint))[0], from: meFrom, action: 'straight', holdShift: -5 }],
          resolution: [{ go: [{ id: 'moi', dist: 34, speed: 9, easing: 'linear' }] }, setAxis(meFrom, 'rouge', 'vert'), { go: [{ id: 'suiveur', dist: 4, speed: 3, easing: 'outCubic' }] }] } });
    }
    case 'feu-clignotant': {
      const U = otherUser(rng, { playerPaint: paint });
      const L = lightsProps(meFrom, 'jaune-clignotant');
      const res = resolvePriority({ from: meFrom, action: 'straight', regime: 'aucun' }, { from: RIGHT[meFrom], action: 'straight', regime: 'aucun' });
      return mk({ article: 'R412-32', situation: `Les feux clignotent en jaune. Il n’y a pas d’autre panneau. Vous allez tout droit ; ${U.un} arrive par votre droite.`,
        question: `Par rapport à ${U.ce}, je passe :`, options: beforeAfter(U), correct: [res.first === 'moi' ? 'A' : 'B'],
        explanation: `Le feu jaune clignotant signale un danger et autorise le passage sous réserve des règles de priorité. Sans autre signalisation, la priorité à droite s’applique (article R415-5) : ${lower(res.raison.split(' : ')[1] || res.raison)}`,
        scene: { ...common, props: [...L.props, ...night], vehicles: [me, { id: 'autre', kind: U.kind, paint: U.paint, from: RIGHT[meFrom], action: 'straight' }],
          resolution: [{ go: ['autre'] }, { wait: 0.9 }, { go: ['moi'] }] } });
    }
    case 'feu-vert-encombre': {
      const r = trafficLight({ state: 'vert', bloque: true });
      const L = lightsProps(meFrom, 'vert');
      const queue = [14.5, 20, 25.5].map((s, i) => ({ id: `file${i}`, kind: i === 1 ? 'camionnette' : undefined, paint: pick(rng, COLORS)[0], from: meFrom, action: 'straight', holdShift: s }));
      return mk({ article: r.article, situation: 'Le feu est vert, mais la file de voitures arrêtées de l’autre côté du carrefour arrive jusqu’à sa sortie.',
        question: 'Je m’engage dans le carrefour ?', ...makeOptions(rng, ['Non'], ['Oui'], { fixe: true }), explanation: r.raison,
        scene: { ...common, props: [...L.props, ...night], vehicles: [me, ...queue],
          resolution: [{ wait: 0.8 }, { sync: true, go: queue.map((q) => ({ id: q.id, dist: 14, speed: 5, easing: 'inOutCubic' })) }, { go: ['moi'] }] } });
    }
    case 'feu-vert-gauche': {
      const U = otherUser(rng, { playerPaint: paint });
      const L = lightsProps(meFrom, 'vert');
      return mk({ article: 'R415-4', alinea: 'III', situation: `Le feu est vert. Vous tournez à gauche, clignotant allumé. ${cap(U.un)} arrive en face et va tout droit : son feu est vert aussi.`,
        question: `Par rapport à ${U.ce}, je passe :`, options: beforeAfter(U), correct: ['B'],
        explanation: 'Le feu vert vaut pour les deux sens. Pour tourner à gauche, je cède le passage aux véhicules qui arrivent en sens inverse, puis je tourne.',
        scene: { ...common, props: [...L.props, ...night], vehicles: [{ ...me, action: 'left' }, { id: 'autre', kind: U.kind, paint: U.paint, from: OPP[meFrom], action: 'straight' }],
          resolution: [{ go: ['autre'] }, { wait: 0.9 }, { go: ['moi'] }] } });
    }
    case 'feu-vert-pietons': {
      const L = lightsProps(meFrom, 'vert');
      const k = QUARTER_OF[meFrom];
      // Passage piéton sur la branche de droite (construit pour une arrivée par le sud, puis tourné)
      const walkers = [0, 1].map((i) => ({ id: `pieton${i}`, kind: 'pieton', enfant: i === 1 && rng() < 0.5,
        path: [{ x: 6.8 + i * 0.8, z: -9 }, { x: 6.8 + i * 0.8, z: 9 }].map((p) => rotateQuarter(p, k)), hold: rotateQuarter({ x: 6.8 + i * 0.8, z: i ? 0.5 : 2.4 }, k) }));
      return mk({ article: 'R415-11', situation: 'Le feu est vert. Vous tournez à droite, clignotant allumé. Des piétons traversent la rue dans laquelle vous vous engagez.',
        question: 'Que faites-vous ?', ...makeOptions(rng, ['je les laisse traverser avant de tourner'], ['je passe avant eux : j’ai le feu vert', 'je klaxonne pour qu’ils se pressent']),
        explanation: 'En tournant, je coupe la traversée des piétons, qui ont souvent le feu vert en même temps que moi. Je dois céder le passage au piéton qui s’engage régulièrement dans la traversée, au besoin en m’arrêtant.',
        scene: { ...common, props: [...L.props, ...night, { type: 'zebra', approach: RIGHT[meFrom] }], vehicles: [{ ...me, action: 'right' }, ...walkers],
          resolution: [{ sync: true, go: walkers.map((w) => ({ id: w.id, dist: 12, speed: 1.4, easing: 'linear' })) }, { go: ['moi'] }] } });
    }
    default: throw new Error(f.id);
  }
}

// ——————————————————— Piétons et cyclistes ———————————————————
function genPieton(rng, uid, f) {
  const engage = f.id === 'pieton-engage';
  const enfant = rng() < 0.35;
  const who = enfant ? 'Un enfant' : 'Un piéton';
  const walker = { id: 'pieton', kind: 'pieton', enfant, path: [{ x: -7.5, z: RUE.zebraZ }, { x: 11, z: RUE.zebraZ }], hold: { x: engage ? -1.2 : -5.4, z: RUE.zebraZ } };
  const situation = engage ? `${who} est engagé sur le passage piéton et traverse vers votre voie.` : `${who} attend au bord du trottoir, devant le passage piéton, et regarde la circulation : il veut traverser.`;
  return base(f, uid, {
    article: 'R415-11', situation, vue: `Rue en ville avec passage piéton. ${situation}`,
    question: 'Que faites-vous ?', ...makeOptions(rng, ['je m’arrête et je le laisse traverser'], engage ? ['je passe derrière lui sans ralentir', 'je klaxonne et je passe'] : ['je passe : il n’est pas encore sur la chaussée', 'je lui fais un appel de phares et je passe']),
    explanation: `Tout conducteur doit céder le passage, au besoin en s’arrêtant, au piéton qui s’engage régulièrement dans la traversée ou qui manifeste clairement l’intention de le faire. ${engage ? '' : 'Attendre au bord du passage en regardant la circulation, c’est manifester cette intention.'} Un refus de priorité à un piéton coûte 6 points.`,
    scene: {
      site: 'rue', weather: pick(rng, ['beau', 'beau', 'pluie', 'nuit']), camera: { x: 1, z: 15, zoom: 30 },
      vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), action: 'rue-straight', holdShift: -5 }, walker],
      resolution: [{ go: [{ id: 'pieton', dist: engage ? 12 : 16, speed: 1.4, easing: 'linear' }] }, { go: [{ id: 'moi', dist: 45 }] }],
    },
  });
}
function genVeloEcart(rng, uid, f) {
  const agglo = f.id === 'velo-ecart-agglo';
  const situation = agglo ? 'En agglomération, vous allez dépasser un cycliste qui roule sur la chaussée.' : 'Hors agglomération, vous allez dépasser un cycliste. La voie de gauche est libre et vous voyez loin.';
  // Dépassement sur la branche sud, avant le carrefour (dépasser un deux-roues reste permis près d'une intersection)
  const path = [{ x: 2, z: 80 }, { x: 2, z: 38 }, { x: -1.4, z: 29, ctrl: { x: 2, z: 32 } }, { x: -1.4, z: 18 }, { x: 2, z: 9, ctrl: { x: -1.4, z: 12 } }, { x: 2, z: -80 }];
  return base(f, uid, {
    article: 'R414-4', alinea: 'IV', situation, vue: situation,
    question: 'Je laisse entre le cycliste et ma voiture un écart latéral d’au moins :',
    ...makeOptions(rng, [agglo ? '1 m' : '1,50 m'], agglo ? ['50 cm', '1,50 m'] : ['50 cm', '1 m']),
    explanation: 'Pour dépasser un cycliste (comme un piéton, un cavalier ou un deux-roues), il faut s’écarter d’au moins 1 m en agglomération et 1,50 m hors agglomération, après l’avoir averti et seulement si le dépassement est sans danger.',
    scene: agglo
      ? { site: 'intersection', layoutOpts: { theme: 'ville', camera: vueOf(rng) }, camera: { x: 1, z: 30, zoom: 34 }, follow: 'moi',
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), path, hold: { x: 2, z: 44 } }, { id: 'velo', kind: 'velo', path: [{ x: 3.1, z: 60 }, { x: 3.1, z: -90 }], hold: { x: 3.1, z: 33 } }],
        resolution: [{ sync: true, go: [{ id: 'velo', dist: 30, speed: 4, easing: 'linear' }, { id: 'moi', dist: 55, speed: 9, easing: 'inOutCubic' }] }] }
      : { site: 'campagne', layoutOpts: { ligne: 'discontinue' }, follow: 'moi', camera: { x: 0, z: -50, zoom: 40 },
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), action: 'velo-overtake' }, { id: 'velo', kind: 'velo', action: 'velo-rive' }],
        resolution: [{ sync: true, go: [{ id: 'velo', dist: 40, speed: 5, easing: 'linear' }, { id: 'moi', dist: 55, speed: 10, easing: 'inOutCubic' }] }] },
  });
}

// ——————————————————— Vitesses maximales ———————————————————
const VITESSE = {
  'vitesse-agglo': { road: 'agglo', meteo: 'sec' },
  'vitesse-route': { road: 'route', meteo: 'sec' },
  'vitesse-2ch': { road: 'deuxChaussees', meteo: 'sec' },
  'vitesse-autoroute': { road: 'autoroute', meteo: 'sec' },
  'vitesse-pluie-autoroute': { road: 'autoroute', meteo: 'pluie' },
  'vitesse-pluie-2ch': { road: 'deuxChaussees', meteo: 'pluie' },
  'vitesse-brouillard': { road: null, meteo: 'brouillard' },
  'vitesse-probatoire-autoroute': { road: 'autoroute', meteo: 'sec', probatoire: true },
  'vitesse-probatoire-2ch': { road: 'deuxChaussees', meteo: 'sec', probatoire: true },
};
const SPEED_VALUES = [30, 50, 70, 80, 90, 100, 110, 130];
function speedExplanation(ctx, best) {
  const parts = [];
  const b = speedLimit({ road: ctx.road });
  parts.push(`${cap(ROAD_TYPES[ctx.road])}, la limite générale est de ${b.v} km/h.`);
  if (ctx.meteo === 'pluie') {
    const rv = speedLimit({ road: ctx.road, meteo: 'pluie' }).v;
    parts.push(rv < b.v ? `Par temps de pluie, elle est abaissée à ${rv} km/h.` : 'La pluie ne change pas cette limite sur ce type de route.');
  }
  if (ctx.probatoire) parts.push(`En permis probatoire, la limite sur ce type de route est de ${speedLimit({ road: ctx.road, probatoire: true }).v} km/h.`);
  if (ctx.meteo === 'brouillard') parts.push('Quand la visibilité est inférieure à 50 mètres, toutes les vitesses maximales sont abaissées à 50 km/h.');
  if (best.v !== b.v) parts.push(`La limite la plus basse s’applique : ${best.v} km/h.`);
  return parts.join(' ');
}
function genVitesse(rng, uid, f) {
  const spec = VITESSE[f.id];
  const road = spec.road || pick(rng, ['route', 'deuxChaussees', 'autoroute']);
  const { meteo } = spec;
  const probatoire = !!spec.probatoire;
  const best = speedLimit({ road, meteo, probatoire });
  const near = SPEED_VALUES.filter((v) => v !== best.v).sort((a, b) => Math.abs(a - best.v) - Math.abs(b - best.v)).slice(0, 4);
  const values = [best.v, ...shuffleWith(rng, near).slice(0, 2)].sort((a, b) => a - b);
  const meteoText = { sec: pick(rng, ['Il fait sec.', 'Le temps est clair.']), pluie: 'Il pleut.', brouillard: 'Un brouillard épais limite la visibilité à environ 40 mètres.' }[meteo];
  const permis = probatoire ? 'Vous êtes en permis probatoire.' : 'Vous avez le permis depuis plus de trois ans.';
  const site = road === 'agglo' ? pick(rng, ['intersection', 'rue']) : road === 'route' ? 'campagne' : 'autoroute';
  const nuit = meteo === 'sec' && rng() < 0.25;
  const situation = `Vous roulez ${ROAD_TYPES[road]}${nuit ? ', de nuit' : ''}. ${meteoText} ${permis} Aucun panneau n’indique de limitation particulière.`;
  const arm = pick(rng, ARMS);
  const vehicle = site === 'intersection' ? { id: 'moi', player: true, paint: playerPaint(rng), from: arm, action: 'straight' }
    : site === 'rue' ? { id: 'moi', player: true, paint: playerPaint(rng), action: 'rue-straight' }
      : site === 'campagne' ? { id: 'moi', player: true, paint: playerPaint(rng), action: 'rural-straight' } : { id: 'moi', player: true, paint: playerPaint(rng), action: pick(rng, ['motorway-cruise', 'motorway-left']) };
  const traffic = site === 'autoroute' && rng() < 0.6 ? [{ id: 'camion', kind: 'camion', path: [{ x: 6.75, z: 20 }, { x: 6.75, z: -160 }], hold: { x: 6.75, z: -14 } }] : [];
  return base(f, uid, {
    article: best.article, ...(best.alinea ? { alinea: best.alinea } : {}), situation, vue: situation,
    question: 'Quelle est votre vitesse maximale autorisée ?',
    options: values.map((v, i) => ({ id: LETTERS[i], text: `${v} km/h` })), correct: [LETTERS[values.indexOf(best.v)]],
    explanation: speedExplanation({ road, meteo, probatoire }, best),
    scene: {
      site, weather: meteo === 'sec' ? (nuit ? 'nuit' : 'beau') : meteo,
      layoutOpts: site === 'intersection' ? { theme: 'ville', camera: vueOf(rng) } : road === 'deuxChaussees' ? { bretelle: false } : {},
      signs: site === 'campagne' ? [{ type: 'sortie-agglo', x: 5.6, z: 3, rotY: 0 }] : [],
      ...(site === 'campagne' ? { camera: { x: 2, z: 4, zoom: 36 } } : site === 'intersection' ? { camera: camFor(arm) } : {}),
      follow: 'moi', vehicles: [vehicle, ...traffic],
      resolution: [{ sync: true, go: [{ id: 'moi', dist: 45, speed: site === 'autoroute' ? 15 : 10 }, ...traffic.map((t) => ({ id: t.id, dist: 30, speed: 11, easing: 'linear' }))] }],
    },
  });
}

// ——————————————————— Panneaux ———————————————————
/** Chapitre de révision d'un panneau selon sa famille. */
export const SIGN_CHAPTER = { danger: 'panneaux-danger', priorite: 'panneaux-priorite', interdiction: 'panneaux-interdiction', fin: 'panneaux-interdiction',
  obligation: 'panneaux-obligation', zone: 'panneaux-indication', indication: 'panneaux-indication', service: 'panneaux-indication', localisation: 'panneaux-indication' };
/** Familles voisines : leurres plausibles quand la famille du panneau est trop petite. */
const NEAR = { fin: ['interdiction'], zone: ['indication', 'interdiction'], service: ['indication'], localisation: ['indication', 'zone'], priorite: ['danger'] };
function signDistractors(rng, sign, n) {
  const ok = (s) => s.code !== sign.code && s.sens !== sign.sens;
  const same = shuffleWith(rng, SIGNS.filter((s) => ok(s) && s.famille === sign.famille));
  const near = shuffleWith(rng, SIGNS.filter((s) => ok(s) && (NEAR[sign.famille] || []).includes(s.famille)));
  const rest = shuffleWith(rng, SIGNS.filter((s) => ok(s) && s.famille !== sign.famille));
  const out = [];
  for (const s of [...same, ...near, ...rest]) if (out.length < n && !out.some((o) => o.sens === s.sens)) out.push(s);
  return out;
}
/** Panneau posé à droite de la route suivie, dans un décor tiré au hasard ; caméra rapprochée pour bien le lire. */
function signPlacement(rng, sign) {
  const where = sign.famille === 'localisation' ? 'campagne' : pick(rng, ['ville', 'campagne', 'route', 'rue']);
  return {
    campagne: { site: 'campagne', sign: { x: 5.6, z: 3 }, camera: { x: 4.6, z: 3.8, zoom: 12 }, v: { action: 'rural-straight' } },
    route: { site: 'campagne', sign: { x: 5.6, z: -6 }, camera: { x: 4.6, z: -5.2, zoom: 12 }, v: { action: 'rural-straight' } },
    ville: { site: 'intersection', sign: { x: 5.2, z: 16 }, camera: { x: 4.3, z: 16.8, zoom: 11 }, v: { from: 'S', action: 'straight' }, layoutOpts: { theme: pick(rng, ['ville', 'campagne']) } },
    rue: { site: 'rue', sign: { x: 9.2, z: 22 }, camera: { x: 8, z: 22.8, zoom: 11 }, v: { action: 'rue-straight' } },
  }[where];
}
const familleText = (sign) => `C’est un panneau ${FAMILLES[sign.famille].nom} : ${FAMILLES[sign.famille].forme}.`;

function genPanneau(rng, uid, f) {
  const sign = SIGNS.find((s) => s.code === f.code);
  const choices = shuffleWith(rng, [sign, ...signDistractors(rng, sign, 3)]);
  const place = signPlacement(rng, sign);
  return base(f, uid, {
    reference: SIGN_SOURCE, signCode: sign.code, situation: pick(rng, ['Vous arrivez à hauteur de ce panneau.', 'Ce panneau est implanté au bord de votre route.', 'Vous apercevez ce panneau.']),
    vue: `Panneau au bord de la route : ${sign.desc}.`, signDesc: sign.desc,
    question: 'Que signifie ce panneau ?',
    options: choices.map((s, i) => ({ id: LETTERS[i], text: s.sens })), correct: [LETTERS[choices.indexOf(sign)]],
    explanation: `Ce panneau (${sign.code}) signifie : ${lower(sign.sens)}. ${familleText(sign)}`,
    scene: {
      site: place.site, layoutOpts: place.layoutOpts || {}, weather: pick(rng, ['beau', 'beau', 'pluie']),
      signs: [{ type: sign.code, ...place.sign, rotY: 0 }], camera: place.camera,
      vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), ...place.v }],
      resolution: [{ go: [{ id: 'moi', dist: 40, speed: 10 }] }],
    },
  });
}

/** « Quel panneau signifie… ? » : quatre panneaux plantés au bord de la route, repérés A à D. */
function genPanneauImage(rng, uid, f) {
  const pool = SIGNS.filter((s) => SIGN_CHAPTER[s.famille] === f.chapitre);
  const target = pick(rng, pool);
  const choices = shuffleWith(rng, [target, ...signDistractors(rng, target, 3)]);
  const zs = [8, 2.5, -3, -8.5];
  return base(f, uid, {
    reference: SIGN_SOURCE, situation: 'Quatre panneaux sont alignés au bord de la route, repérés par les lettres A à D.',
    vue: `Quatre panneaux au bord d’une route de campagne. ${choices.map((s, i) => `${LETTERS[i]} : ${s.desc}`).join(' ; ')}.`,
    question: `Quel panneau signifie : « ${target.sens} » ?`,
    options: choices.map((s, i) => ({ id: LETTERS[i], text: `Panneau ${LETTERS[i]}`, signCode: s.code, alt: s.desc })),
    correct: [LETTERS[choices.indexOf(target)]],
    explanation: `C’est le panneau ${LETTERS[choices.indexOf(target)]} (${target.code}). ${familleText(target)} Les autres signifient : ${choices.filter((s) => s !== target).map((s) => `${s.code}, ${lower(s.sens)}`).join(' ; ')}.`,
    scene: {
      site: 'campagne', weather: pick(rng, ['beau', 'beau', 'pluie']), camera: { x: 4.4, z: 0, zoom: 22 },
      signs: choices.map((s, i) => ({ type: s.code, x: 5.8, z: zs[i], rotY: 0 })),
      labels: choices.map((s, i) => ({ id: LETTERS[i], x: 7.6, z: zs[i], scale: 0.7 })),
      vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), action: 'rural-straight' }],
      resolution: [{ go: [{ id: 'moi', dist: 40, speed: 10 }] }],
    },
  });
}

/** Famille d'un panneau d'après sa forme et ses couleurs. */
const FORMES = ['danger', 'interdiction', 'obligation', 'indication'];
function genForme(rng, uid, f) {
  const sign = pick(rng, SIGNS.filter((s) => s.famille === f.fam && !/^B14/.test(s.code)));
  const opts = shuffleWith(rng, FORMES);
  const place = signPlacement(rng, sign);
  return base(f, uid, {
    reference: SIGN_SOURCE, signCode: sign.code, signDesc: sign.desc, situation: 'Observez la forme et les couleurs de ce panneau.',
    vue: `Panneau : ${sign.desc}.`, question: 'Ce panneau appartient à la famille des panneaux :',
    options: opts.map((k, i) => ({ id: LETTERS[i], text: FAMILLES[k].nom })), correct: [LETTERS[opts.indexOf(f.fam)]],
    explanation: `${familleText(sign)} Ici, il s’agit du panneau ${sign.code} : ${lower(sign.sens)}. Repères : triangle bordé de rouge = danger ; disque bordé de rouge = interdiction ; disque bleu = obligation ; carré ou rectangle bleu = indication.`,
    scene: { site: place.site, layoutOpts: place.layoutOpts || {}, signs: [{ type: sign.code, ...place.sign, rotY: 0 }], camera: place.camera,
      vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), ...place.v }], resolution: [{ go: [{ id: 'moi', dist: 40, speed: 10 }] }] },
  });
}

/** Mises en situation : le panneau dans son contexte, et ce qu'il autorise ou interdit. */
const SITUATIONS = {
  'sit-sens-interdit': { chapitre: 'panneaux-interdiction', make(rng, f, uid) {
    const arm = pick(rng, ARMS), k = QUARTER_OF[arm];
    const p = rotateQuarter({ x: 7.5, z: 5.6 }, k);
    return { article: 'R412-28', signCode: 'B1', situation: 'Vous voulez tourner à droite. Ce panneau est implanté à l’entrée de la rue de droite, face à vous quand vous tournez.',
      question: 'Pouvez-vous vous engager dans cette rue ?', ...makeOptions(rng, ['Non'], ['Oui'], { fixe: true }),
      explanation: 'Le panneau B1 signale un sens interdit à tout véhicule : je ne peux pas m’y engager et je continue tout droit. Circuler en sens interdit coûte 4 points.',
      scene: { site: 'intersection', layoutOpts: { theme: 'ville', camera: vueOf(rng) }, camera: camFor(arm, 30), signs: [{ type: 'B1', x: p.x, z: p.z, rotY: -Math.PI / 2 + k * Math.PI / 2 }],
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), from: arm, action: 'straight' }], resolution: [{ go: ['moi'] }] } };
  } },
  'sit-tourner-gauche': { chapitre: 'panneaux-interdiction', make(rng, f, uid) {
    const arm = pick(rng, ARMS);
    return { reference: SIGN_SOURCE, signCode: 'B2a', situation: 'Vous comptiez tourner à gauche à la prochaine intersection. Ce panneau est placé à votre droite.',
      question: 'Que faites-vous ?', ...makeOptions(rng, ['je prends une autre direction'], ['je tourne à gauche si personne n’arrive en face', 'je tourne à gauche en m’arrêtant d’abord']),
      explanation: 'Le panneau B2a interdit de tourner à gauche à la prochaine intersection, même si la voie est libre : je continue tout droit ou je tourne à droite.',
      scene: { site: 'intersection', layoutOpts: { theme: pick(rng, ['ville', 'campagne']), camera: vueOf(rng) }, camera: camFor(arm), signs: [{ type: 'B2a', approach: arm }],
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), from: arm, action: 'straight' }], resolution: [{ go: ['moi'] }] } };
  } },
  'sit-direction-droite': { chapitre: 'panneaux-obligation', make(rng, f, uid) {
    const arm = pick(rng, ARMS);
    return { reference: SIGN_SOURCE, signCode: 'B21c1', situation: 'Ce panneau est placé à votre droite, avant l’intersection.',
      question: 'Puis-je continuer tout droit ?', ...makeOptions(rng, ['Non'], ['Oui'], { fixe: true }),
      explanation: 'Le panneau B21c1 (disque bleu, flèche qui tourne à droite) rend obligatoire la direction à droite à la prochaine intersection.',
      scene: { site: 'intersection', layoutOpts: { theme: pick(rng, ['ville', 'campagne']), camera: vueOf(rng) }, camera: camFor(arm), signs: [{ type: 'B21c1', approach: arm }],
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), from: arm, action: 'right' }], resolution: [{ go: ['moi'] }] } };
  } },
  'sit-stop-vide': { chapitre: 'panneaux-priorite', make(rng, f, uid) {
    const arm = pick(rng, ARMS);
    return { article: 'R415-6', signCode: 'AB4', situation: 'Vous arrivez à ce panneau. Aucun véhicule n’est en vue sur la route que vous allez croiser.',
      question: 'Dois-je marquer un temps d’arrêt ?', ...makeOptions(rng, ['Oui'], ['Non'], { fixe: true }),
      explanation: 'Au stop, je marque toujours un temps d’arrêt à la limite de la chaussée abordée (à la ligne), même si la voie est libre, puis je ne m’engage qu’après m’être assuré que je peux le faire sans danger.',
      scene: { site: 'intersection', layoutOpts: { theme: 'campagne', camera: vueOf(rng) }, camera: camFor(arm), signs: [{ type: 'stop', approach: arm }],
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), from: arm, action: pick(rng, ['straight', 'left', 'right']) }], resolution: [{ wait: 1.4 }, { go: ['moi'] }] } };
  } },
  'sit-arret-depose': { chapitre: 'panneaux-interdiction', make(rng, f, uid) {
    const total = rng() < 0.5;
    const code = total ? 'B6d' : 'B6a1';
    return { article: 'R110-2', signCode: code, situation: `Ce panneau est implanté le long du trottoir. Vous voulez juste laisser descendre un passager, en restant au volant.`,
      question: 'Puis-je m’arrêter ici le temps qu’il descende ?', ...makeOptions(rng, [total ? 'Non' : 'Oui'], [total ? 'Oui' : 'Non'], { fixe: true }),
      explanation: total
        ? 'Le panneau B6d interdit l’arrêt et le stationnement : même une immobilisation de quelques secondes pour déposer quelqu’un est interdite.'
        : 'Le panneau B6a1 interdit seulement le stationnement. L’arrêt reste permis : c’est l’immobilisation momentanée pour laisser monter ou descendre quelqu’un (ou charger, décharger), le conducteur restant aux commandes ou à proximité.',
      scene: { site: 'rue', camera: { x: 6, z: 32, zoom: 20 }, signs: [{ type: code, x: 8.7, z: 30, rotY: 0 }],
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), action: 'rue-straight', holdShift: -14 }], resolution: [{ go: [{ id: 'moi', dist: 60 }] }] } };
  } },
  'sit-interdiction-depasser': { chapitre: 'panneaux-interdiction', make(rng, f, uid) {
    const velo = rng() < 0.5;
    const ahead = velo ? { id: 'lent', kind: 'velo', action: 'velo-rive' } : { id: 'lent', paint: pick(rng, COLORS)[0], path: [{ x: 2, z: -20 }, { x: 2, z: -200 }], hold: { x: 2, z: -50 } };
    return { reference: SIGN_SOURCE, signCode: 'B3', situation: `Vous venez de passer ce panneau. ${velo ? 'Un cycliste' : 'Une voiture'} roule lentement devant vous ; la voie de gauche est libre.`,
      question: `Puis-je dépasser ${velo ? 'ce cycliste' : 'cette voiture'} ?`, ...makeOptions(rng, [velo ? 'Oui, si je peux le faire sans danger' : 'Non'], [velo ? 'Non' : 'Oui, si je peux le faire sans danger'], { fixe: true }),
      explanation: `Le panneau B3 interdit de dépasser tous les véhicules à moteur, sauf les deux-roues sans side-car. ${velo ? 'Un vélo n’est pas un véhicule à moteur : je peux le dépasser, dans les conditions habituelles (sans danger, avec au moins 1,50 m d’écart hors agglomération).' : 'Une voiture est un véhicule à moteur : je reste derrière jusqu’au panneau de fin d’interdiction.'}`,
      scene: { site: 'campagne', layoutOpts: { ligne: 'discontinue' }, camera: { x: 2, z: -20, zoom: 40 }, signs: [{ type: 'B3', x: 5.6, z: -12, rotY: 0 }],
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), ...(velo ? { action: 'velo-overtake' } : { path: [{ x: 2, z: 30 }, { x: 2, z: -200 }], hold: { x: 2, z: -38 } }) }, ahead],
        resolution: [{ sync: true, go: [{ id: 'lent', dist: 40, speed: 5, easing: 'linear' }, { id: 'moi', dist: velo ? 55 : 30, speed: velo ? 10 : 5, easing: velo ? 'inOutCubic' : 'linear' }] }] } };
  } },
  'sit-entree-agglo': { chapitre: 'panneaux-indication', make(rng, f, uid) {
    return { article: 'R413-3', signCode: 'EB10', situation: 'Vous arrivez de la campagne et passez ce panneau. Aucun autre panneau de vitesse n’est implanté.',
      question: 'Votre vitesse maximale devient :', ...makeOptions(rng, ['50 km/h'], ['30 km/h', '70 km/h', '80 km/h']),
      explanation: 'Le panneau EB10 marque l’entrée d’une agglomération : la vitesse y est limitée à 50 km/h, sauf signalisation contraire.',
      scene: { site: 'campagne', camera: { x: -3, z: -2, zoom: 22 }, signs: [{ type: 'EB10', x: -5.6, z: -4, rotY: Math.PI }],
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), action: 'rural-oncoming', holdShift: 12 }], resolution: [{ go: [{ id: 'moi', dist: 40 }] }] } };
  } },
  'sit-sens-inverse': { chapitre: 'panneaux-interdiction', make(rng, f, uid) {
    const prioritaire = rng() < 0.5;
    const code = prioritaire ? 'C18' : 'B15';
    const U = otherUser(rng, { ville: false });
    return { reference: SIGN_SOURCE, signCode: code, situation: `Plus loin, la chaussée se rétrécit et deux véhicules ne peuvent pas s’y croiser. Ce panneau est placé à votre droite. ${cap(U.un)} arrive en face.`,
      question: `Par rapport à ${U.ce}, je passe :`, options: beforeAfter(U), correct: [prioritaire ? 'A' : 'B'],
      explanation: prioritaire ? 'Le panneau C18 (carré bleu, flèche blanche vers le haut) m’indique que j’ai la priorité sur la circulation venant en sens inverse dans le passage étroit.'
        : 'Le panneau B15 (disque bordé de rouge, flèche rouge vers le haut) m’impose de céder le passage à la circulation venant en sens inverse.',
      scene: { site: 'campagne', camera: { x: 1, z: -6, zoom: 36 }, signs: [{ type: code, x: 5.6, z: 0, rotY: 0 }],
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), action: 'rural-straight' }, { id: 'autre', kind: U.kind, paint: U.paint, action: 'rural-oncoming' }],
        resolution: prioritaire ? [{ go: [{ id: 'moi', dist: 45 }] }, { wait: 0.6 }, { go: [{ id: 'autre', dist: 60 }] }] : [{ go: [{ id: 'autre', dist: 60, speed: 11 }] }, { wait: 0.8 }, { go: [{ id: 'moi', dist: 45 }] }] } };
  } },
  'sit-zone-rencontre': { chapitre: 'panneaux-indication', make(rng, f, uid) {
    return { article: 'R110-2', signCode: 'B52', situation: 'Vous entrez dans une zone signalée par ce panneau.',
      question: 'Dans cette zone :', ...makeOptions(rng, ['les piétons peuvent marcher sur la chaussée et sont prioritaires', 'la vitesse est limitée à 20 km/h'], ['la vitesse est limitée à 30 km/h', 'les voitures sont prioritaires sur les piétons']),
      explanation: 'En zone de rencontre, les piétons peuvent circuler sur la chaussée (sans y stationner) et ont la priorité sur les véhicules. La vitesse est limitée à 20 km/h.',
      scene: { site: 'rue', camera: { x: 4, z: 20, zoom: 22 }, signs: [{ type: 'B52', x: 9.2, z: 22, rotY: 0 }],
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), action: 'rue-straight' }, { id: 'pieton', kind: 'pieton', path: [{ x: -1, z: 4 }, { x: -1, z: -30 }], hold: { x: -1, z: 6 } }],
        resolution: [{ sync: true, go: [{ id: 'pieton', dist: 10, speed: 1.3, easing: 'linear' }, { id: 'moi', dist: 25, speed: 5 }] }] } };
  } },
  'sit-zone-30': { chapitre: 'panneaux-indication', make(rng, f, uid) {
    return { article: 'R110-2', signCode: 'B30', situation: 'Vous passez ce panneau en entrant dans un quartier.',
      question: 'Votre vitesse maximale est désormais de :', ...makeOptions(rng, ['30 km/h'], ['20 km/h', '50 km/h']),
      explanation: 'Le panneau B30 marque l’entrée d’une zone 30 : la vitesse des véhicules y est limitée à 30 km/h jusqu’au panneau de sortie de zone (B51).',
      scene: { site: 'rue', camera: { x: 7, z: 22, zoom: 16 }, signs: [{ type: 'B30', x: 9.2, z: 22, rotY: 0 }],
        vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), action: 'rue-straight' }], resolution: [{ go: [{ id: 'moi', dist: 40, speed: 6 }] }] } };
  } },
};
function genSituationPanneau(rng, uid, f) {
  const q = SITUATIONS[f.id].make(rng, f, uid);
  const sign = SIGNS.find((s) => s.code === (q.signCode === 'stop' ? 'AB4' : q.signCode));
  return base(f, uid, { ...q, signDesc: sign?.desc, vue: `${q.situation} Panneau : ${sign?.desc}.` });
}

// ——————————————————— Dépassement ———————————————————
const DEPASSEMENT = { 'depasser-tracteur-continue': { ligne: 'continue', cible: 'tracteur' }, 'depasser-tracteur-discontinue': { ligne: 'discontinue', cible: 'tracteur' }, 'depasser-velo-continue': { ligne: 'continue', cible: 'velo' } };
function genDepassement(rng, uid, f) {
  const variant = DEPASSEMENT[f.id];
  const rule = overtakeRule(variant);
  const isVelo = variant.cible === 'velo';
  const target = isVelo ? 'un cycliste' : pick(rng, ['un tracteur', 'un engin agricole']);
  const situation = `Sur une route de campagne, ${target} roule lentement devant vous. La ligne au milieu de la chaussée est ${variant.ligne}. La voie de gauche est libre et vous voyez loin devant.`;
  const opt = isVelo
    ? makeOptions(rng, ['je peux le dépasser en chevauchant la ligne, si je peux le faire sans danger et en laissant au moins 1,50 m d’écart'], ['je ne peux pas le dépasser tant que la ligne est continue'])
    : variant.ligne === 'continue'
      ? makeOptions(rng, ['je reste derrière jusqu’à ce que la ligne devienne discontinue'], ['je le dépasse en franchissant la ligne puisqu’il roule lentement'])
      : makeOptions(rng, ['je peux le dépasser, si je peux me rabattre sans gêner'], ['je dois rester derrière lui']);
  const me = { id: 'moi', player: true, paint: playerPaint(rng), action: isVelo ? 'velo-overtake' : variant.ligne === 'continue' ? 'rural-follow' : 'rural-overtake' };
  const lent = { id: 'lent', kind: isVelo ? 'velo' : 'tracteur', action: isVelo ? 'velo-rive' : 'tractor' };
  const slow = isVelo ? 5 : 4.5;
  const resolution = variant.ligne === 'continue' && !isVelo
    ? [{ sync: true, go: [{ id: 'lent', dist: 30, speed: slow, easing: 'linear' }, { id: 'moi', dist: 30, speed: slow, easing: 'linear' }] },
      { sync: true, go: [{ id: 'lent', dist: 40, speed: slow, easing: 'linear' }, { id: 'moi', dist: 70, speed: 11, easing: 'inOutCubic' }] }]
    : [{ sync: true, go: [{ id: 'lent', dist: 40, speed: slow, easing: 'linear' }, { id: 'moi', dist: 55, speed: 10, easing: 'inOutCubic' }] }];
  return base(f, uid, {
    article: rule.article, situation, vue: situation, question: `Pouvez-vous dépasser ${isVelo ? 'ce cycliste' : 'ce véhicule lent'} ?`, ...opt,
    explanation: rule.raison + (isVelo ? ' Il faut aussi avertir l’usager dépassé et pouvoir reprendre sa place sans gêner.' : ''),
    scene: {
      site: 'campagne', layoutOpts: { ligne: variant.ligne }, follow: 'moi', weather: pick(rng, ['beau', 'beau', 'pluie']),
      camera: { x: 0, z: variant.ligne === 'continue' && !isVelo ? -58 : -50, zoom: 40 }, vehicles: [me, lent], resolution,
    },
  });
}

// ——————————————————— Arrêt et stationnement ———————————————————
const SPOT_POS = { place: { x: 5.3, z: 37.7 }, piste: { x: 7.4, z: 43.5 }, passage: { x: 1.5, z: 13 }, avantPassage: { x: 3.3, z: 16.8 }, trottoir: { x: 5.3, z: 22.5 } };
function genStationnement(rng, uid, f) {
  const askForbidden = f.id === 'stationnement-interdit';
  const illegal = shuffleWith(rng, ['piste', 'passage', 'avantPassage', 'trottoir']).slice(0, 2);
  const spots = shuffleWith(rng, ['place', ...illegal]);
  const options = spots.map((k, i) => ({ id: LETTERS[i], text: `${PARKING_SPOTS[k].label} (${LETTERS[i]})` }));
  const correct = spots.flatMap((k, i) => ((PARKING_SPOTS[k].permis !== askForbidden) ? [LETTERS[i]] : []));
  return base(f, uid, {
    article: 'R417-11', alinea: 'I',
    situation: 'Vous cherchez à vous garer dans cette rue. Trois endroits sont repérés par les lettres A, B et C.',
    vue: `Rue avec places, piste cyclable et passage piéton. ${spots.map((k, i) => `${LETTERS[i]} : ${PARKING_SPOTS[k].label}`).join(' ; ')}.`,
    question: askForbidden ? 'Où l’arrêt et le stationnement sont-ils interdits ?' : 'Où avez-vous le droit de stationner ?',
    options, correct,
    explanation: `Seule la place matérialisée convient. Aux deux autres endroits, l’arrêt comme le stationnement sont très gênants, même pour un instant. ${illegal.map((k) => PARKING_SPOTS[k].raison).join(' ')}`,
    scene: {
      site: 'rue', camera: { x: 3, z: 28, zoom: 44 }, weather: pick(rng, ['beau', 'beau', 'pluie']),
      labels: spots.map((k, i) => ({ id: LETTERS[i], ...SPOT_POS[k] })),
      vehicles: [{ id: 'moi', player: true, paint: playerPaint(rng), action: 'park' }],
      resolution: [{ wait: 0.3 }, { go: [{ id: 'moi', speed: 4, easing: 'inOutCubic' }] }],
    },
  });
}

// ——————————————————— Distances de sécurité (R412-12) ———————————————————
function genDistance(rng, uid, f) {
  const paint = playerPaint(rng);
  const lead = { id: 'devant', paint: pick(rng, COLORS.filter(([c]) => c !== paint))[0], action: 'rural-lead' };
  const follow = { sync: true, go: [{ id: 'devant', dist: 60, speed: 14, easing: 'linear' }, { id: 'moi', dist: 60, speed: 14, easing: 'linear' }] };
  if (f.id === 'distance-2s') {
    return base(f, uid, {
      article: 'R412-12', alinea: 'I', situation: 'Vous suivez une voiture sur une route de campagne. Elle passe à hauteur de la borne.',
      vue: 'Route de campagne : votre voiture suit une autre voiture ; une borne au bord de la route sert de repère.',
      question: 'Pour respecter la distance de sécurité, j’arrive à hauteur de la borne au moins :',
      ...makeOptions(rng, ['deux secondes après elle'], ['une seconde après elle', 'une demi-seconde après elle']),
      explanation: 'La distance de sécurité correspond à la distance parcourue pendant au moins deux secondes. Astuce : choisir un repère fixe et compter « un… deux… » quand le véhicule de devant le dépasse.',
      scene: { site: 'campagne', weather: pick(rng, ['beau', 'pluie']), camera: { x: 3, z: -6, zoom: 40 }, follow: 'moi', props: [{ type: 'borne', x: 4.8, z: -20 }],
        vehicles: [{ id: 'moi', player: true, paint, action: 'rural-straight' }, lead], resolution: [follow] },
    });
  }
  if (f.id === 'distance-calcul') {
    const [v, site] = pick(rng, [[50, 'intersection'], [80, 'campagne'], [110, 'autoroute'], [130, 'autoroute']]);
    const d2 = distanceIn(v, 2), d1 = distanceIn(v, 1), d4 = distanceIn(v, 4);
    const me = site === 'intersection' ? { id: 'moi', player: true, paint, from: 'S', action: 'straight' } : site === 'campagne' ? { id: 'moi', player: true, paint, action: 'rural-straight' } : { id: 'moi', player: true, paint, action: 'motorway-cruise' };
    const ahead = site === 'campagne' ? lead : site === 'autoroute' ? { id: 'devant', paint: lead.paint, path: [{ x: 6.75, z: 30 }, { x: 6.75, z: -160 }], hold: { x: 6.75, z: -20 } } : { id: 'devant', paint: lead.paint, from: 'S', action: 'straight', holdShift: 14 };
    return base(f, uid, {
      article: 'R412-12', alinea: 'I', situation: `Vous roulez à ${v} km/h derrière un autre véhicule.`, vue: `Vous suivez un véhicule à ${v} km/h.`,
      question: 'La distance de sécurité minimale est d’environ :', ...makeOptions(rng, [`${d2} m`], [`${d1} m`, `${d4} m`]),
      explanation: `La distance de sécurité correspond à au moins deux secondes de trajet. À ${v} km/h, on parcourt environ ${Math.round(v / 3.6)} m par seconde (${v} ÷ 3,6) : deux secondes font donc environ ${d2} m.`,
      scene: { site, layoutOpts: site === 'intersection' ? { theme: 'ville' } : {}, follow: 'moi', vehicles: [me, ahead],
        resolution: [{ sync: true, go: [{ id: 'devant', dist: 50, speed: 12, easing: 'linear' }, { id: 'moi', dist: 50, speed: 12, easing: 'linear' }] }] },
    });
  }
  // distance-poids-lourds
  return base(f, uid, {
    article: 'R412-12', alinea: 'II', situation: 'Hors agglomération, deux camions de plus de 3,5 tonnes se suivent à la même vitesse. Vous roulez derrière eux.',
    vue: 'Route de campagne : deux camions se suivent, votre voiture derrière.',
    question: 'La distance minimale entre les deux camions est de :', ...makeOptions(rng, ['50 mètres'], ['20 mètres', '100 mètres']),
    explanation: 'Hors agglomération, les véhicules de plus de 3,5 tonnes ou de plus de 7 mètres qui se suivent à la même vitesse doivent laisser au moins 50 mètres entre eux. Cela facilite aussi le dépassement par les véhicules plus rapides.',
    scene: { site: 'campagne', camera: { x: 2, z: -18, zoom: 46 }, follow: 'moi',
      vehicles: [{ id: 'moi', player: true, paint, action: 'rural-straight' }, { id: 'camion1', kind: 'camion', path: [{ x: 2, z: 0 }, { x: 2, z: -200 }], hold: { x: 2, z: -62 } }, { id: 'camion2', kind: 'camion', path: [{ x: 2, z: 20 }, { x: 2, z: -200 }], hold: { x: 2, z: -8 } }],
      resolution: [{ sync: true, go: ['camion1', 'camion2', 'moi'].map((id) => ({ id, dist: 50, speed: 12, easing: 'linear' })) }] },
  });
}

// ——————————————————— Éclairage (R416-5 à R416-12) ———————————————————
function genEclairage(rng, uid, f) {
  const paint = playerPaint(rng);
  const me = { id: 'moi', player: true, paint, action: 'rural-straight', lights: 'position' };
  const go = [{ go: [{ id: 'moi', dist: 45, speed: 11 }] }];
  const FEUX_TEXT = { route: 'les feux de route', croisement: 'les feux de croisement' };
  const lightQ = (h, situation, others, extraScene = {}) => base(f, uid, {
    article: h.article, ...(h.alinea ? { alinea: h.alinea } : {}), situation, vue: `De nuit. ${situation}`,
    question: 'Quels feux utilisez-vous ?', ...makeOptions(rng, [FEUX_TEXT[h.feux]], [FEUX_TEXT[h.feux === 'route' ? 'croisement' : 'route'], 'les feux de position seuls']),
    explanation: h.raison,
    scene: { site: 'campagne', weather: 'nuit', camera: { x: 1, z: -2, zoom: 44 }, follow: 'moi', vehicles: [me, ...others],
      resolution: [{ lights: { moi: h.feux } }, { wait: 0.4 }, ...(extraScene.resolution || go)], ...extraScene.scene },
  });
  switch (f.id) {
    case 'nuit-route': return lightQ(headlights({ lieu: 'route-sombre' }), 'Il fait nuit sur une route de campagne sans éclairage. Personne devant vous ni en face.', []);
    case 'nuit-croiser': return lightQ(headlights({ lieu: 'route-sombre', croise: true }), 'Il fait nuit sur une route de campagne sans éclairage. Une voiture arrive en face.',
      [{ id: 'face', paint: pick(rng, COLORS)[0], action: 'rural-oncoming', lights: 'croisement' }],
      { resolution: [{ sync: true, go: [{ id: 'face', dist: 50, speed: 12, easing: 'linear' }, { id: 'moi', dist: 45, speed: 11 }] }] });
    case 'nuit-suivre': return lightQ(headlights({ lieu: 'route-sombre', suit: true }), 'Il fait nuit sur une route de campagne sans éclairage. Vous suivez une voiture à faible distance.',
      [{ id: 'devant', paint: pick(rng, COLORS)[0], action: 'rural-lead', lights: 'croisement', holdShift: -8 }],
      { resolution: [{ sync: true, go: [{ id: 'devant', dist: 50, speed: 12, easing: 'linear' }, { id: 'moi', dist: 50, speed: 12, easing: 'linear' }] }] });
    case 'nuit-agglo': {
      const h = headlights({ lieu: 'agglo-eclairee' });
      const s = 'Il fait nuit. Vous roulez en agglomération, dans une rue bien éclairée par les lampadaires.';
      return base(f, uid, {
        article: h.article, alinea: h.alinea, situation: s, vue: s, question: 'Puis-je rouler en feux de route ?', ...makeOptions(rng, ['Non'], ['Oui'], { fixe: true }),
        explanation: `${h.raison} J’utilise les feux de croisement pour être bien vu sans éblouir.`,
        scene: { site: 'rue', weather: 'nuit', camera: { x: 1, z: 14, zoom: 34 }, follow: 'moi',
          props: [{ type: 'lampadaire', x: -5, z: 30 }, { type: 'lampadaire', x: -5, z: 8 }, { type: 'lampadaire', x: -5, z: -14 }, { type: 'lampadaire', x: 9, z: 18 }],
          vehicles: [{ id: 'moi', player: true, paint, action: 'rue-straight', lights: 'position' }], resolution: [{ lights: { moi: 'croisement' } }, { go: [{ id: 'moi', dist: 40 }] }] },
      });
    }
    case 'brouillard-arriere': case 'pluie-brouillard-arriere': case 'pluie-brouillard-avant': {
      const meteo = f.id === 'brouillard-arriere' ? pick(rng, ['brouillard', 'neige']) : 'forte-pluie';
      const r = fogLights(meteo);
      const avant = f.id === 'pluie-brouillard-avant';
      const allowed = avant ? r.avant : r.arriere;
      const text = { brouillard: 'Un brouillard épais est tombé.', neige: 'La neige tombe abondamment.', 'forte-pluie': 'Il pleut très fort, sans brouillard.' }[meteo];
      const s = `${text} Vous roulez sur une route de campagne.`;
      return base(f, uid, {
        article: r.article, alinea: avant ? 'I' : 'II', situation: s, vue: s,
        question: `Puis-je allumer mes feux de brouillard ${avant ? 'avant' : 'arrière'} ?`, ...makeOptions(rng, [allowed ? 'Oui' : 'Non'], [allowed ? 'Non' : 'Oui'], { fixe: true }),
        explanation: 'Les feux de brouillard avant peuvent remplacer ou compléter les feux de croisement en cas de brouillard, de chute de neige ou de forte pluie. Les feux de brouillard arrière, très éblouissants, ne sont permis qu’en cas de brouillard ou de chute de neige — jamais sous la seule pluie.',
        scene: { site: 'campagne', weather: meteo === 'forte-pluie' ? 'pluie' : meteo, camera: { x: 1, z: 0, zoom: 36 }, follow: 'moi',
          vehicles: [{ id: 'moi', player: true, paint, action: 'rural-straight', lights: 'croisement' }],
          resolution: [{ lights: { moi: allowed ? 'brouillard' : 'croisement' } }, { go: [{ id: 'moi', dist: 40 }] }] },
      });
    }
    case 'nuit-stationnement': {
      const s = 'Il fait nuit. Vous êtes arrêté sur le bord de la chaussée d’une route de campagne sans éclairage.';
      return base(f, uid, {
        article: 'R416-12', alinea: 'I', situation: s, vue: s, question: 'Quels feux laissez-vous allumés ?',
        ...makeOptions(rng, ['les feux de position (et les feux rouges arrière)'], ['les feux de route, pour être mieux vu', 'aucun feu : la route est déserte']),
        explanation: 'À l’arrêt ou en stationnement sur la chaussée la nuit, le véhicule est signalé par ses feux de position à l’avant et ses feux rouges arrière (avec l’éclairage de la plaque). Les feux de route sont interdits à l’arrêt (article R416-5).',
        scene: { site: 'campagne', weather: 'nuit', camera: { x: 3, z: -6, zoom: 30 },
          vehicles: [{ id: 'moi', player: true, paint, action: 'rural-breakdown', lights: null }, { id: 'passe', paint: pick(rng, COLORS)[0], action: 'rural-oncoming', lights: 'croisement' }],
          resolution: [{ lights: { moi: 'position' } }, { go: [{ id: 'passe', dist: 60, speed: 12, easing: 'linear' }] }] },
      });
    }
    default: throw new Error(f.id);
  }
}

// ——————————————————— Passage à niveau ———————————————————
function genPassageNiveau(rng, uid, f) {
  const paint = playerPaint(rng);
  const me = { id: 'moi', player: true, paint, action: 'pn-approach' };
  const train = { id: 'train', kind: 'train', path: [{ x: -150, z: -20 }, { x: 150, z: -20 }], hold: { x: -110, z: -20 } };
  const passage = [{ pn: 'ferme' }, { wait: 0.6 }, { go: [{ id: 'train', dist: 230, speed: 30, easing: 'linear' }] }, { wait: 0.4 }, { pn: 'ouvert' }, { wait: 0.4 }, { go: [{ id: 'moi', dist: 50 }] }];
  const scene = (extra) => ({ site: 'campagne', weather: pick(rng, ['beau', 'beau', 'pluie', 'nuit']), camera: { x: 1, z: -14, zoom: 42 }, ...extra });
  if (f.id === 'pn-feux') {
    return base(f, uid, {
      article: 'R412-30', situation: 'Les feux rouges clignotent au passage à niveau. Les demi-barrières sont encore levées.', vue: 'Passage à niveau, feux rouges clignotants, demi-barrières levées.',
      question: 'Que faites-vous ?', ...makeOptions(rng, ['je m’arrête avant le passage à niveau'], ['je passe vite avant que les barrières se baissent', 'je ralentis et je passe si je ne vois pas de train']),
      explanation: 'Le feu rouge clignotant impose l’arrêt absolu, comme le feu rouge fixe. Au passage à niveau, il annonce l’arrivée d’un train : les barrières vont se baisser.',
      scene: scene({ props: [{ type: 'pn', z: -20, state: 'ouvert', feux: true }], vehicles: [me, train], resolution: passage }),
    });
  }
  if (f.id === 'pn-barrieres') {
    return base(f, uid, {
      article: 'R422-3', alinea: 'II', situation: 'À l’approche du passage à niveau, les demi-barrières commencent à se baisser.', vue: 'Passage à niveau, demi-barrières en train de se baisser.',
      question: 'Je peux m’engager sur la voie ferrée :', ...makeOptions(rng, ['non, j’attends'], ['oui, en accélérant', 'oui, en contournant la demi-barrière']),
      explanation: 'Aucun usager ne doit s’engager sur un passage à niveau quand les barrières ou demi-barrières sont fermées, en cours de fermeture ou d’ouverture.',
      scene: scene({ props: [{ type: 'pn', z: -20, state: 'fermeture', feux: true }], vehicles: [me, train], resolution: passage }),
    });
  }
  // pn-file : la file de l'autre côté risque d'immobiliser le joueur sur les voies
  const queue = [-29, -35, -41].map((z, i) => ({ id: `file${i}`, paint: pick(rng, COLORS)[0], path: [{ x: 2, z: z + 5 }, { x: 2, z: -180 }], hold: { x: 2, z } }));
  return base(f, uid, {
    article: 'R422-3', alinea: 'II', situation: 'Les barrières sont levées et aucun feu ne clignote. Mais juste après la voie ferrée, une file de voitures est arrêtée.', vue: 'Passage à niveau ouvert, file de voitures arrêtée juste après les rails.',
    question: 'Je m’engage sur le passage à niveau ?', ...makeOptions(rng, ['Non'], ['Oui'], { fixe: true }),
    explanation: 'Aucun conducteur ne doit s’engager sur un passage à niveau si son véhicule risque d’y être immobilisé, notamment à cause de la circulation. J’attends que la place soit libre après les rails.',
    scene: scene({ props: [{ type: 'pn', z: -20, state: 'ouvert', feux: false }], vehicles: [me, ...queue],
      resolution: [{ wait: 0.6 }, { sync: true, go: queue.map((q) => ({ id: q.id, dist: 20, speed: 5, easing: 'inOutCubic' })) }, { go: [{ id: 'moi', dist: 40 }] }] }),
  });
}

// ——————————————————— Fiches de connaissances ———————————————————
// Position des pièces sous le capot (repère de la voiture, avant vers +Z) — cf. src/scene/vehicles.js
export const PIECE_POS = { batterie: { x: 0.62, z: 0.95 }, huile: { x: 0.1, z: 1.45 }, refroidissement: { x: -0.62, z: 1.0 }, 'lave-glace': { x: -0.62, z: 1.75 } };
/** Voiture vue de près au parking, avant tourné vers la caméra (cap sud-est). Repère voiture → monde : rotation de π/4. */
const ATELIER_ANGLE = Math.PI / 4;      // avant tourné vers la caméra
const PROFIL_ANGLE = (3 * Math.PI) / 4;  // flanc droit tourné vers la caméra (pneus)
const carToWorld = (p, a = ATELIER_ANGLE) => ({ x: p.x * Math.cos(a) + p.z * Math.sin(a), z: -p.x * Math.sin(a) + p.z * Math.cos(a) });
function sceneFromRecipe(rng, r) {
  const paint = playerPaint(rng);
  const me = { id: 'moi', player: true, paint };
  const weather = r.meteo || (r.nuit ? 'nuit' : 'beau');
  switch (r.recette) {
    case 'atelier': {
      const pneus = r.piece === 'pneus';
      return {
        site: 'parking', weather: 'beau', layoutOpts: {},
        camera: pneus ? { ...carToWorld({ x: -0.9, z: 0.6 }, PROFIL_ANGLE), zoom: 6.5 } : r.capot ? { ...carToWorld({ x: 0, z: 1.2 }), zoom: 7 } : { x: 0.3, z: 0.3, zoom: 10 },
        // Étiquettes étagées en hauteur pour ne jamais se chevaucher à l'écran
        labels: (r.etiquettes || []).map((k, i) => ({ id: LETTERS[i], ...carToWorld(PIECE_POS[k]), y: 1.2 + i * 0.42, scale: 0.26 })),
        vehicles: [{ ...me, at: { x: 0, z: 0, angle: pneus ? PROFIL_ANGLE : ATELIER_ANGLE }, capot: !!r.capot, highlight: r.piece || null }],
        resolution: [{ wait: 0.6 }],
      };
    }
    case 'stationne': {
      const cyc = r.cycliste ? [{ id: 'velo', kind: 'velo', action: 'rue-velo-voie' }] : [];
      return { site: 'rue', weather, camera: { x: 3, z: 40, zoom: 24 }, vehicles: [{ ...me, action: 'rue-gare' }, ...cyc],
        resolution: cyc.length ? [{ go: [{ id: 'velo', dist: 40, speed: 4.5, easing: 'linear' }] }] : [{ wait: 0.6 }] };
    }
    case 'panne': {
      // Avec triangle : voiture immobilisée en partie sur la chaussée, triangle posé loin en amont
      const props = r.triangle ? [{ type: 'triangle', x: 3.3, z: 20 }] : [];
      return { site: 'campagne', weather, camera: r.triangle ? { x: 3, z: 6, zoom: 36 } : { x: 3, z: 2, zoom: 30 }, props,
        vehicles: [{ ...me, action: r.triangle || r.surChaussee ? 'rural-breakdown' : 'rural-shoulder', hazard: true }, { id: 'passe', paint: pick(rng, COLORS)[0], ...(r.triangle || r.surChaussee ? { action: 'rural-oncoming' } : { action: 'rural-straight', holdShift: -20 }) }],
        resolution: [{ go: [{ id: 'passe', dist: 60, speed: 10 }] }] };
    }
    case 'accident': {
      const crashed = [{ id: 'epave', paint: pick(rng, COLORS)[0], at: { x: 5.6, z: -8, angle: Math.PI + 1.1, tilt: 0.16 }, hazard: true }];
      if (r.moto) crashed.push({ id: 'motoTombee', kind: 'moto', at: { x: -1.2, z: -13, angle: 1.2 }, tombe: true }, { id: 'motard', kind: 'pieton', at: { x: 1.4, z: -15.5, angle: 0.4 }, couche: true, casque: true });
      return { site: 'campagne', weather, camera: { x: 2.5, z: -12, zoom: 30 }, props: [{ type: 'triangle', x: 3.4, z: 26 }],
        vehicles: [{ ...me, path: [{ x: 2, z: 30 }, { x: 2, z: -18 }, { x: 5.6, z: -26, ctrl: { x: 2, z: -24 } }, { x: 5.6, z: -30 }], hold: { x: 5.6, z: -29 }, hazard: true }, ...crashed],
        resolution: [{ wait: 0.6 }] };
    }
    case 'feu-rouge': {
      const meFrom = pick(rng, ARMS);
      return { site: 'intersection', layoutOpts: { theme: 'ville', camera: vueOf(rng) }, weather, props: lightsProps(meFrom, 'rouge').props, camera: camFor(meFrom, 36),
        vehicles: [{ ...me, from: meFrom, action: 'straight' }], resolution: [{ wait: 1 }, setAxis(meFrom, 'vert', 'rouge'), { go: ['moi'] }] };
    }
    default: { // 'trajet' : ambiance de conduite sur un site tiré au hasard
      const site = r.site || pick(rng, ['campagne', 'autoroute', 'rue', 'intersection']);
      const extra = { lights: r.feux || undefined, coffre: !!r.coffre, hazard: !!r.detresse };
      const arm = pick(rng, ARMS);
      const v = site === 'campagne' ? { action: 'rural-straight' } : site === 'autoroute' ? { action: r.voie === 'gauche' ? 'motorway-left' : 'motorway-cruise' }
        : site === 'rue' ? { action: 'rue-straight' } : { from: arm, action: 'straight' };
      const traffic = [];
      if (r.cycliste && site === 'rue') traffic.push({ id: 'velo', kind: 'velo', path: [{ x: RUE.pisteX, z: 50 }, { x: RUE.pisteX, z: -50 }], hold: { x: RUE.pisteX, z: 10 } });
      else if (site === 'autoroute' && rng() < 0.7) traffic.push({ id: 'camion', kind: 'camion', path: [{ x: 6.75, z: 20 }, { x: 6.75, z: -160 }], hold: { x: 6.75, z: -16 } });
      else if (site === 'campagne' && rng() < 0.5) traffic.push({ id: 'face', paint: pick(rng, COLORS)[0], action: 'rural-oncoming', lights: weather === 'nuit' ? 'croisement' : undefined });
      return {
        site, weather, layoutOpts: site === 'intersection' ? { theme: pick(rng, ['ville', 'campagne']), camera: vueOf(rng) } : {}, follow: 'moi',
        ...(site === 'intersection' ? { camera: camFor(arm) } : {}),
        props: weather === 'nuit' && site === 'intersection' ? CORNER_LAMPS : [],
        vehicles: [{ ...me, ...v, ...extra }, ...traffic],
        resolution: [{ sync: true, go: [{ id: 'moi', dist: 40, speed: site === 'autoroute' ? 15 : 9 }, ...traffic.map((t) => ({ id: t.id, dist: 40, speed: t.kind === 'velo' ? 4 : 11, easing: 'linear' }))] }],
      };
    }
  }
}
function genFiche(rng, uid, f) {
  const fiche = f.fiche;
  const v = pick(rng, fiche.variantes);
  let opt;
  if (v.cible) {
    // Question de repérage : les options sont les pièces étiquetées dans la scène
    const keys = fiche.scene.etiquettes;
    opt = { options: keys.map((k, i) => ({ id: LETTERS[i], text: `${cap(PIECES[k])} (${LETTERS[i]})` })), correct: [LETTERS[keys.indexOf(v.cible)]] };
  } else opt = makeOptions(rng, v.ok, v.ko, { fixe: v.fixe });
  const scene = sceneFromRecipe(rng, fiche.scene);
  return base(f, uid, {
    ...(fiche.article ? { article: fiche.article } : { reference: fiche.reference }),
    ...(fiche.alinea ? { alinea: fiche.alinea } : {}),
    ...(fiche.source ? { source: fiche.source } : {}),
    ...(fiche.image ? { voyant: fiche.image.voyant } : {}),
    situation: v.s, vue: `${v.s} ${scene.site === 'parking' ? 'Voiture vue de près sur un parking.' : ''}`.trim(),
    question: v.q, ...opt, explanation: v.e, scene,
  });
}

// ——————————————————— Catalogue des notions ———————————————————
const CATALOGUE = [];
function add(famille, domaine, ids, make, extra = {}) { for (const id of ids) CATALOGUE.push({ id, famille, domaine, make, chapitre: extra.chapitre || domaine, ...extra }); }
add('priorite', 'circulation', Object.keys(PRIO), genPriorite, { theme: 'priorites', chapitre: 'priorites' });
add('giratoire', 'circulation', ['giratoire'], genGiratoire, { theme: 'priorites', chapitre: 'priorites' });
add('prioritaire', 'usagers', ['vehicule-prioritaire'], genPrioritaire);
add('debouche', 'vehicule', ['sortie-parking'], genDebouche);
add('feux', 'circulation', ['feu-rouge', 'feu-jaune', 'feu-jaune-tard', 'feu-clignotant', 'feu-vert-encombre', 'feu-vert-gauche'], genFeux, { chapitre: 'feux' });
add('feux', 'usagers', ['feu-vert-pietons'], genFeux);
add('pieton', 'usagers', ['pieton-engage', 'pieton-intention'], genPieton);
add('velo', 'usagers', ['velo-ecart-agglo', 'velo-ecart-route'], genVeloEcart);
add('vitesse', 'circulation', ['vitesse-agglo', 'vitesse-route', 'vitesse-2ch', 'vitesse-autoroute', 'vitesse-probatoire-autoroute', 'vitesse-probatoire-2ch'], genVitesse, { chapitre: 'vitesse' });
add('vitesse', 'route', ['vitesse-pluie-autoroute', 'vitesse-pluie-2ch', 'vitesse-brouillard'], genVitesse, { chapitre: 'nuit-meteo' });
for (const sg of SIGNS) add('panneau', 'circulation', [`panneau-${sg.code}`], genPanneau, { code: sg.code, theme: 'signalisation', chapitre: SIGN_CHAPTER[sg.famille] });
for (const ch of new Set(Object.values(SIGN_CHAPTER))) add('panneau-image', 'circulation', [`reconnaitre-${ch}`, `reconnaitre-${ch}-2`], genPanneauImage, { theme: 'signalisation', chapitre: ch });
for (const fam of FORMES) add('panneau-forme', 'circulation', [`forme-${fam}`], genForme, { fam, theme: 'signalisation', chapitre: SIGN_CHAPTER[fam] });
for (const [id, sit] of Object.entries(SITUATIONS)) add('panneau-situation', 'circulation', [id], genSituationPanneau, { theme: 'signalisation', chapitre: sit.chapitre });
add('depassement', 'circulation', Object.keys(DEPASSEMENT), genDepassement, { chapitre: 'depassement' });
add('stationnement', 'circulation', ['stationnement-permis', 'stationnement-interdit'], genStationnement, { chapitre: 'stationnement' });
add('distance', 'conducteur', ['distance-2s', 'distance-calcul'], genDistance);
add('distance', 'route', ['distance-poids-lourds'], genDistance, { chapitre: 'route-divers' });
add('eclairage', 'route', ['nuit-route', 'nuit-croiser', 'nuit-suivre', 'nuit-agglo', 'brouillard-arriere', 'pluie-brouillard-arriere', 'pluie-brouillard-avant', 'nuit-stationnement'], genEclairage, { chapitre: 'nuit-meteo' });
add('passage-niveau', 'route', ['pn-feux', 'pn-barrieres', 'pn-file'], genPassageNiveau, { chapitre: 'passage-niveau' });
const FICHE_CHAPTER = { 'depasser-droite': 'depassement', 'autoroute-marche-arriere': 'autoroute', 'autoroute-bau': 'autoroute', 'autoroute-gauche-80': 'autoroute', 'autoroute-sortie': 'autoroute', 'virage-depassement': 'route-divers', 'montagne-croisement': 'route-divers' };
for (const fiche of FICHES) add(`fiche-${fiche.domaine}`, fiche.domaine, [fiche.notion], genFiche, { fiche, chapitre: FICHE_CHAPTER[fiche.notion] || fiche.domaine });

/** Catalogue public (sans les fonctions de fabrication) : notion, thème officiel, famille. */
export const NOTIONS = CATALOGUE.map(({ id, domaine, famille, chapitre }) => ({ id, domaine, famille, chapitre }));
const BY_ID = new Map(CATALOGUE.map((c) => [c.id, c]));

// ——— Vue conseillée : à la place du conducteur quand la situation se lit devant soi ———
const DRIVER_FAMILIES = new Set(['panneau', 'panneau-forme', 'feux', 'pieton', 'passage-niveau', 'eclairage', 'distance', 'depassement', 'vitesse', 'velo']);
const DRIVER_SITUATIONS = new Set(['sit-tourner-gauche', 'sit-direction-droite', 'sit-stop-vide', 'sit-arret-depose', 'sit-interdiction-depasser', 'sit-entree-agglo', 'sit-sens-inverse', 'sit-zone-rencontre', 'sit-zone-30']);
const TAN_MAX = Math.tan((16 * Math.PI) / 180); // le panneau doit être dans le champ de vision, à moins de 16° de l'axe
/**
 * Recule le point d'arrêt du joueur pour que les panneaux posés au bord de la route soient devant lui,
 * dans le champ de vision du conducteur. Renvoie false si ce n'est pas possible.
 */
function frameSignsForDriver(scene) {
  const me = scene.vehicles.find((v) => v.player);
  // Panneaux posés par coordonnées, ou au coin d'arrivée d'un carrefour (même ancrage que src/scene/world.js)
  const signs = (scene.signs || []).map((x) => (x.x !== undefined ? x : scene.site === 'intersection' && x.approach ? rotateQuarter({ x: 5.2, z: 6.2 }, QUARTER_OF[x.approach]) : null)).filter(Boolean);
  if (!signs.length) return true;
  const route = routeFor(me, scene.site);
  for (let shift = 0; shift >= -45; shift -= 1) {
    const s = route.hold + shift;
    if (s < 4) break;
    const p = pointAt(route, s), f = { x: Math.sin(p.angle), z: Math.cos(p.angle) };
    const ok = signs.every((sg) => {
      const w = toWorld(scene.site, sg); const d = { x: w.x - p.x, z: w.z - p.z };
      const ahead = d.x * f.x + d.z * f.z, lateral = Math.abs(d.x * f.z - d.z * f.x);
      return ahead > 8 && ahead < 45 && lateral / ahead < TAN_MAX;
    });
    if (ok) { if (shift) me.holdShift = (me.holdShift || 0) + shift; return true; }
  }
  return false;
}
function adviseView(q, f, rng) {
  const sc = q.scene;
  if (sc.vue || !sc.vehicles?.some((v) => v.player && !v.at)) return q;
  let driver = DRIVER_FAMILIES.has(f.famille) || DRIVER_SITUATIONS.has(f.id)
    || (f.famille.startsWith('fiche-') && f.fiche.scene.recette === 'trajet' && rng() < 0.6);
  // Panneaux : le joueur s'arrête assez loin pour avoir le panneau devant lui (sauf s'il vient volontairement de le dépasser)
  if (driver && (f.famille === 'panneau' || f.famille === 'panneau-forme' || (DRIVER_SITUATIONS.has(f.id) && f.id !== 'sit-interdiction-depasser'))) driver = frameSignsForDriver(sc);
  if (driver) sc.vue = 'conducteur';
  return q;
}

/** Fabrique une question pour une notion donnée. */
export function makeQuestion(notionId, rng, uid = notionId) {
  const f = BY_ID.get(notionId);
  if (!f) throw new Error(`Notion inconnue : ${notionId}`);
  return adviseView(f.make(rng, uid, f), f, rng);
}

/**
 * Tire une série de `count` questions (reproductible avec la même graine et le même historique).
 * history : notions vues lors des séries précédentes (de la plus ancienne à la plus récente).
 */
export function generateQuestions(count, seed = Date.now() % 2147483647, { history = [], domaines, chapitres } = {}) {
  const rng = createRng(seed);
  const pool = chapitres ? NOTIONS.filter((n) => chapitres.includes(n.chapitre)) : NOTIONS;
  const plan = planSession(pool, count, rng, { history, ...(domaines ? { domaines } : {}) });
  return plan.map((n, i) => makeQuestion(n.id, rng, `${seed}-${i}`));
}
