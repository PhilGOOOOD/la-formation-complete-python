// Composition d'une série sans redondance — logique pure, testable sous Node.
// Règles :
//  1. une notion n'apparaît qu'une fois par série (tant que le catalogue n'est pas épuisé) ;
//  2. les thèmes officiels sont servis à tour de rôle, pour couvrir tout le programme ;
//  3. une même famille de mise en scène (priorités, feux…) est plafonnée dans la série ;
//  4. les notions vues lors des séries précédentes (historique) passent après les notions jamais vues ;
//  5. deux questions qui se suivent n'ont ni le même thème ni la même famille, quand c'est possible.
import { DOMAIN_IDS } from '../data/domains.js';

/** Poids des thèmes : la circulation (signalisation, priorités, vitesses…) pèse le plus lourd dans le programme. */
export const WEIGHTS = { circulation: 2, route: 1.5, usagers: 1.5 };

function shuffled(list, rng) {
  const a = list.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

/**
 * Choisit `count` entrées du catalogue.
 * @param {Array<{id:string, domaine:string, famille:string}>} catalogue
 * @param {number} count
 * @param {() => number} rng
 * @param {{history?: string[], domaines?: string[]}} options  history : identifiants de notions déjà vues, du plus ancien au plus récent
 */
export function planSession(catalogue, count, rng, { history = [], domaines = DOMAIN_IDS } = {}) {
  const pool = catalogue.filter((n) => domaines.includes(n.domaine));
  if (!pool.length) throw new Error('Aucune notion disponible pour ces thèmes');
  // Ancienneté : -1 = jamais vue ; sinon rang de la dernière apparition (plus grand = plus récent)
  const lastSeen = new Map();
  history.forEach((id, i) => lastSeen.set(id, i));
  const recency = (n) => (lastSeen.has(n.id) ? lastSeen.get(n.id) : -1);
  const familyCap = Math.max(1, Math.ceil(count / 8));

  const chosen = [];
  let used = new Set();
  const familyCount = new Map();
  // Tourniquet pondéré (lisse) : chaque thème revient selon son poids, dans un ordre de départ tiré au hasard
  const order = shuffled(domaines.filter((d) => pool.some((n) => n.domaine === d)), rng);
  const credit = new Map(order.map((d) => [d, 0]));
  const weight = (d) => WEIGHTS[d] || 1;
  const totalWeight = order.reduce((s, d) => s + weight(d), 0);
  let relax = false;
  let blocked = new Set();
  while (chosen.length < count) {
    const open = order.filter((d) => !blocked.has(d));
    if (!open.length) {
      // Plus rien de possible : on lève le plafond par famille, puis on autorise une nouvelle ronde
      if (!relax) relax = true; else used = new Set();
      blocked = new Set();
      continue;
    }
    for (const d of open) credit.set(d, credit.get(d) + weight(d));
    const domain = open.reduce((a, b) => (credit.get(b) > credit.get(a) ? b : a));
    credit.set(domain, credit.get(domain) - totalWeight);
    const candidates = pool.filter((n) => n.domaine === domain && !used.has(n.id)
      && (relax || (familyCount.get(n.famille) || 0) < familyCap));
    if (!candidates.length) { blocked.add(domain); continue; }
    // Les moins récemment vues d'abord ; tirage au hasard parmi les ex æquo (ou les trois plus anciennes)
    const sorted = shuffled(candidates, rng).sort((a, b) => recency(a) - recency(b));
    const best = recency(sorted[0]);
    const top = best === -1 ? sorted.filter((n) => recency(n) === -1) : sorted.slice(0, 3);
    const pickN = top[Math.floor(rng() * top.length)];
    chosen.push(pickN);
    used.add(pickN.id);
    familyCount.set(pickN.famille, (familyCount.get(pickN.famille) || 0) + 1);
  }
  return spread(shuffled(chosen, rng));
}

/** Réordonne pour éviter deux questions consécutives du même thème ou de la même famille. */
export function spread(list) {
  const out = list.slice();
  const clash = (a, b) => a && b && (a.domaine === b.domaine || a.famille === b.famille);
  const total = () => out.reduce((s, x, k) => s + (k && clash(out[k - 1], x) ? 1 : 0), 0);
  for (let pass = 0; pass < 4; pass++) {
    for (let i = 1; i < out.length; i++) {
      if (!clash(out[i - 1], out[i])) continue;
      const before = total();
      for (let j = 0; j < out.length; j++) {
        if (j === i) continue;
        [out[i], out[j]] = [out[j], out[i]];
        if (total() < before) break;
        [out[i], out[j]] = [out[j], out[i]]; // pas mieux : on annule
      }
    }
  }
  return out;
}
