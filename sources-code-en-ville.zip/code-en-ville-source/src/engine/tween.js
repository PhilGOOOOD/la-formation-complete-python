// Mini moteur d'animation (motion design) piloté par la boucle de rendu.
// Le temps est injecté, ce qui permet d'accélérer ou de figer l'animation dans les tests.

export const ease = {
  linear: (t) => t,
  inOutCubic: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  outCubic: (t) => 1 - Math.pow(1 - t, 3),
  inCubic: (t) => t * t * t,
  inQuad: (t) => t * t,
  outQuart: (t) => 1 - Math.pow(1 - t, 4),
  outBack: (t) => { const c1 = 1.4, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
};

export function createTimeline() {
  const active = new Set();
  let timeScale = 1;

  function tween({ duration = 1, delay = 0, easing = ease.inOutCubic, onUpdate, onDone }) {
    return new Promise((resolve) => {
      const job = { t: -delay, duration: Math.max(duration, 1e-4), easing, onUpdate, done: false,
        finish() { if (job.done) return; job.done = true; active.delete(job); onUpdate?.(1, 1); onDone?.(); resolve(); } };
      active.add(job);
      if (duration <= 0 && delay <= 0) job.finish();
    });
  }

  const wait = (seconds) => tween({ duration: seconds, easing: ease.linear });

  function update(dt) {
    const step = dt * timeScale;
    for (const job of Array.from(active)) {
      job.t += step;
      if (job.t < 0) continue;
      const raw = Math.min(job.t / job.duration, 1);
      job.onUpdate?.(job.easing(raw), raw);
      if (raw >= 1) job.finish();
    }
  }

  return {
    tween, wait, update,
    /** Termine immédiatement toutes les animations en cours (bouton « passer », tests). */
    finishAll() { for (const job of Array.from(active)) job.finish(); },
    get busy() { return active.size > 0; },
    get timeScale() { return timeScale; },
    set timeScale(v) { timeScale = Math.max(0, v); },
  };
}
