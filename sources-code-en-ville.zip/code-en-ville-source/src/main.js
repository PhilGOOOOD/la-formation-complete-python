// Orchestration du jeu : boucle de rendu, déroulé des questions, clavier, chrono.
import { QUESTIONS } from './data/questions.js';
import { createSession, questionsFor } from './engine/quiz.js';
import { generateQuestions, makeQuestion, NOTIONS } from './engine/generator.js';
import { CHAPITRES, chapitreLabel } from './data/chapters.js';
import { DOMAINS, domainLabel } from './data/domains.js';
import { createRng } from './engine/quiz.js';
import { signImage } from './scene/signs.js';
import { voyantImage, VOYANTS } from './scene/dashboard.js';
import { SIGNS } from './data/signs-catalog.js';
import { createTimeline } from './engine/tween.js';
import { createWorld } from './scene/world.js';
import { createDirector } from './scene/director.js';
import { createSfx } from './audio/sfx.js';
import { createUI } from './ui/ui.js';
import { createCockpit } from './ui/cockpit.js';
import { loadPhotos } from './scene/photos.js';

const TIME_LIMIT = 20; // secondes par question, comme à l'examen

// Les textures photographiques sont décodées avant de construire le moindre décor (sinon : textures dessinées)
await loadPhotos();
const canvas = document.getElementById('scene');
const ui = createUI();
const sfx = createSfx();
const timeline = createTimeline();
const world = createWorld(canvas);
const director = createDirector(world, timeline, sfx);
const cockpit = createCockpit(world);

const state = {
  phase: 'intro', // intro | observe | question | feedback | end
  session: null,
  selected: new Set(),
  timed: true,
  exactCount: false,
  questions: QUESTIONS,
  timeLeft: TIME_LIMIT,
  lastRecord: null,
  busy: false,
  vuePref: null, // vue choisie par le joueur (bouton « Vue conducteur ») ; null : vue conseillée par chaque scène
};

// ——— Boucle de rendu (l'image n'est redessinée que si quelque chose bouge) ———
let last = performance.now();
let frames = 0, renders = 0;
// Qualité adaptative : si l'animation descend sous ~28 images/s, on allège le rendu.
const perf = { time: 0, count: 0 };
const LADDER = ['haute', 'moyenne', 'basse'];
const fixedQuality = Boolean(window.__QUALITE); // qualité imposée (tests) : pas d'adaptation
function adapt(realDt, rendered) {
  if (fixedQuality || !timeline.busy) { perf.time = 0; perf.count = 0; return; }
  perf.time += realDt; if (rendered) perf.count++;
  if (perf.time >= 2) {
    const fps = perf.count / perf.time;
    const i = LADDER.indexOf(world.quality);
    if (fps < 28 && i < LADDER.length - 1) world.setQuality(LADDER[i + 1]);
    perf.time = 0; perf.count = 0;
  }
}
function loop(now) {
  const realDt = (now - last) / 1000;
  const dt = Math.min(realDt, 0.1); // évite un saut d'animation après un onglet en arrière-plan
  last = now;
  timeline.update(dt);
  director.tick(dt * timeline.timeScale);
  world.update(dt);
  if (state.phase === 'question' && state.timed) tickTimer(dt * timeline.timeScale);
  const rendered = world.renderIfNeeded();
  if (rendered) renders++;
  adapt(Math.min(realDt, 1), rendered);
  frames++;
  requestAnimationFrame(loop);
}
window.addEventListener('resize', world.resize);
world.resize();
director.moveCamera('accueil', 0);
director.prepareHome();
requestAnimationFrame(loop);

// ——— Cadrage : la cible de la caméra évite la zone couverte par la carte de question ———
function frameFor(phase) {
  const wide = window.innerWidth > 640;
  if (phase === 'intro' || phase === 'end') world.view.focus = { x: 0.5, y: 0.5 };
  else world.view.focus = wide ? { x: 0.64, y: 0.52 } : { x: 0.5, y: 0.3 };
  world.resize();
  cockpit.draw();
}
/** Bouton de vue : visible pendant une situation où l'on peut prendre la place du conducteur. */
function updateViewButton() {
  const b = document.getElementById('btn-vue');
  const active = ['observe', 'question', 'feedback'].includes(state.phase) && director.canDrive;
  b.hidden = !active;
  const driver = director.view === 'conducteur';
  b.setAttribute('aria-pressed', String(driver));
  b.querySelector('.etat').textContent = driver ? 'Vue du dessus' : 'Vue conducteur';
  canvas.setAttribute('aria-label', `${driver ? 'Vue à la place du conducteur, avec rétroviseur. ' : ''}${state.session?.current?.vue || 'Vue isométrique de la situation'}`);
  cockpit.draw();
}
function toggleView() {
  if (!director.canDrive || !['observe', 'question', 'feedback'].includes(state.phase)) return;
  state.vuePref = director.view === 'conducteur' ? 'iso' : 'conducteur';
  director.setView(state.vuePref);
  sfx.ui();
  updateViewButton();
}
document.getElementById('btn-vue').addEventListener('click', toggleView);
window.addEventListener('resize', () => frameFor(state.phase));

// ——— Historique des notions vues (navigateur seulement ; sert à varier les séries suivantes) ———
const HISTORY_KEY = 'code-en-ville:notions';
function loadHistory() {
  try { const h = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); return Array.isArray(h) ? h.filter((x) => typeof x === 'string') : []; } catch { return []; }
}
function remember(notion) {
  if (!notion) return;
  try {
    const h = loadHistory().filter((x) => x !== notion);
    h.push(notion);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(h.slice(-400)));
  } catch { /* stockage indisponible : la série reste sans redondance, seule la mémoire entre séries est perdue */ }
}

// ——— Déroulé ———
async function startGame() {
  sfx.unlock(); sfx.ui();
  state.vuePref = null;
  state.timed = document.getElementById('opt-chrono').checked;
  state.exactCount = document.getElementById('opt-aide').checked;
  const chapter = document.querySelector('input[name="chapitre"]:checked')?.value || 'tout';
  const seed = Math.floor(Math.random() * 2147483646) + 1;
  if (chapter === 'aleatoire') {
    // Examen blanc : tirage sur les 10 thèmes, les kits fournissent décor, véhicules et panneaux, le moteur de règles la réponse
    const count = Number(document.getElementById('opt-nombre').value) || 20;
    state.questions = generateQuestions(count, seed, { history: loadHistory() });
    state.titre = 'Bilan de l’examen blanc';
  } else if (chapter === 'revision') {
    // Révision ciblée : un thème entier ou un de ses chapitres
    const { chapitres, label } = revisionTarget(document.getElementById('opt-chapitre').value);
    const pool = NOTIONS.filter((n) => chapitres.includes(n.chapitre)).length;
    const asked = document.getElementById('opt-nombre-revision').value;
    const count = asked === 'tout' ? Math.min(pool, 60) : Number(asked);
    state.questions = generateQuestions(count, seed, { history: loadHistory(), chapitres });
    state.titre = `Bilan de la révision : ${label}`;
  } else { state.questions = questionsFor(QUESTIONS, chapter); state.titre = 'Bilan du parcours guidé'; }
  state.session = createSession(state.questions);
  await showQuestion();
}

async function showQuestion() {
  const s = state.session;
  const q = s.current;
  state.selected = new Set();
  state.phase = 'observe';
  frameFor('observe');
  ui.show('observe');
  ui.renderProgress(s.total, s.index, s.answers);
  ui.renderObserve(q, s.index, s.total);
  ui.setTimer(1, false);
  ui.el.skip.hidden = false;
  const ready = director.setup(q.scene, { vue: state.vuePref });
  updateViewButton();
  await ready;
  ui.el.skip.hidden = true;
  if (state.phase !== 'observe') return;
  state.phase = 'question';
  state.timeLeft = TIME_LIMIT;
  if (q.signCode && !q.signImage) q.signImage = signImage(q.signCode); // dessinée au moment de l'afficher
  if (q.voyant && !q.voyantImage) { q.voyantImage = voyantImage(q.voyant); q.voyantDesc = VOYANTS[q.voyant].desc; }
  for (const o of q.options) if (o.signCode && !o.image) o.image = signImage(o.signCode);
  ui.renderQuestion(q, s.index, s.total, state.selected, toggleOption, validate, { exactCount: state.exactCount });
  ui.setTimer(1, state.timed);
  ui.announce(`${q.situation} ${q.question}`);
  updateViewButton();
  document.getElementById('opt-' + q.options[0].id)?.focus({ preventScroll: true });
}

function toggleOption(id) {
  if (state.phase !== 'question') return;
  state.selected.has(id) ? state.selected.delete(id) : state.selected.add(id);
  sfx.select();
  ui.updateSelection(state.selected);
}

let lastSecond = TIME_LIMIT;
function tickTimer(dt) {
  state.timeLeft -= dt;
  ui.setTimer(state.timeLeft / TIME_LIMIT, true);
  const sec = Math.ceil(state.timeLeft);
  if (sec !== lastSecond && sec <= 5 && sec > 0) sfx.tick();
  lastSecond = sec;
  if (state.timeLeft <= 0) validate({ timedOut: true });
}

async function validate({ timedOut = false } = {}) {
  if (state.phase !== 'question') return;
  if (!timedOut && state.selected.size === 0) return;
  const s = state.session;
  const q = s.current;
  const index = s.index;
  const record = s.answer([...state.selected], { timedOut });
  state.lastRecord = record;
  remember(q.notion);
  state.phase = 'feedback';
  ui.setTimer(0, false);
  record.correct ? sfx.correct() : sfx.wrong();
  ui.renderProgress(s.total, s.index, s.answers);
  ui.renderFeedback(q, record, index, s.total, replay, next, s.finished);
  state.busy = true;
  try { await director.resolve(); } finally { state.busy = false; }
}

async function replay() {
  if (state.busy || state.phase !== 'feedback') return;
  state.busy = true; sfx.ui();
  try { await director.resolve(); } finally { state.busy = false; }
}

async function next() {
  if (state.phase !== 'feedback') return;
  sfx.ui();
  timeline.finishAll();
  if (state.session.finished) {
    state.phase = 'end';
    frameFor('end');
    director.clear();
    updateViewButton();
    await director.moveCamera('accueil', 1.4);
    ui.renderEnd(state.session.result(), state.questions, restart, state.titre);
    return;
  }
  await showQuestion();
}

function restart() {
  sfx.ui();
  renderMenu();
  state.phase = 'intro';
  frameFor('intro');
  ui.show('intro');
  ui.el.progress.innerHTML = '';
  document.getElementById('btn-commencer').focus({ preventScroll: true });
}

// ——— Commandes ———
// Menu des chapitres (le nombre de situations est calculé depuis la banque)
/** « theme:circulation » ou « chap:feux » → liste de chapitres et libellé. */
function revisionTarget(value) {
  const [kind, id] = value.split(':');
  if (kind === 'theme') return { chapitres: CHAPITRES.filter((c) => c.domaine === id).map((c) => c.id), label: domainLabel(id) };
  return { chapitres: [id], label: chapitreLabel(id) };
}
/** Menu des modes : examen blanc, révision par chapitre (avec les notions déjà vues), parcours guidé. */
function renderMenu() {
  const seen = new Set(loadHistory());
  const stat = (chapitres) => {
    const ids = NOTIONS.filter((n) => chapitres.includes(n.chapitre));
    return `${ids.filter((n) => seen.has(n.id)).length}/${ids.length} vues`;
  };
  const previous = document.getElementById('opt-chapitre')?.value;
  const groups = DOMAINS.map((d) => {
    const subs = CHAPITRES.filter((c) => c.domaine === d.id);
    const whole = `<option value="theme:${d.id}">${d.label}${subs.length > 1 ? ' — tout le thème' : ''} (${stat(subs.map((c) => c.id))})</option>`;
    const parts = subs.length > 1 ? subs.map((c) => `<option value="chap:${c.id}">${c.label} (${stat([c.id])})</option>`).join('') : '';
    return `<optgroup label="${d.court}">${whole}${parts}</optgroup>`;
  }).join('');
  const checked = document.querySelector('input[name="chapitre"]:checked')?.value || 'aleatoire';
  const n = questionsFor(QUESTIONS, 'tout').length;
  document.getElementById('chapitres').innerHTML = `
    <label class="chapitre" for="chap-aleatoire"><input type="radio" name="chapitre" id="chap-aleatoire" value="aleatoire" ${checked === 'aleatoire' ? 'checked' : ''}>
      <span class="chap-nom">Examen blanc <span class="chap-n">tirage sur les 10 thèmes</span></span>
      <select id="opt-nombre" aria-label="Nombre de questions de l’examen blanc"><option value="10">10 questions</option><option value="20" selected>20 questions</option><option value="40">40 questions</option></select></label>
    <label class="chapitre" for="chap-revision"><input type="radio" name="chapitre" id="chap-revision" value="revision" ${checked === 'revision' ? 'checked' : ''}>
      <span class="chap-nom">Révision par chapitre</span>
      <span class="chap-detail">
        <select id="opt-chapitre" aria-label="Chapitre à réviser">${groups}</select>
        <select id="opt-nombre-revision" aria-label="Nombre de questions de la révision"><option value="tout" selected>Toutes les notions</option><option value="10">10 questions</option><option value="20">20 questions</option></select>
      </span></label>
    <label class="chapitre" for="chap-tout"><input type="radio" name="chapitre" id="chap-tout" value="tout" ${checked === 'tout' ? 'checked' : ''}>
      <span class="chap-nom">Parcours guidé</span><span class="chap-n">${n} situations commentées</span></label>`;
  if (previous) document.getElementById('opt-chapitre').value = previous;
  document.getElementById('opt-nombre').addEventListener('change', () => { document.getElementById('chap-aleatoire').checked = true; });
  for (const id of ['opt-chapitre', 'opt-nombre-revision']) document.getElementById(id).addEventListener('change', () => { document.getElementById('chap-revision').checked = true; });
}
renderMenu();
document.getElementById('btn-commencer').addEventListener('click', startGame);
ui.el.mute.addEventListener('click', () => {
  sfx.unlock();
  sfx.muted = !sfx.muted;
  ui.el.mute.setAttribute('aria-pressed', String(sfx.muted));
  ui.el.mute.querySelector('.etat').textContent = sfx.muted ? 'Son coupé' : 'Son activé';
});
ui.el.skip.addEventListener('click', () => timeline.finishAll());

document.addEventListener('keydown', (e) => {
  if (e.target.matches?.('input')) return;
  const key = e.key.toUpperCase();
  if (state.phase === 'question' && /^[A-D]$/.test(key)) {
    const q = state.session.current;
    if (q.options.some((o) => o.id === key)) { e.preventDefault(); toggleOption(key); }
  } else if (e.key === 'Enter' && state.phase === 'question' && !e.target.matches?.('#btn-valider')) {
    // Entrée valide toujours, y compris quand le focus est sur une option (évite de la désélectionner)
    e.preventDefault(); validate();
  } else if (e.key === ' ' && state.phase === 'observe') {
    e.preventDefault(); timeline.finishAll();
  } else if (key === 'V' && !e.ctrlKey && !e.metaKey) {
    toggleView();
  } else if (key === 'M' && !e.ctrlKey && !e.metaKey) {
    ui.el.mute.click();
  }
});

ui.show('intro');

// ——— Point d'accès pour les tests automatisés (lecture seule, sans effet sur le jeu normal) ———
window.__jeu = {
  get phase() { return state.phase; },
  get score() { return state.session?.score ?? 0; },
  get index() { return state.session?.index ?? 0; },
  get currentId() { return state.session?.current?.id ?? null; },
  get lastRecord() { return state.lastRecord; },
  get frames() { return frames; },
  get renders() { return renders; },
  get quality() { return world.quality; },
  get weather() { return world.weather; },
  get busy() { return timeline.busy; },
  get resolving() { return state.busy; },
  info: () => ({ calls: world.renderer.info.render.calls, tris: world.renderer.info.render.triangles, geos: world.renderer.info.memory.geometries, tex: world.renderer.info.memory.textures, progs: world.renderer.info.programs.length }),
  get timeLeft() { return state.timeLeft; },
  vehicles: () => director.snapshot(),
  props: () => director.propsState(),
  get view() { return director.view; },
  setView: (m) => { state.vuePref = m; director.setView(m); updateViewButton(); return director.view; },
  get current() { const q = state.session?.current; return q ? { id: q.id, notion: q.notion, domaine: q.domaine, famille: q.famille, site: q.scene.site, chapitre: NOTIONS.find((n) => n.id === q.notion)?.chapitre ?? null, total: state.session.total } : null; },
  history: () => loadHistory(),
  signImages: () => SIGNS.map((x) => [x.code, signImage(x.code)]),
  /** Tests et captures : lance une série composée des notions demandées. */
  playNotions: async (ids, seed = 1) => {
    const rng = createRng(seed);
    state.timed = false; state.exactCount = false;
    state.questions = ids.map((id, i) => makeQuestion(id, rng, `test-${i}`));
    state.session = createSession(state.questions);
    sfx.unlock();
    await showQuestion();
  },
  setTimeScale: (v) => { timeline.timeScale = v; },
  finishAnimations: () => timeline.finishAll(),
  correctIds: () => state.session?.current?.correct.slice() ?? [],
};
