"""Captures d'écran de revue visuelle. Usage : python3 tests/captures.py [largeur hauteur [chapitre]]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import e2e
from playwright.sync_api import sync_playwright
w, h = (int(sys.argv[1]), int(sys.argv[2])) if len(sys.argv) > 2 else (1100, 700)
chapter = sys.argv[3] if len(sys.argv) > 3 else 'tout'
with sync_playwright() as p:
    b = p.chromium.launch(args=['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'])
    errs = []
    ctx, pg = e2e.open_page(b, {'width': w, 'height': h}, errs)
    pg.screenshot(path=str(e2e.SHOTS / f'revue-{w}-0-accueil.png'))
    if chapter == 'aleatoire': pg.select_option('#opt-nombre', '10')
    pg.check(f'#chap-{chapter}')
    pg.click('#btn-commencer')
    i = 0
    while True:
        e2e.wait_phase(pg, 'question')
        pg.wait_for_timeout(200)
        i += 1
        pg.screenshot(path=str(e2e.SHOTS / f'revue-{w}-{chapter}-{i}.png'))
        for cid in pg.evaluate('window.__jeu.correctIds()'): pg.click(f'#opt-{cid}')
        pg.click('#btn-valider')
        pg.wait_for_function('window.__jeu.phase === "feedback"')
        pg.evaluate('window.__jeu.finishAnimations()')
        last = 'bilan' in pg.inner_text('#btn-suivant')
        pg.click('#btn-suivant')
        if last: break
    print('erreurs :', errs)
