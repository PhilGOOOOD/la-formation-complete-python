"""Tests de bout en bout du jeu dans Chromium (Playwright).

Couvre : démarrage sans erreur, parcours complet des 5 questions (réponse juste, fausse,
temps écoulé), mouvements des véhicules, bilan, affichage téléphone, accessibilité (axe-core),
captures d'écran de référence et mesure indicative de fluidité.
Usage : python3 tests/e2e.py  (après npm run build)
"""
import json, pathlib, sys, time
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
PAGE = (ROOT / 'dist' / 'test.html').as_uri()
SHOTS = ROOT / 'tests' / 'captures'
SHOTS.mkdir(exist_ok=True)
THREE = ROOT / 'node_modules' / 'three'

results = []
def check(name, ok, detail=''):
    results.append((name, bool(ok), detail))
    print(('  OK  ' if ok else ' ÉCHEC ') + name + (f' — {detail}' if detail else ''))

def route_cdn(route):
    """Sert Three.js depuis node_modules (même version que le CDN) pour des tests hors ligne et reproductibles."""
    url = route.request.url
    rel = url.split('three@0.170.0/', 1)[1]
    route.fulfill(path=str(THREE / rel), content_type='application/javascript')

def open_page(browser, viewport, errors):
    ctx = browser.new_context(viewport=viewport, device_scale_factor=1)
    page = ctx.new_page()
    page.add_init_script("window.__QUALITE = 'haute'")
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' and 'ERR_FAILED' not in m.text else None)
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.route('**/cdn.jsdelivr.net/npm/three@0.170.0/**', route_cdn)
    page.route('**/fonts.googleapis.com/**', lambda r: r.abort())
    page.route('**/fonts.gstatic.com/**', lambda r: r.abort())
    page.goto(PAGE)
    page.wait_for_function('window.__jeu && window.__jeu.renders > 0', timeout=90000)
    return ctx, page

def wait_phase(page, phase, timeout=120000):
    # Le rendu logiciel est lent : on termine les animations au lieu de les attendre.
    page.wait_for_function(f'(window.__jeu.phase === "observe" && window.__jeu.finishAnimations(), window.__jeu.phase === "{phase}")', timeout=timeout, polling=500)

def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(args=['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'])
        errors = []
        ctx, page = open_page(browser, {'width': 1100, 'height': 700}, errors)

        check('la page démarre et la scène 3D est dessinée', page.evaluate('window.__jeu.renders') > 0)
        check('écran d’accueil visible', page.is_visible('#ecran-accueil'))
        page.screenshot(path=str(SHOTS / '01-accueil.png'))

        # Accessibilité de l'accueil
        page.add_script_tag(path=str(ROOT / 'node_modules' / 'axe-core' / 'axe.min.js'))
        axe = page.evaluate("""async () => (await axe.run(document, { runOnly: ['wcag2a','wcag2aa'] })).violations
            .map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length }))""")
        check('accessibilité accueil : aucune violation grave (axe)', not [v for v in axe if v['impact'] in ('critical', 'serious')], json.dumps(axe, ensure_ascii=False))

        page.evaluate('window.__jeu.setTimeScale(1)')
        check('le mode aléatoire est proposé par défaut', page.is_checked('#chap-aleatoire'))
        page.check('#chap-tout')
        page.click('#btn-commencer')

        # Q1 — priorité à droite : réponse juste
        wait_phase(page, 'question')
        check('Q1 : aucune mention pour une question à une seule réponse', page.locator('.attendues').count() == 0)
        check('Q1 : la scène est décrite pour les lecteurs d’écran', 'droite' in (page.get_attribute('#scene', 'aria-label') or ''))
        page.keyboard.press('a')
        page.keyboard.press('a')
        page.wait_for_timeout(300)
        page.screenshot(path=str(SHOTS / '02-q1-question.png'))
        v = page.evaluate('window.__jeu.vehicles()')
        check('Q1 : deux véhicules à leur point d’attente', len(v) == 2 and all(abs(x['s'] - x['hold']) < 0.2 for x in v), json.dumps(v))
        rouge = next(x for x in v if x['id'] == 'rouge')
        check('Q1 : la voiture rouge arrive bien par la droite du joueur (est)', rouge['x'] > 4)
        check('Q1 : bouton Valider désactivé sans choix', page.is_disabled('#btn-valider'))
        page.keyboard.press('b')
        check('Q1 : la touche B sélectionne l’option B', page.get_attribute('#opt-B', 'aria-pressed') == 'true')
        page.click('#btn-valider')
        wait_phase(page, 'feedback')
        check('Q1 : verdict « Bonne réponse »', 'Bonne réponse' in page.inner_text('.verdict'))
        check('Q1 : référence à l’article affichée', 'R. 415-5' in page.inner_text('.panonceau'))
        page.screenshot(path=str(SHOTS / '03-q1-retour.png'))
        page.wait_for_function('(window.__jeu.finishAnimations(), window.__jeu.vehicles().every(v => v.s > v.hold + 20))', timeout=60000, polling=500)
        check('Q1 : la résolution fait avancer les deux voitures', True)
        page.click('#btn-suivant')

        # Q2 — stop : réponse incomplète, donc fausse
        wait_phase(page, 'question')
        page.screenshot(path=str(SHOTS / '04-q2-stop.png'))
        check('Q2 : mention « Plusieurs bonnes réponses » (comme à l’examen)', 'Plusieurs bonnes réponses' in page.inner_text('.attendues'))
        page.click('#opt-A')
        page.click('#btn-valider')
        wait_phase(page, 'feedback')
        check('Q2 : une réponse incomplète est comptée fausse', 'Pas tout à fait' in page.inner_text('.verdict'))
        check('Q2 : la progression marque l’erreur', page.locator('#progression li.ko').count() == 1)
        page.click('#btn-suivant')

        # Q3 — cédez le passage : on laisse le chrono s'écouler (accéléré)
        wait_phase(page, 'question')
        page.screenshot(path=str(SHOTS / '05-q3-cedez.png'))
        check('Q3 : le chrono est visible', page.is_visible('#chrono'))
        page.evaluate('window.__jeu.setTimeScale(40)')
        wait_phase(page, 'feedback')
        check('Q3 : temps écoulé compté comme une erreur', 'Temps écoulé' in page.inner_text('.verdict'))
        page.evaluate('window.__jeu.setTimeScale(1)')
        page.click('#btn-suivant')

        # Q4 — tourner à gauche : clignotant et réponse juste
        wait_phase(page, 'question')
        v = page.evaluate('window.__jeu.vehicles()')
        moi = next(x for x in v if x['id'] == 'moi')
        check('Q4 : clignotant gauche allumé sur la voiture du joueur', moi['blinker'] == 'left')
        page.screenshot(path=str(SHOTS / '06-q4-gauche.png'))
        page.click('#opt-B'); page.click('#btn-valider')
        wait_phase(page, 'feedback')
        page.wait_for_function('(window.__jeu.finishAnimations(), window.__jeu.vehicles().find(v => v.id === "moi").x < -8)', timeout=60000, polling=500)
        check('Q4 : le joueur tourne bien vers l’ouest après la voiture jaune', True)
        page.click('#btn-suivant')

        # Q5 — giratoire
        wait_phase(page, 'question')
        page.wait_for_timeout(200)
        page.screenshot(path=str(SHOTS / '07-q5-giratoire.png'))
        v = page.evaluate('window.__jeu.vehicles()')
        ring = next(x for x in v if x['id'] == 'rouge')
        check('Q5 : la voiture de l’anneau est à gauche du joueur', ring['x'] < 0, json.dumps(ring))
        page.click('#opt-A'); page.click('#btn-valider')
        wait_phase(page, 'feedback')
        page.screenshot(path=str(SHOTS / '08-q5-retour.png'))
        check('Q5 : bouton « Question suivante » (le parcours continue)', 'suivante' in page.inner_text('#btn-suivant'))
        page.click('#btn-suivant')

        # Q6 à Q11 — nouveaux environnements : réponses justes, vérifications ciblées
        expected = ['rue-velo-1', 'rue-stationnement-1', 'campagne-vitesse-1', 'campagne-depassement-1', 'autoroute-insertion-1', 'autoroute-pluie-1']
        for k, qid in enumerate(expected, start=6):
            wait_phase(page, 'question')
            check(f'Q{k} : question {qid}', page.evaluate('window.__jeu.currentId') == qid)
            if qid == 'autoroute-pluie-1':
                check('Q11 : il pleut sur l’autoroute', page.evaluate('window.__jeu.weather') == 'pluie')
            if qid == 'campagne-vitesse-1':
                check('Q8 : il fait beau en campagne', page.evaluate('window.__jeu.weather') == 'beau')
            page.screenshot(path=str(SHOTS / f'12-q{k}.png'))
            for cid in page.evaluate('window.__jeu.correctIds()'):
                page.click(f'#opt-{cid}')
            page.keyboard.press('Enter')
            wait_phase(page, 'feedback')
            check(f'Q{k} : Entrée valide la réponse et elle est juste', 'Bonne réponse' in page.inner_text('.verdict'))
            page.wait_for_function('(window.__jeu.finishAnimations(), !window.__jeu.resolving)', timeout=90000, polling=500)
            if qid == 'campagne-depassement-1':
                v = page.evaluate('window.__jeu.vehicles()')
                moi = next(x for x in v if x['id'] == 'moi'); tr = next(x for x in v if x['id'] == 'tracteur')
                check('Q9 : le joueur a dépassé le tracteur et s’est rabattu', moi['z'] < tr['z'] and abs(moi['x'] - 2) < 0.2, json.dumps(v))
            page.click('#btn-revoir', timeout=90000)
            page.click('#btn-revoir', timeout=90000)  # double clic : ne doit rien casser
            page.wait_for_function('(window.__jeu.finishAnimations(), !window.__jeu.resolving)', timeout=90000, polling=500)
            if k == 11:
                check('dernier bouton = « Voir le bilan »', 'bilan' in page.inner_text('#btn-suivant'))
            page.click('#btn-suivant')

        page.wait_for_function('(window.__jeu.finishAnimations(), window.__jeu.phase === "end")', timeout=60000, polling=500)
        page.wait_for_selector('#ecran-bilan:not([hidden])')
        page.wait_for_timeout(500)
        page.screenshot(path=str(SHOTS / '09-bilan.png'))
        score = page.inner_text('#bilan-score')
        check('bilan : score 9/11 (Q2 fausse, Q3 temps écoulé)', score.replace('\n', '') == '9/11', score)
        check('bilan : 11 lignes de détail', page.locator('#bilan-liste li').count() == 11)
        axe = page.evaluate("""async () => (await axe.run(document, { runOnly: ['wcag2a','wcag2aa'] })).violations
            .map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length }))""")
        check('accessibilité bilan : aucune violation grave (axe)', not [v for v in axe if v['impact'] in ('critical', 'serious')], json.dumps(axe, ensure_ascii=False))

        geos_bilan = page.evaluate('window.__jeu.info().geos')  # tout le décor a été affiché au moins une fois
        check('bilan : bouton de vue masqué', not page.is_visible('#btn-vue'))
        page.click('#btn-rejouer')
        check('rejouer ramène à l’accueil', page.is_visible('#ecran-accueil'))
        page.click('#btn-commencer')
        wait_phase(page, 'question')
        geos_again = page.evaluate('window.__jeu.info().geos')
        check('mémoire : les objets des 11 situations ont été libérés', geos_again - geos_bilan < 40, f'bilan {geos_bilan}, puis Q1 de la 2e partie {geos_again}')

        # Entraînement aléatoire : 10 questions tirées au hasard, toutes jouées jusqu'au bilan
        page.goto(PAGE)
        page.wait_for_function('window.__jeu && window.__jeu.renders > 0', timeout=90000)
        page.select_option('#opt-nombre', '10')
        check('choisir un nombre de questions sélectionne le mode aléatoire', page.is_checked('#chap-aleatoire'))
        page.click('#btn-commencer')
        seen, notions, domaines = set(), [], set()
        for k in range(10):
            wait_phase(page, 'question')
            cur = page.evaluate('window.__jeu.current')
            qid = cur['id']
            seen.add(cur['famille']); notions.append(cur['notion']); domaines.add(cur['domaine'])
            if qid.startswith('alea-panneau'):
                check(f'aléatoire Q{k+1} : vignette du panneau affichée', page.locator('.vignette').count() == 1)
            if page.locator('.vignette').count():
                check(f'aléatoire Q{k+1} : la vignette a un texte de remplacement', len(page.get_attribute('.vignette', 'alt') or '') > 10)
            for cid in page.evaluate('window.__jeu.correctIds()'):
                page.click(f'#opt-{cid}')
            page.click('#btn-valider')
            wait_phase(page, 'feedback')
            if 'Bonne réponse' not in page.inner_text('.verdict'):
                check(f'aléatoire Q{k+1} ({qid}) : la bonne réponse est reconnue', False)
            page.wait_for_function('(window.__jeu.finishAnimations(), !window.__jeu.resolving)', timeout=90000, polling=500)
            page.click('#btn-suivant')
        page.wait_for_function('(window.__jeu.finishAnimations(), window.__jeu.phase === "end")', timeout=60000, polling=500)
        check('aléatoire : 10/10 en répondant juste', page.inner_text('#bilan-score').replace('\n', '') == '10/10', page.inner_text('#bilan-score'))
        check('aléatoire : aucune notion répétée dans la série', len(set(notions)) == 10, str(notions))
        check('aléatoire : les 10 thèmes de l’examen sont couverts', len(domaines) == 10, str(domaines))
        check('aléatoire : plusieurs familles de mises en scène', len(seen) >= 6, str(seen))
        check('bilan : tableau des résultats par thème', page.locator('#bilan-themes tr').count() == 10)
        hist = page.evaluate('window.__jeu.history()')
        check('historique : les notions vues sont mémorisées', all(n in hist for n in notions), str(len(hist)))
        # Deuxième série : aucune des notions déjà vues ne revient
        page.click('#btn-rejouer')
        page.select_option('#opt-nombre', '10')
        page.click('#btn-commencer')
        wait_phase(page, 'question')
        second = page.evaluate('window.__jeu.current')['notion']
        check('historique : la série suivante commence par une notion nouvelle', second not in notions, second)
        info = page.evaluate('window.__jeu.info()')
        print(f"  info  appels de dessin : {info['calls']}, triangles : {info['tris']}, textures : {info['tex']}, programmes : {info['progs']}")
        check('budget de rendu : moins de 400 appels de dessin', info['calls'] < 400, str(info['calls']))
        check('aucune erreur dans la console', not errors, ' | '.join(errors[:5]))

        # Révision par chapitre : panneaux de danger, toutes les notions
        page.goto(PAGE)
        page.wait_for_function('window.__jeu && window.__jeu.renders > 0', timeout=90000)
        page.screenshot(path=str(SHOTS / '17-menu.png'))
        page.select_option('#opt-chapitre', 'chap:panneaux-danger')
        check('choisir un chapitre sélectionne le mode révision', page.is_checked('#chap-revision'))
        page.click('#btn-commencer')
        for k in range(3):
            wait_phase(page, 'question')
            cur = page.evaluate('window.__jeu.current')
            check(f'révision Q{k+1} : notion du chapitre « panneaux de danger »', cur['chapitre'] == 'panneaux-danger', json.dumps(cur))
            if k == 0: check('révision : toutes les notions du chapitre sont proposées', cur['total'] >= 20, str(cur['total']))
            if page.locator('.options.en-images').count():
                check(f'révision Q{k+1} : réponses en images avec texte de remplacement', page.locator('.opt-img').count() == 4 and all(len(page.get_attribute(f'#opt-{l} img', 'alt') or '') > 5 for l in 'ABCD'))
                page.screenshot(path=str(SHOTS / '18-quel-panneau.png'))
            for cid in page.evaluate('window.__jeu.correctIds()'): page.click(f'#opt-{cid}')
            page.click('#btn-valider')
            wait_phase(page, 'feedback')
            check(f'révision Q{k+1} : réponse juste reconnue', 'Bonne réponse' in page.inner_text('.verdict'))
            page.wait_for_function('(window.__jeu.finishAnimations(), !window.__jeu.resolving)', timeout=90000, polling=500)
            page.click('#btn-suivant')

        # Scénarios ciblés (feux, passage à niveau, éclairage, vue rapprochée)
        page.goto(PAGE)
        page.wait_for_function('window.__jeu && window.__jeu.renders > 0', timeout=90000)
        page.evaluate("window.__jeu.playNotions(['reconnaitre-panneaux-interdiction', 'feu-rouge', 'pn-barrieres', 'nuit-croiser', 'piece-batterie'], 3)")
        wait_phase(page, 'question')
        check('« quel panneau » : quatre réponses en images', page.locator('.options.en-images .opt-img').count() == 4)
        page.screenshot(path=str(SHOTS / '18-quel-panneau.png'))
        for cid in page.evaluate('window.__jeu.correctIds()'): page.click(f'#opt-{cid}')
        page.click('#btn-valider')
        wait_phase(page, 'feedback')
        page.wait_for_function('(window.__jeu.finishAnimations(), !window.__jeu.resolving)', timeout=90000, polling=500)
        page.click('#btn-suivant')
        wait_phase(page, 'question')
        feux = page.evaluate('window.__jeu.props()')
        check('feu rouge : quatre feux posés, deux rouges et deux verts', len([f for f in feux if f['type'] == 'feu']) == 4 and sorted(f['state'] for f in feux if f['type'] == 'feu') == ['rouge', 'rouge', 'vert', 'vert'], json.dumps(feux))
        page.screenshot(path=str(SHOTS / '13-feu-rouge.png'))
        check('vue conducteur conseillée au feu rouge', page.evaluate('window.__jeu.view') == 'conducteur')
        check('vue conducteur : habitacle et rétroviseur affichés', page.is_visible('#cockpit') and page.locator('#cockpit rect').count() >= 2)
        check('bouton de vue visible et étiqueté', page.is_visible('#btn-vue') and 'dessus' in page.inner_text('#btn-vue'))
        page.keyboard.press('v')
        check('touche V : retour à la vue du dessus', page.evaluate('window.__jeu.view') == 'iso' and not page.is_visible('#cockpit'))
        page.keyboard.press('v')
        check('touche V : de nouveau à la place du conducteur', page.evaluate('window.__jeu.view') == 'conducteur')
        page.wait_for_timeout(400)
        calls = page.evaluate('window.__jeu.info().calls')
        check('vue conducteur : moins de 400 appels de dessin, rétroviseur compris', 20 < calls < 400, str(calls))
        moi = next(v for v in page.evaluate('window.__jeu.vehicles()') if v['id'] == 'moi')
        page.click(f"#opt-{page.evaluate('window.__jeu.correctIds()')[0]}"); page.click('#btn-valider')
        wait_phase(page, 'feedback')
        page.wait_for_function('(window.__jeu.finishAnimations(), !window.__jeu.resolving)', timeout=90000, polling=500)
        moi = next(v for v in page.evaluate('window.__jeu.vehicles()') if v['id'] == 'moi')
        check('feu rouge : le joueur ne repart qu’une fois le feu passé au vert', moi['s'] > moi['hold'] + 20 and 'vert' in [f['state'] for f in page.evaluate('window.__jeu.props()') if f['type'] == 'feu'], json.dumps(moi))
        page.click('#btn-suivant')
        wait_phase(page, 'question')
        pn = next(p for p in page.evaluate('window.__jeu.props()') if p['type'] == 'pn')
        check('passage à niveau : demi-barrières à mi-course au moment de la question', abs(pn['barrier'] - 0.5) < 0.01, json.dumps(pn))
        page.screenshot(path=str(SHOTS / '14-passage-niveau.png'))
        for cid in page.evaluate('window.__jeu.correctIds()'): page.click(f'#opt-{cid}')
        page.click('#btn-valider')
        wait_phase(page, 'feedback')
        page.wait_for_function('(window.__jeu.finishAnimations(), !window.__jeu.resolving)', timeout=90000, polling=500)
        pn = next(p for p in page.evaluate('window.__jeu.props()') if p['type'] == 'pn')
        check('passage à niveau : barrières relevées après le passage du train', pn['barrier'] < 0.01, json.dumps(pn))
        page.click('#btn-suivant')
        wait_phase(page, 'question')
        check('nuit : la scène est plongée dans la nuit', page.evaluate('window.__jeu.weather') == 'nuit')
        moi = next(v for v in page.evaluate('window.__jeu.vehicles()') if v['id'] == 'moi')
        check('nuit : le joueur n’a que ses feux de position pendant la question', moi['lights'] == 'position', json.dumps(moi))
        page.screenshot(path=str(SHOTS / '15-nuit.png'))
        for cid in page.evaluate('window.__jeu.correctIds()'): page.click(f'#opt-{cid}')
        page.click('#btn-valider')
        wait_phase(page, 'feedback')
        page.wait_for_function('(window.__jeu.finishAnimations(), !window.__jeu.resolving)', timeout=90000, polling=500)
        moi = next(v for v in page.evaluate('window.__jeu.vehicles()') if v['id'] == 'moi')
        check('nuit : la résolution passe le joueur en feux de croisement', moi['lights'] == 'croisement', json.dumps(moi))
        page.click('#btn-suivant')
        wait_phase(page, 'question')
        page.screenshot(path=str(SHOTS / '16-capot.png'))
        check('vue rapprochée : trois pièces étiquetées sous le capot', page.locator('#carte .option').count() == 3)
        check('scénarios ciblés : aucune erreur console', not errors, ' | '.join(errors[:5]))
        ctx.close()

        # Téléphone
        errors_m = []
        ctx, page = open_page(browser, {'width': 390, 'height': 844}, errors_m)
        page.screenshot(path=str(SHOTS / '10-mobile-accueil.png'))
        page.check('#chap-tout')
        page.click('#btn-commencer')
        wait_phase(page, 'question')
        page.wait_for_timeout(300)
        page.screenshot(path=str(SHOTS / '11-mobile-question.png'))
        sw = page.evaluate('[document.documentElement.scrollWidth, window.innerWidth]')
        check('téléphone : pas de défilement horizontal', sw[0] <= sw[1], str(sw))
        box = page.locator('#btn-valider').bounding_box()
        check('téléphone : bouton Valider visible à l’écran', box and box['y'] + box['height'] <= 844, str(box))
        check('téléphone : aucune erreur console', not errors_m, ' | '.join(errors_m[:5]))
        ctx.close()
        browser.close()

    failed = [r for r in results if not r[1]]
    print(f'\n{len(results) - len(failed)}/{len(results)} vérifications réussies')
    sys.exit(1 if failed else 0)

if __name__ == '__main__':
    main()
