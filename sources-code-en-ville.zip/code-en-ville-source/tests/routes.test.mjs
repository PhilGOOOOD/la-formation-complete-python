import { test } from 'node:test';
import assert from 'node:assert/strict';
import { intersectionRoute, giratoireRoute, pointAt, rightOf, ROAD_HALF, GIRATOIRE } from '../src/scene/routes.js';
import { QUESTIONS } from '../src/data/questions.js';
import { routeFor } from '../src/scene/routes.js';

const near = (a, b, eps = 0.05) => Math.abs(a - b) < eps;

test('le vecteur droite correspond à la circulation à droite', () => {
  const n = (v) => ({ x: v.x + 0, z: v.z + 0 });
  assert.deepEqual(n(rightOf({ x: 0, z: -1 })), { x: 1, z: 0 }); // vers le nord, la droite est l'est
  assert.deepEqual(n(rightOf({ x: 1, z: 0 })), { x: 0, z: 1 });  // vers l'est, la droite est le sud
});

test('un véhicule venant du sud roule sur la voie de droite (x > 0)', () => {
  const r = intersectionRoute('S', 'straight');
  for (const p of r.points) assert.ok(near(p.x, 2), `x=${p.x}`);
  const start = pointAt(r, 0);
  assert.ok(near(start.angle, Math.PI) || near(Math.abs(start.angle), Math.PI), 'cap vers le nord');
});

test('le point d’attente est avant la chaussée croisée', () => {
  for (const from of ['N', 'S', 'E', 'W']) {
    const r = intersectionRoute(from, 'straight');
    const p = pointAt(r, r.hold);
    const distToCenter = Math.max(Math.abs(p.x), Math.abs(p.z));
    assert.ok(distToCenter > ROAD_HALF + 2, `${from} : attente trop proche (${distToCenter.toFixed(2)})`);
    assert.ok(r.hold > 0 && r.hold < r.length);
  }
});

test('le virage à gauche finit sur la voie de droite de la route ouest', () => {
  const r = intersectionRoute('S', 'left');
  const end = r.points[r.points.length - 1];
  assert.ok(end.x < -30, 'part vers l’ouest');
  assert.ok(near(end.z, -2), `voie nord de la route est-ouest, z=${end.z}`);
});

test('le virage à droite finit sur la voie sud de la route est', () => {
  const r = intersectionRoute('S', 'right');
  const end = r.points[r.points.length - 1];
  assert.ok(end.x > 30 && near(end.z, 2));
});

test('les routes sont continues (pas de saut entre deux points)', () => {
  const routes = [intersectionRoute('S', 'left'), intersectionRoute('E', 'right'), giratoireRoute('ring-east'), giratoireRoute('ring-north')];
  for (const r of routes) {
    for (let i = 1; i < r.points.length; i++) {
      const d = Math.hypot(r.points[i].x - r.points[i - 1].x, r.points[i].z - r.points[i - 1].z);
      assert.ok(d < 1.2, `saut de ${d.toFixed(2)} m à l’index ${i}`);
    }
  }
});

test('l’anneau du giratoire est parcouru dans le sens antihoraire vu de dessus', () => {
  const r = giratoireRoute('ring-north');
  const { cx, cz } = GIRATOIRE;
  const a0 = Math.atan2(r.points[2].z - cz, r.points[2].x - cx);
  const a1 = Math.atan2(r.points[6].z - cz, r.points[6].x - cx);
  // Z vers le sud : l'angle décroît quand on tourne dans le sens antihoraire à l'écran.
  let d = a1 - a0; if (d > Math.PI) d -= 2 * Math.PI; if (d < -Math.PI) d += 2 * Math.PI;
  assert.ok(d < 0, 'angle décroissant attendu');
});

test('la voiture de l’anneau attend à gauche du joueur', () => {
  const ring = giratoireRoute('ring-north');
  const p = pointAt(ring, ring.hold);
  assert.ok(p.x < GIRATOIRE.cx, 'côté ouest, donc à gauche d’un véhicule venant du sud');
});

test('chaque véhicule des questions a une route valide', () => {
  for (const q of QUESTIONS) for (const v of q.scene.vehicles) {
    const r = routeFor(v, q.scene.site);
    assert.ok(r.length > 20, `${q.id}/${v.id}`);
  }
});

/** Position d'un autre véhicule dans le repère du conducteur joueur (avant / droite), aux points d'attente. */
function relative(question, otherId) {
  const { site, vehicles } = question.scene;
  const me = vehicles.find((v) => v.player), other = vehicles.find((v) => v.id === otherId);
  const rm = routeFor(me, site), ro = routeFor(other, site);
  const p = pointAt(rm, rm.hold), o = pointAt(ro, ro.hold);
  const fwd = { x: Math.sin(p.angle), z: Math.cos(p.angle) };
  const right = rightOf(fwd);
  const d = { x: o.x - p.x, z: o.z - p.z };
  return { avant: d.x * fwd.x + d.z * fwd.z, droite: d.x * right.x + d.z * right.z,
    memeSens: Math.cos(o.angle - p.angle) > 0.7, sensInverse: Math.cos(o.angle - p.angle) < -0.7 };
}

test('la mise en scène correspond à l’énoncé de chaque question', () => {
  const q = (id) => QUESTIONS.find((x) => x.id === id);
  let r = relative(q('priorite-droite-1'), 'rouge');
  assert.ok(r.droite > 2 && r.avant > 0, `Q1 : la voiture rouge doit venir de droite ${JSON.stringify(r)}`);
  r = relative(q('cedez-1'), 'blanche');
  assert.ok(r.droite < -2 && r.avant > 0, `Q3 : la voiture blanche doit venir de gauche ${JSON.stringify(r)}`);
  r = relative(q('gauche-1'), 'jaune');
  assert.ok(r.avant > 8 && r.sensInverse, `Q4 : la voiture jaune doit arriver en face ${JSON.stringify(r)}`);
  r = relative(q('giratoire-1'), 'rouge');
  assert.ok(r.droite < 0 && r.avant > 0, `Q5 : la voiture de l’anneau doit être à gauche, devant ${JSON.stringify(r)}`);
  r = relative(q('rue-velo-1'), 'cycliste');
  assert.ok(r.droite > 3 && r.avant < 0 && r.memeSens, `cycliste derrière à droite, même sens ${JSON.stringify(r)}`);
  r = relative(q('campagne-depassement-1'), 'tracteur');
  assert.ok(r.avant > 4 && Math.abs(r.droite) < 0.5 && r.memeSens, `tracteur devant, même voie ${JSON.stringify(r)}`);
  r = relative(q('autoroute-insertion-1'), 'blanche');
  assert.ok(r.avant < 0 && r.droite < -2 && r.memeSens, `voiture blanche en arrière, à gauche ${JSON.stringify(r)}`);
});

test('sur la route de campagne, le joueur ne quitte sa voie que sur la ligne discontinue', async () => {
  const { CAMPAGNE, LANE } = await import('../src/scene/routes.js');
  const r = routeFor({ action: 'rural-follow' }, 'campagne');
  for (const p of r.points) {
    const zl = p.z - CAMPAGNE.oz;
    if (zl < CAMPAGNE.solidFrom && zl > CAMPAGNE.solidTo) assert.ok(Math.abs(p.x - CAMPAGNE.ox - LANE) < 0.01, `écart de voie à z=${zl.toFixed(1)}`);
  }
});

test('le virage à gauche de Q4 traverse le carrefour sans couper la voie du sud', () => {
  const r = routeFor({ from: 'S', action: 'left' }, 'intersection');
  const mid = pointAt(r, r.hold + 9);
  assert.ok(mid.x > -1 && mid.z < 3, JSON.stringify(mid));
});
