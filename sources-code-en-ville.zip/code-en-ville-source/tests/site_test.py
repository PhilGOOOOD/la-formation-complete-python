"""Vérifie la version autonome (dossier site/) telle qu'elle sera publiée sur GitHub Pages.

- aucune requête vers un serveur externe ;
- polices intégrées, manifeste valide (installable), icônes présentes ;
- le service worker garde une copie : le jeu redémarre et se joue hors connexion.
Usage : python3 tests/site_test.py  (après npm run build)
"""
import functools, http.server, json, pathlib, sys, threading
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
SITE = ROOT / 'site'
SHOTS = ROOT / 'tests' / 'captures'
SHOTS.mkdir(exist_ok=True)

results = []
def check(name, ok, detail=''):
    results.append((name, bool(ok), detail))
    print(('  OK  ' if ok else ' ÉCHEC ') + name + (f' — {detail}' if detail else ''))

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass

def serve():
    handler = functools.partial(Quiet, directory=str(SITE))
    handler.extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map, '.webmanifest': 'application/manifest+json'}
    srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv

def wait_phase(page, phase, timeout=120000):
    page.wait_for_function(f'(window.__jeu.phase === "observe" && window.__jeu.finishAnimations(), window.__jeu.phase === "{phase}")', timeout=timeout, polling=500)

def main():
    srv = serve()
    base = f'http://127.0.0.1:{srv.server_address[1]}/'
    with sync_playwright() as p:
        browser = p.chromium.launch(args=['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'])
        ctx = browser.new_context(viewport={'width': 1100, 'height': 700})
        page = ctx.new_page()
        errors, externes = [], []
        page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('request', lambda r: externes.append(r.url) if not r.url.startswith(base) and not r.url.startswith('data:') else None)

        page.goto(base)
        page.wait_for_function('window.__jeu && window.__jeu.renders > 0', timeout=90000)
        check('le jeu démarre depuis le site autonome', page.is_visible('#ecran-accueil'))
        check('aucune requête vers un serveur externe', not externes, ', '.join(externes[:3]))
        fonts = page.evaluate("document.fonts.ready.then(() => [document.fonts.check('600 16px \"Barlow\"'), document.fonts.check('700 16px \"Barlow Semi Condensed\"')])")
        check('polices Barlow intégrées et chargées', all(fonts), str(fonts))

        manifest = json.loads((SITE / 'manifest.webmanifest').read_text())
        sizes = {i['sizes'] for i in manifest['icons']}
        check('manifeste : nom, adresse de départ, affichage, icônes 192 et 512',
              manifest.get('name') and manifest.get('start_url') and manifest.get('display') == 'standalone' and {'192x192', '512x512'} <= sizes)
        check('icônes présentes', all((SITE / i['src']).exists() for i in manifest['icons']) and (SITE / 'icons/apple-touch-icon.png').exists())
        mtype = page.evaluate("fetch('manifest.webmanifest').then(r => r.headers.get('content-type'))")
        check('manifeste servi et relié à la page', 'json' in (mtype or '') and page.locator('link[rel=manifest]').count() == 1, mtype)

        page.wait_for_function('navigator.serviceWorker.ready.then(() => true)', timeout=30000)
        page.reload()
        page.wait_for_function('window.__jeu && window.__jeu.renders > 0', timeout=90000)
        check('service worker actif (la page est sous son contrôle)', page.evaluate('!!navigator.serviceWorker.controller'))
        cached = page.evaluate("caches.keys().then(ks => Promise.all(ks.map(k => caches.open(k).then(c => c.keys())))).then(a => a.flat().map(r => new URL(r.url).pathname))")
        check('copie hors ligne : page, manifeste et icônes', all(any(c.endswith(f) for c in cached) for f in ['/index.html', '/manifest.webmanifest', '/icons/icon-512.png']), str(cached))

        # Hors connexion : on coupe le réseau et le serveur, puis on relance le jeu.
        ctx.set_offline(True)
        srv.shutdown(); srv.server_close()
        page.reload()
        page.wait_for_function('window.__jeu && window.__jeu.renders > 0', timeout=90000)
        check('hors connexion : le jeu redémarre', page.is_visible('#ecran-accueil'))
        page.click('#btn-commencer')
        wait_phase(page, 'question')
        q = page.evaluate('window.__jeu.current')
        check('hors connexion : une série aléatoire se lance', q and q.get('total') in (10, 20, 40), json.dumps({k: q.get(k) for k in ('id', 'total')} if q else None))
        page.screenshot(path=str(SHOTS / 'site-hors-ligne.png'))

        # Téléphone (vue d'accueil)
        m = browser.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, is_mobile=True, has_touch=True, offline=True)
        ctx.close()
        check('aucune erreur JavaScript', not [e for e in errors if 'ERR_INTERNET_DISCONNECTED' not in e], ' | '.join(errors[:3]))
        m.close()
        browser.close()

    ok = sum(1 for r in results if r[1])
    print(f'\n{ok}/{len(results)} vérifications réussies')
    sys.exit(0 if ok == len(results) else 1)

if __name__ == '__main__':
    main()
