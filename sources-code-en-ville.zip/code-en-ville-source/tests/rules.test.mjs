import { test } from 'node:test';
import assert from 'node:assert/strict';
import { resolvePriority, pathsConflict, sideOf, speedLimit, overtakeRule, PARKING_SPOTS } from '../src/engine/rules.js';

const P = (action, regime = 'aucun') => ({ from: 'S', action, regime });
const O = (from, action, regime = 'aucun') => ({ from, action, regime });

test('position relative des approches', () => {
  assert.equal(sideOf('S', 'E'), 'droite');
  assert.equal(sideOf('S', 'W'), 'gauche');
  assert.equal(sideOf('S', 'N'), 'face');
  assert.equal(sideOf('E', 'N'), 'droite');
});

test('table de vérité des priorités (joueur venant du sud)', () => {
  const cases = [
    // [moi, autre, premier attendu, article]
    [P('straight'), O('E', 'straight'), 'autre', 'R415-5'],
    [P('straight'), O('W', 'straight'), 'moi', 'R415-5'],
    [P('left'), O('E', 'straight'), 'autre', 'R415-5'],
    [P('right'), O('W', 'straight'), 'moi', 'R415-5'],
    [P('straight'), O('E', 'right'), 'autre', 'R415-5'],
    [P('straight', 'stop'), O('W', 'straight'), 'autre', 'R415-6'],
    [P('straight', 'cedez'), O('W', 'straight'), 'autre', 'R415-7'],
    [P('straight'), O('E', 'straight', 'stop'), 'moi', 'R415-6'],
    [P('straight'), O('E', 'straight', 'cedez'), 'moi', 'R415-7'],
    [P('left'), O('N', 'straight'), 'autre', 'R415-4'],
    [P('straight'), O('N', 'left'), 'moi', 'R415-4'],
    [P('left', 'stop'), O('N', 'right', 'stop'), 'autre', 'R415-4'],
  ];
  for (const [me, other, first, article] of cases) {
    const r = resolvePriority(me, other);
    assert.equal(r.first, first, `${JSON.stringify(me)} / ${JSON.stringify(other)} → ${r.raison}`);
    assert.equal(r.article, article, `${JSON.stringify(me)} / ${JSON.stringify(other)}`);
    assert.ok(r.raison.length > 20);
  }
});

test('trajectoires sans conflit détectées', () => {
  assert.equal(pathsConflict(P('straight'), O('N', 'straight')), false, 'deux voitures face à face qui vont tout droit');
  assert.equal(pathsConflict(P('right'), O('E', 'straight')), false, 'virage à droite et voiture de droite qui continue');
  assert.equal(resolvePriority(P('right'), O('E', 'straight')).sansConflit, true);
  assert.equal(pathsConflict(P('straight'), O('E', 'straight')), true);
  assert.equal(pathsConflict(P('straight'), O('E', 'right')), true, 'les deux finissent sur la même voie');
});

test('les combinaisons exclues sont refusées', () => {
  assert.throws(() => resolvePriority(P('straight', 'stop'), O('E', 'straight', 'cedez')), /exclue/);
  assert.throws(() => resolvePriority(P('straight', 'stop'), O('W', 'straight', 'stop')), /exclue/, 'deux stops perpendiculaires : le texte ne tranche pas');
  assert.throws(() => resolvePriority(P('straight', 'cedez'), O('E', 'straight', 'cedez')), /exclue/);
  assert.throws(() => resolvePriority(P('left'), O('N', 'left')), /non géré/);
});

test('vitesses maximales (R413-2 à R413-5)', () => {
  const v = (o) => speedLimit(o).v;
  assert.equal(v({ road: 'agglo' }), 50);
  assert.equal(v({ road: 'agglo', meteo: 'pluie' }), 50);
  assert.equal(v({ road: 'route' }), 80);
  assert.equal(v({ road: 'route', meteo: 'pluie' }), 80);
  assert.equal(v({ road: 'deuxChaussees' }), 110);
  assert.equal(v({ road: 'deuxChaussees', meteo: 'pluie' }), 100);
  assert.equal(v({ road: 'autoroute' }), 130);
  assert.equal(v({ road: 'autoroute', meteo: 'pluie' }), 110);
  assert.equal(v({ road: 'autoroute', probatoire: true }), 110);
  assert.equal(v({ road: 'deuxChaussees', probatoire: true }), 100);
  assert.equal(v({ road: 'autoroute', meteo: 'brouillard' }), 50);
  assert.equal(speedLimit({ road: 'autoroute', meteo: 'brouillard' }).article, 'R413-4');
  assert.equal(speedLimit({ road: 'autoroute', probatoire: true }).article, 'R413-5');
  assert.equal(speedLimit({ road: 'autoroute', meteo: 'pluie' }).alinea, 'II, 1°');
});

test('dépassement et stationnement', () => {
  assert.equal(overtakeRule({ ligne: 'continue', cible: 'tracteur' }).permis, false);
  assert.equal(overtakeRule({ ligne: 'continue', cible: 'velo' }).permis, true);
  assert.equal(overtakeRule({ ligne: 'discontinue', cible: 'tracteur' }).permis, true);
  assert.equal(Object.values(PARKING_SPOTS).filter((s) => s.permis).length, 1);
});

// Oracle indépendant du calcul géométrique : conflits établis à la main, trajectoire par trajectoire,
// pour un joueur venant du sud (voie x = +2). « null » = cas exclu du générateur (deux virages à gauche face à face).
const CONFLICTS = {
  straight: { E: { straight: true, left: true, right: true }, W: { straight: true, left: true, right: false }, N: { straight: false, left: true, right: false } },
  left: { E: { straight: true, left: true, right: false }, W: { straight: true, left: true, right: false }, N: { straight: true, left: null, right: true } },
  right: { E: { straight: false, left: false, right: false }, W: { straight: true, left: false, right: false }, N: { straight: false, left: true, right: false } },
};

test('les conflits de trajectoires correspondent à la table établie à la main', () => {
  for (const [myAction, byFrom] of Object.entries(CONFLICTS)) {
    for (const [from, byAction] of Object.entries(byFrom)) {
      for (const [action, expected] of Object.entries(byAction)) {
        if (expected === null) continue;
        assert.equal(pathsConflict(P(myAction), O(from, action)), expected, `moi ${myAction} / autre de ${from} ${action}`);
      }
    }
  }
});

// ——— v0.4 : feux, éclairage, distances ———
import { trafficLight, headlights, fogLights, distanceIn } from '../src/engine/rules.js';

test('feux tricolores : rouge et jaune arrêtent, sauf arrêt impossible ; vert encombré interdit de s’engager', () => {
  assert.equal(trafficLight({ state: 'rouge' }).passe, false);
  assert.equal(trafficLight({ state: 'rouge' }).article, 'R412-30');
  assert.equal(trafficLight({ state: 'jaune' }).passe, false);
  assert.equal(trafficLight({ state: 'jaune', arretImpossible: true }).passe, true);
  assert.equal(trafficLight({ state: 'jaune-clignotant' }).article, 'R412-32');
  assert.equal(trafficLight({ state: 'vert' }).passe, true);
  assert.equal(trafficLight({ state: 'vert', bloque: true }).passe, false);
});

test('éclairage de nuit (R416-5, R416-6) et feux de brouillard (R416-7)', () => {
  assert.equal(headlights({ lieu: 'route-sombre' }).feux, 'route');
  assert.equal(headlights({ lieu: 'route-sombre', croise: true }).alinea, 'II, 1° a');
  assert.equal(headlights({ lieu: 'route-sombre', suit: true }).feux, 'croisement');
  assert.equal(headlights({ lieu: 'agglo-eclairee' }).feux, 'croisement');
  assert.deepEqual([fogLights('brouillard').avant, fogLights('brouillard').arriere], [true, true]);
  assert.deepEqual([fogLights('neige').avant, fogLights('neige').arriere], [true, true]);
  assert.deepEqual([fogLights('forte-pluie').avant, fogLights('forte-pluie').arriere], [true, false]);
  assert.deepEqual([fogLights('pluie').avant, fogLights('pluie').arriere], [false, false]);
});

test('distance parcourue en deux secondes', () => {
  assert.equal(distanceIn(90, 1), 25);
  assert.equal(distanceIn(90, 2), 50);
  assert.equal(distanceIn(130, 2), 72);
  assert.equal(distanceIn(50, 2), 28);
});
