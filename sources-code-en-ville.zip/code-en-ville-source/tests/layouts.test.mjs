import { test } from 'node:test';
import assert from 'node:assert/strict';
import { layout, overlaps, isRoad } from '../src/data/layouts.js';

const KNOWN = new Set(['route', 'croix', 'te', 'giratoire', 'autoroute', 'immeubles', 'maisons', 'parc', 'bosquet', 'champ', 'foret']);

test('les plans du kit ne se chevauchent pas et n’utilisent que des pièces connues', () => {
  for (const [name, opts] of [['croix', {}], ['croix', { theme: 'campagne' }], ['giratoire', {}], ['rue', {}], ['campagne', {}], ['campagne', { ligne: 'discontinue' }], ['autoroute', {}]]) {
    const plan = layout(name, opts);
    assert.deepEqual(overlaps(plan), [], name);
    for (const p of plan.pieces) {
      assert.ok(KNOWN.has(p.type), `${name} : pièce inconnue ${p.type}`);
      if (p.opts?.variante !== undefined) assert.ok(p.opts.variante >= 0 && p.opts.variante <= 3, `${name} : variante ${p.opts.variante}`);
    }
    assert.ok(plan.pieces.some(isRoad));
  }
});

test('rien de haut côté caméra (sud-est) autour d’un carrefour de ville', () => {
  const plan = layout('croix', { theme: 'ville' });
  for (const p of plan.pieces) if (p.i > 0 && p.j > 0) assert.ok(!['immeubles', 'maisons'].includes(p.type), `${p.type} en ${p.i},${p.j}`);
});

test('la ligne continue de la campagne suit l’option', () => {
  const cont = layout('campagne').pieces.filter((p) => p.type === 'route' && p.opts.centre === 'continue');
  assert.equal(cont.length, 3);
  assert.equal(layout('campagne', { ligne: 'discontinue' }).pieces.filter((p) => p.opts?.centre === 'continue').length, 0);
});

test('le passage piéton de la rue est à l’endroit visé par les étiquettes (z = 13)', async () => {
  const { RUE } = await import('../src/scene/routes.js');
  const { TILE } = await import('../src/data/layouts.js');
  const tile = layout('rue').pieces.find((p) => p.type === 'route' && p.opts.zebra !== undefined);
  assert.equal(tile.j * TILE + tile.opts.zebra, RUE.zebraZ);
});

test('la route à deux chaussées n’a pas de bretelle', () => {
  assert.ok(layout('autoroute').pieces.some((p) => p.opts?.insertion === 'bretelle'));
  assert.ok(!layout('autoroute', { bretelle: false }).pieces.some((p) => p.opts?.insertion));
});
