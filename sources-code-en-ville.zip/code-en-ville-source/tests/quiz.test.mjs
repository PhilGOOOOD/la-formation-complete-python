import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  createRng, shuffle, isCorrect, expectedCount, expectedHint, questionsFor, createSession, validateQuestion,
} from '../src/engine/quiz.js';
import { QUESTIONS, THEMES, CHAPTERS } from '../src/data/questions.js';

test('le générateur aléatoire est reproductible', () => {
  const a = createRng(42), b = createRng(42);
  const sa = Array.from({ length: 5 }, a), sb = Array.from({ length: 5 }, b);
  assert.deepEqual(sa, sb);
  for (const v of sa) assert.ok(v >= 0 && v < 1);
});

test('shuffle garde les mêmes éléments et ne modifie pas l’original', () => {
  const src = [1, 2, 3, 4, 5, 6];
  const out = shuffle(src, createRng(7));
  assert.deepEqual(src, [1, 2, 3, 4, 5, 6]);
  assert.deepEqual([...out].sort(), src);
});

test('isCorrect exige exactement les bonnes options', () => {
  const q = { correct: ['A', 'C'] };
  assert.equal(isCorrect(q, ['A', 'C']), true);
  assert.equal(isCorrect(q, ['C', 'A']), true);
  assert.equal(isCorrect(q, ['A']), false, 'réponse incomplète');
  assert.equal(isCorrect(q, ['A', 'B', 'C']), false, 'option en trop');
  assert.equal(isCorrect(q, []), false);
  assert.equal(expectedCount(q), 2);
});

test('une session compte le score et gère le temps écoulé', () => {
  const s = createSession(QUESTIONS);
  assert.equal(s.total, QUESTIONS.length);
  assert.equal(s.answer(['B']).correct, true); // priorité à droite
  assert.equal(s.answer(['A', 'C'], { timedOut: true }).correct, false); // stop, temps écoulé
  assert.equal(s.score, 1);
  assert.equal(s.index, 2);
  while (!s.finished) s.answer(s.current.correct);
  const r = s.result();
  assert.equal(r.score, QUESTIONS.length - 1);
  assert.equal(r.errors, 1);
  assert.throws(() => s.answer(['A']), /terminée/);
});

test('le seuil de réussite reprend la proportion 35/40', () => {
  const fake = Array.from({ length: 40 }, (_, i) => ({ id: `q${i}`, correct: ['A'] }));
  const pass = createSession(fake);
  fake.forEach((_, i) => pass.answer(i < 35 ? ['A'] : ['B']));
  assert.equal(pass.result().passed, true);
  const fail = createSession(fake);
  fake.forEach((_, i) => fail.answer(i < 34 ? ['A'] : ['B']));
  assert.equal(fail.result().passed, false);
});

test('l’ordre mélangé est reproductible avec la même graine', () => {
  const a = createSession(QUESTIONS, { order: 'shuffle', seed: 3 });
  const b = createSession(QUESTIONS, { order: 'shuffle', seed: 3 });
  assert.equal(a.current.id, b.current.id);
});

test('une session vide est refusée', () => {
  assert.throws(() => createSession([]), /au moins une question/);
});

test('chaque question de la banque est cohérente', () => {
  const ids = new Set();
  for (const q of QUESTIONS) {
    assert.deepEqual(validateQuestion(q), [], `problèmes dans ${q.id}`);
    assert.ok(!ids.has(q.id), `id en double : ${q.id}`);
    ids.add(q.id);
    assert.ok(THEMES[q.theme], `thème inconnu pour ${q.id}`);
  }
});

test('le validateur détecte les erreurs courantes', () => {
  const bad = { id: 'x', article: 'L12', question: 'Q', explanation: 'court', options: [{ id: 'A', text: '' }],
    correct: ['Z'], scene: { site: 'lune', vehicles: [] } };
  const problems = validateQuestion(bad);
  assert.ok(problems.length >= 5, problems.join(' | '));
});

test('la mention des réponses suit le mode examen ou le mode aide', () => {
  assert.equal(expectedHint({ correct: ['A'] }), '');
  assert.equal(expectedHint({ correct: ['A', 'C'] }), 'Plusieurs bonnes réponses');
  assert.equal(expectedHint({ correct: ['A'] }, { exact: true }), '1 bonne réponse');
  assert.equal(expectedHint({ correct: ['A', 'C'] }, { exact: true }), '2 bonnes réponses');
});

test('chaque chapitre a des questions et chaque question un chapitre connu', () => {
  const ids = new Set(CHAPTERS.map((c) => c.id));
  for (const q of QUESTIONS) assert.ok(ids.has(q.chapter), q.id);
  for (const c of CHAPTERS) assert.ok(questionsFor(QUESTIONS, c.id).length >= 2, c.id);
  assert.equal(questionsFor(QUESTIONS, 'tout').length, QUESTIONS.length);
});
