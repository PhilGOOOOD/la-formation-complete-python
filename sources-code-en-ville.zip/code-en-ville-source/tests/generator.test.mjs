import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateQuestions, NOTIONS, makeQuestion, PIECE_POS } from '../src/engine/generator.js';
import { validateQuestion, createRng } from '../src/engine/quiz.js';
import { resolvePriority, speedLimit } from '../src/engine/rules.js';
import { routeFor, pointAt } from '../src/scene/routes.js';
import { layoutForScene, overlaps } from '../src/data/layouts.js';
import { signByCode } from '../src/data/signs-catalog.js';
import { DOMAIN_IDS } from '../src/data/domains.js';
import { FICHES, PIECES } from '../src/data/fiches.js';

test('chaque notion produit 20 variantes valides et jouables', () => {
  for (const n of NOTIONS) {
    for (let s = 1; s <= 20; s++) {
      const q = makeQuestion(n.id, createRng(s * 7919 + 1), `${n.id}-${s}`);
      assert.deepEqual(validateQuestion(q), [], `${n.id} : ${validateQuestion(q).join(' | ')}`);
      assert.equal(q.notion, n.id);
      assert.ok(DOMAIN_IDS.includes(q.domaine), q.domaine);
      for (const v of q.scene.vehicles) assert.ok(routeFor(v, q.scene.site).length >= 0.04, `${q.id}/${v.id}`);
      for (const sg of q.scene.signs || []) assert.ok(signByCode(sg.type), `panneau inconnu ${sg.type}`);
      assert.deepEqual(overlaps(layoutForScene(q.scene)), [], q.id);
      assert.equal(new Set(q.options.map((o) => o.text)).size, q.options.length, `${q.id} : options en double`);
    }
  }
});

test('le catalogue couvre les 10 thèmes de l’examen, avec au moins 6 notions chacun', () => {
  for (const d of DOMAIN_IDS) assert.ok(NOTIONS.filter((n) => n.domaine === d).length >= 6, d);
  assert.equal(new Set(NOTIONS.map((n) => n.id)).size, NOTIONS.length, 'identifiants de notions uniques');
});

test('une série ne répète jamais une notion et couvre tous les thèmes', () => {
  for (let seed = 1; seed <= 40; seed++) {
    for (const count of [10, 20, 40]) {
      const qs = generateQuestions(count, seed);
      assert.equal(qs.length, count);
      assert.equal(new Set(qs.map((q) => q.notion)).size, count, `notion répétée (graine ${seed}, ${count})`);
      if (count >= 10) assert.equal(new Set(qs.map((q) => q.domaine)).size, 10, `thème manquant (graine ${seed}, ${count})`);
      assert.equal(new Set(qs.map((q) => q.id)).size, count);
    }
  }
});

test('deux questions consécutives ne partagent ni thème ni famille de mise en scène', () => {
  for (let seed = 1; seed <= 40; seed++) {
    const qs = generateQuestions(20, seed);
    for (let i = 1; i < qs.length; i++) {
      assert.notEqual(qs[i].domaine, qs[i - 1].domaine, `graine ${seed}, position ${i}`);
      assert.notEqual(qs[i].famille, qs[i - 1].famille, `graine ${seed}, position ${i}`);
    }
  }
});

test('l’historique écarte les notions déjà vues tant qu’il en reste de nouvelles', () => {
  const seen = [];
  for (let k = 0; k < 4; k++) {
    const qs = generateQuestions(20, 100 + k, { history: seen });
    const repeated = qs.filter((q) => seen.includes(q.notion));
    assert.equal(repeated.length, 0, `série ${k + 1} : ${repeated.map((q) => q.notion).join(', ')}`);
    seen.push(...qs.map((q) => q.notion));
  }
});

test('les mises en scène varient : branche d’arrivée, couleur du joueur, angle de vue', () => {
  const arms = new Set(), paints = new Set(), vues = new Set(), kinds = new Set();
  for (let s = 1; s <= 60; s++) {
    const q = makeQuestion('priorite-droite', createRng(s), s);
    const me = q.scene.vehicles.find((v) => v.player);
    arms.add(me.from); paints.add(me.paint); vues.add(q.scene.layoutOpts.camera);
    kinds.add(q.scene.vehicles.find((v) => !v.player).kind);
  }
  assert.equal(arms.size, 4, 'les quatre branches');
  assert.ok(paints.size >= 5, `couleurs du joueur : ${[...paints]}`);
  assert.equal(vues.size, 2);
  assert.ok(kinds.size >= 4, `types d’usagers : ${[...kinds]}`);
});

test('la réponse des questions de priorité correspond au moteur de règles, quelle que soit la branche', () => {
  for (const notion of ['priorite-droite', 'priorite-gauche', 'stop-moi', 'cedez-moi', 'stop-autre', 'cedez-autre', 'tourne-gauche-face', 'face-tourne-gauche']) {
    for (let i = 0; i < 60; i++) {
      const q = makeQuestion(notion, createRng(i + 1), i);
      const [me, other] = q.scene.vehicles;
      const regimeOf = (from) => q.scene.signs.find((s) => s.approach === from)?.type || 'aucun';
      const faceRegime = /tous les deux un stop/.test(q.situation) ? 'stop' : /tous les deux un cédez/.test(q.situation) ? 'cedez' : null;
      const r = resolvePriority({ from: me.from, action: me.action, regime: faceRegime || regimeOf(me.from) }, { from: other.from, action: other.action, regime: faceRegime || regimeOf(other.from) });
      assert.deepEqual(q.correct, [r.first === 'moi' ? 'A' : 'B'], `${notion} : ${q.situation}`);
      const order = q.scene.resolution.filter((s) => s.go).map((s) => s.go[0]);
      assert.equal(order[0], r.first === 'moi' ? 'moi' : 'autre', 'la scène rejoue le bon ordre');
    }
  }
});

test('la réponse des questions de vitesse est la limite la plus basse applicable', () => {
  for (const n of NOTIONS.filter((x) => x.famille === 'vitesse')) {
    for (let i = 0; i < 30; i++) {
      const q = makeQuestion(n.id, createRng(i + 7), i);
      const good = q.options.find((o) => q.correct.includes(o.id)).text;
      assert.match(good, /^\d+ km\/h$/);
      assert.ok(q.explanation.includes(good.replace(' km/h', '')), q.explanation);
    }
  }
});

test('les feux : le joueur ne franchit le feu dans la scène que si la règle le permet', () => {
  for (const notion of ['feu-rouge', 'feu-jaune']) {
    for (let i = 0; i < 20; i++) {
      const q = makeQuestion(notion, createRng(i + 3), i);
      const steps = q.scene.resolution;
      const firstGoMe = steps.findIndex((s) => s.go?.some((m) => (m.id || m) === 'moi' && (m.dist ?? 34) > 20));
      const me = q.scene.vehicles[0].from;
      const greenBefore = steps.slice(0, firstGoMe).some((s) => s.feux && s.feux[me] === 'vert');
      assert.ok(greenBefore, `${notion} : le joueur attend le vert`);
    }
  }
  // Feu vert mais carrefour encombré : la file avance avant que le joueur s'engage
  const q = makeQuestion('feu-vert-encombre', createRng(9), 'x');
  const steps = q.scene.resolution.filter((s) => s.go);
  assert.ok(steps[0].go.every((m) => m.id.startsWith('file')), 'la file dégage d’abord');
  assert.equal(steps[1].go[0], 'moi');
});

test('les pièces étiquetées sous le capot correspondent aux options', () => {
  for (const f of FICHES.filter((x) => x.scene.etiquettes)) {
    const q = makeQuestion(f.notion, createRng(5), 'x');
    assert.equal(q.scene.labels.length, q.options.length);
    q.options.forEach((o, i) => assert.ok(o.text.toLowerCase().startsWith(PIECES[f.scene.etiquettes[i]].toLowerCase().slice(0, 6)), o.text));
    for (const k of f.scene.etiquettes) assert.ok(PIECE_POS[k], k);
  }
});

test('chaque fiche cite un article du Code ou une source publique avec lien', () => {
  for (const f of FICHES) {
    assert.ok(f.article || (f.reference && (/^https:\/\//.test(f.source || '') || /maquette/.test(f.reference))), f.notion);
    for (const v of f.variantes) assert.ok(v.e.length > 60, `${f.notion} : explication trop courte`);
  }
});

test('le même tirage est reproductible avec la même graine', () => {
  assert.deepEqual(generateQuestions(10, 42).map((q) => q.situation), generateQuestions(10, 42).map((q) => q.situation));
});

test('les piétons du feu vert traversent bien la rue où le joueur tourne', () => {
  for (let i = 0; i < 20; i++) {
    const q = makeQuestion('feu-vert-pietons', createRng(i + 11), i);
    const me = routeFor(q.scene.vehicles[0], 'intersection');
    const walker = routeFor(q.scene.vehicles[1], 'intersection');
    const p = pointAt(walker, walker.hold);
    const near = me.points.some((m) => Math.hypot(m.x - p.x, m.z - p.z) < 1.6);
    assert.ok(near, `le piéton bloque la trajectoire du joueur (${JSON.stringify(p)})`);
  }
});

// Encombrement approximatif (longueur, largeur) de chaque modèle, pour vérifier qu'aucun véhicule n'en chevauche un autre
const SIZE = { voiture: [4.3, 1.9], camionnette: [5.2, 2.0], camion: [11, 2.5], bus: [12, 2.6], moto: [2.1, 0.9], velo: [1.8, 0.7], tracteur: [4, 2.1], pompiers: [6.4, 2.2], smur: [4.6, 2.2], police: [4.6, 2.2], pieton: [0.6, 0.6] };
function corners(p, angle, [l, w]) {
  const f = { x: Math.sin(angle), z: Math.cos(angle) }, r = { x: f.z, z: -f.x };
  return [[1, 1], [1, -1], [-1, -1], [-1, 1]].map(([a, b]) => ({ x: p.x + f.x * a * l / 2 + r.x * b * w / 2, z: p.z + f.z * a * l / 2 + r.z * b * w / 2 }));
}
function overlap(A, B) {
  for (const poly of [A, B]) for (let i = 0; i < 4; i++) {
    const a = poly[i], b = poly[(i + 1) % 4], n = { x: b.z - a.z, z: a.x - b.x };
    const proj = (P) => P.map((q) => q.x * n.x + q.z * n.z);
    const pa = proj(A), pb = proj(B);
    if (Math.max(...pa) < Math.min(...pb) || Math.max(...pb) < Math.min(...pa)) return false;
  }
  return true;
}
test('à l’arrêt (moment de la question), aucun véhicule n’en chevauche un autre', () => {
  for (const n of NOTIONS) for (let s = 1; s <= 8; s++) {
    const q = makeQuestion(n.id, createRng(s * 31 + 7), s);
    const boxes = q.scene.vehicles.filter((v) => v.kind !== 'train' && !v.couche && !v.tombe).map((v) => {
      const r = routeFor(v, q.scene.site); const p = pointAt(r, r.hold);
      return { id: v.id, box: corners(p, p.angle, SIZE[v.kind || 'voiture']) };
    });
    for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
      assert.ok(!overlap(boxes[i].box, boxes[j].box), `${q.notion} (graine ${s}) : ${boxes[i].id} chevauche ${boxes[j].id}`);
    }
  }
});

// ——— v0.5 : révision par chapitre et panneaux ———
import { CHAPITRES } from '../src/data/chapters.js';
import { SIGNS as ALL_SIGNS } from '../src/data/signs-catalog.js';

test('chaque notion appartient à un chapitre de révision, et chaque chapitre a des notions', () => {
  const ids = new Set(CHAPITRES.map((c) => c.id));
  for (const n of NOTIONS) assert.ok(ids.has(n.chapitre), `${n.id} : chapitre ${n.chapitre}`);
  for (const c of CHAPITRES) assert.ok(NOTIONS.some((n) => n.chapitre === c.id), c.id);
});

test('une révision ne tire que des notions du chapitre choisi, sans répétition', () => {
  for (const c of CHAPITRES) {
    const pool = NOTIONS.filter((n) => n.chapitre === c.id);
    const qs = generateQuestions(pool.length, 77, { chapitres: [c.id] });
    assert.ok(qs.every((q) => NOTIONS.find((n) => n.id === q.notion).chapitre === c.id), c.id);
    assert.equal(new Set(qs.map((q) => q.notion)).size, pool.length, `${c.id} : toutes les notions, une fois chacune`);
  }
});

test('révision d’un petit chapitre avec plus de questions que de notions : les notions reviennent après épuisement', () => {
  const qs = generateQuestions(10, 5, { chapitres: ['stationnement'] });
  assert.equal(qs.length, 10);
});

test('questions « quel panneau » : quatre panneaux distincts, images et étiquettes cohérentes', () => {
  for (const n of NOTIONS.filter((x) => x.famille === 'panneau-image')) {
    for (let s = 1; s <= 10; s++) {
      const q = makeQuestion(n.id, createRng(s), s);
      assert.equal(q.options.length, 4);
      assert.ok(q.options.every((o) => o.signCode && o.alt), q.id);
      assert.equal(new Set(q.options.map((o) => o.signCode)).size, 4);
      const target = ALL_SIGNS.find((x) => q.question.includes(`« ${x.sens} »`));
      assert.equal(q.options.find((o) => q.correct.includes(o.id)).signCode, target.code, q.question);
      assert.deepEqual(q.scene.signs.map((x) => x.type), q.options.map((o) => o.signCode), 'les panneaux de la scène suivent l’ordre A à D');
    }
  }
});

test('chaque panneau du catalogue a une question de signification avec trois leurres de sens différents', () => {
  for (const sg of ALL_SIGNS) {
    const q = makeQuestion(`panneau-${sg.code}`, createRng(3), 'x');
    assert.equal(q.options.length, 4, sg.code);
    assert.equal(new Set(q.options.map((o) => o.text)).size, 4, sg.code);
    assert.equal(q.options.find((o) => q.correct.includes(o.id)).text, sg.sens);
  }
});
